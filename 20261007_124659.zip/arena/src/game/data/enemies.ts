/**
 * 敵兵／首領資料庫
 * ------------------------------------------------------------------
 * 每一種部隊都有獨立的：AI 原型、招式時間軸、死亡演出、配色、魂魄掉落。
 * 新增敵種只需在此追加 EnemyDef，關卡資料即可引用。
 */
import type { EnemyDef, MoveDef } from '../core/types';
import { flash, fx, melee, motion, move, multiHits, proj, shake, sfx } from './move-helpers';

/* ============================== 雜兵 ============================== */

/** 小妖嘍囉：成群衝上來揮棒的基礎雜兵 */
const IMP_CLUB: MoveDef = move({
  id: 'imp_club',
  name: '木棒揮擊',
  kind: 'combo',
  duration: 0.62,
  events: [
    sfx(0.06, 'swing', 0.5, 0.9),
    motion(0.1, 220, 0, 0.16),
    melee(0.22, 8, 44, { w: 78, h: 74, kb: { x: 240, z: 60 }, hitstop: 0.05, shake: 6, fx: 'impactFlame', sfx: 'hit' }),
  ],
});
const IMP_LEAP: MoveDef = move({
  id: 'imp_leap',
  name: '撲抱',
  kind: 'combo',
  duration: 0.8,
  events: [
    sfx(0.0, 'jump', 0.6, 1.3),
    motion(0.06, 420, 520, 0.36),
    melee(0.3, 10, 40, { oy: -20, w: 76, h: 80, kb: { x: 300, z: 180 }, hitstop: 0.06, shake: 8, fx: 'impactFlame', sfx: 'hit' }),
    fx(0.34, 'dustPuff', { scale: 0.8 }),
  ],
});

/** 骷髏槍兵：中距離突刺，會保持距離 */
const SPEAR_THRUST: MoveDef = move({
  id: 'spear_thrust',
  name: '紅纓突刺',
  kind: 'combo',
  duration: 0.72,
  events: [
    sfx(0.08, 'swing', 0.6, 1.1),
    fx(0.14, 'slashIron', { ox: 70, oz: 56, scale: 0.9, color: '#e8e2d0' }),
    motion(0.18, 340, 0, 0.16),
    melee(0.24, 12, 84, { w: 130, h: 56, kb: { x: 320, z: 40 }, hitstop: 0.07, shake: 9, fx: 'impactIron', sfx: 'hit' }),
  ],
});
const SPEAR_SWEEP: MoveDef = move({
  id: 'spear_sweep',
  name: '橫掃千軍',
  kind: 'combo',
  duration: 0.86,
  events: [
    sfx(0.1, 'swingHeavy', 0.7, 1),
    motion(0.18, 200, 0, 0.24),
    ...multiHits(0.24, 2, 0.14, 9, 76, { w: 150, h: 70, pierce: true, kb: { x: 260, z: 100 }, hitstop: 0.05, shake: 8, fx: 'slashIron' }),
  ],
});

/** 狼影忍：高速接近、瞬身連斬 */
const NINJA_SLASH: MoveDef = move({
  id: 'ninja_slash',
  name: '雙牙連斬',
  kind: 'combo',
  duration: 0.6,
  events: [
    sfx(0.02, 'dash', 0.6, 1.3),
    motion(0.02, 620, 0, 0.14),
    fx(0.06, 'dashGhost', { scale: 0.9, color: '#5b6bd6' }),
    ...multiHits(0.12, 3, 0.1, 7, 44, { w: 82, h: 72, kb: { x: 200, z: 40 }, hitstop: 0.04, shake: 6, fx: 'slashWind', sfx: 'hit' }),
  ],
});
const NINJA_SHURIKEN: MoveDef = move({
  id: 'ninja_shuriken',
  name: '影手裡劍',
  kind: 'skill',
  duration: 0.7,
  events: [
    sfx(0.06, 'wind', 0.7, 1.4),
    proj(0.14, 'enemyArrow', 8, { count: 3, spread: 0.16, speed: 620, oz: 60, size: 0.8, life: 1.6 }),
  ],
});

/** 黃袍術士：遠距離符咒射擊、會瞬移 */
const CASTER_RUNE: MoveDef = move({
  id: 'caster_rune',
  name: '黃符射擊',
  kind: 'skill',
  duration: 0.9,
  events: [
    sfx(0.04, 'charge', 0.6, 1.4),
    fx(0.16, 'chargeAura', { oz: 62, scale: 0.8, color: '#ffd76a' }),
    proj(0.3, 'enemyRune', 11, { count: 1, speed: 460, oz: 62, size: 1, life: 2.4, homing: 0.8 }),
    proj(0.44, 'enemyRune', 11, { count: 1, speed: 500, oz: 62, size: 1, life: 2.4, homing: 0.8 }),
  ],
});
const CASTER_NOVA: MoveDef = move({
  id: 'caster_nova',
  name: '咒爆陣',
  kind: 'skill',
  duration: 1.1,
  events: [
    sfx(0.04, 'thunder', 0.8, 1.5),
    fx(0.2, 'shockRing', { scale: 1.6, color: '#ffd76a' }),
    melee(0.34, 14, 0, { w: 190, h: 150, kb: { x: 380, z: 260 }, hitstop: 0.08, shake: 14, fx: 'impactFox', sfx: 'explode', aoe: 130 }),
    flash(0.34, '#ffe9a0', 0.35, 0.24),
  ],
});

/** 爆焰甲蟲：衝向玩家自爆 */
const BOMBER_BLAST: MoveDef = move({
  id: 'bomber_blast',
  name: '自爆',
  kind: 'skill',
  duration: 0.8,
  events: [
    sfx(0.0, 'charge', 0.9, 1.6),
    fx(0.06, 'chargeAura', { oz: 40, scale: 1.2, color: '#ff6a1a' }),
    motion(0.02, 380, 0, 0.3),
    sfx(0.36, 'explode', 1, 0.9),
    melee(0.38, 22, 0, { w: 200, h: 170, kb: { x: 620, z: 420 }, hitstop: 0.1, shake: 24, fx: 'impactFlame', sfx: 'explode', aoe: 160 }),
    flash(0.38, '#ffb03a', 0.5, 0.3),
    fx(0.4, 'shockRing', { scale: 2.2, color: '#ff6a1a' }),
    shake(0.38, 22),
  ],
});

/** 石甲巨鬼：慢速重擊、霸體 */
const BRUTE_SLAM: MoveDef = move({
  id: 'brute_slam',
  name: '巨石鎚砸',
  kind: 'combo',
  duration: 1.25,
  events: [
    sfx(0.06, 'charge', 0.8, 0.7),
    fx(0.2, 'chargeAura', { oz: 70, scale: 1.4, color: '#ff8a3a' }),
    motion(0.34, 260, 0, 0.2),
    sfx(0.5, 'swingHeavy', 0.9, 0.6),
    melee(0.58, 26, 74, { w: 170, h: 140, kb: { x: 480, z: 420 }, launch: true, hitstop: 0.14, shake: 26, fx: 'impactRock', sfx: 'hitHeavy', aoe: 140 }),
    fx(0.6, 'groundCrack', { scale: 1.8 }),
    fx(0.62, 'shockRing', { scale: 2.2, color: '#e0a558' }),
    shake(0.58, 24),
    proj(0.6, 'rockShard', 12, { count: 4, spread: 0.6, speed: 420, oz: 20, size: 0.9, life: 1 }),
  ],
});
const BRUTE_CHARGE: MoveDef = move({
  id: 'brute_charge',
  name: '巨鬼衝撞',
  kind: 'skill',
  duration: 1.3,
  events: [
    sfx(0.02, 'dash', 0.9, 0.5),
    motion(0.16, 620, 0, 0.6),
    fx(0.18, 'dashGhost', { scale: 1.6, color: '#8a6a4a' }),
    ...multiHits(0.28, 4, 0.14, 16, 66, { w: 150, h: 130, pierce: true, kb: { x: 520, z: 200 }, hitstop: 0.07, shake: 14, fx: 'impactRock' }),
    shake(0.9, 18),
    fx(0.88, 'dustPuff', { scale: 1.6 }),
  ],
});

/** 弓妖：遠距離拋射箭雨 */
const ARCHER_SHOT: MoveDef = move({
  id: 'archer_shot',
  name: '妖弓連射',
  kind: 'skill',
  duration: 0.9,
  events: [
    sfx(0.08, 'swing', 0.6, 1.5),
    proj(0.16, 'enemyArrow', 10, { count: 1, speed: 760, oz: 66, size: 1, life: 2 }),
    proj(0.34, 'enemyArrow', 10, { count: 1, speed: 800, oz: 66, size: 1, life: 2 }),
    proj(0.52, 'enemyArrow', 10, { count: 1, speed: 840, oz: 66, size: 1, life: 2 }),
  ],
});
const ARCHER_RAIN: MoveDef = move({
  id: 'archer_rain',
  name: '天降箭雨',
  kind: 'skill',
  duration: 1.4,
  events: [
    sfx(0.06, 'wind', 0.8, 0.8),
    proj(0.2, 'enemyArrow', 12, { count: 6, spread: 1.1, speed: 520, oz: 220, size: 1, life: 2.2 }),
    proj(0.5, 'enemyArrow', 12, { count: 6, spread: 1.1, speed: 560, oz: 240, size: 1, life: 2.2 }),
    sfx(0.2, 'swing', 0.7, 1.2),
  ],
});

/** 獄犬：成群疾衝、撲咬 */
const HOUND_BITE: MoveDef = move({
  id: 'hound_bite',
  name: '撕裂咬',
  kind: 'combo',
  duration: 0.5,
  events: [
    sfx(0.04, 'swing', 0.6, 1.4),
    motion(0.06, 460, 0, 0.16),
    melee(0.16, 9, 42, { w: 76, h: 66, kb: { x: 260, z: 80 }, hitstop: 0.05, shake: 7, fx: 'impactFox', sfx: 'hit' }),
  ],
});

/** 旗手巫師：為周圍敵人強化、插旗 */
const SHAMAN_BUFF: MoveDef = move({
  id: 'shaman_buff',
  name: '戰旗咒舞',
  kind: 'skill',
  duration: 1.3,
  events: [
    sfx(0.04, 'thunder', 0.7, 1.6),
    fx(0.14, 'chargeAura', { oz: 60, scale: 1.3, color: '#ff5ad6' }),
    fx(0.4, 'shockRing', { scale: 2.4, color: '#ff5ad6' }),
    melee(0.42, 8, 0, { w: 240, h: 180, pierce: true, kb: { x: 180, z: 60 }, hitstop: 0.04, shake: 8, fx: 'impactFox' }),
  ],
});
const SHAMAN_BOLT: MoveDef = move({
  id: 'shaman_bolt',
  name: '咒雷',
  kind: 'skill',
  duration: 1,
  events: [
    sfx(0.06, 'charge', 0.7, 1.5),
    sfx(0.34, 'thunder', 1),
    proj(0.36, 'thunderSpear', 15, { count: 1, speed: 900, oz: 66, size: 1.1, life: 1.4 }),
    fx(0.36, 'lightning', { oz: 60, scale: 1 }),
  ],
});

export const ENEMIES: EnemyDef[] = [
  {
    id: 'imp',
    name: '青皮嘍囉',
    rank: '雜兵',
    ai: 'chaser',
    atlas: 0,
    hp: 34,
    atk: 8,
    speed: 168,
    weight: 0.8,
    radius: 26,
    height: 82,
    scale: 1,
    colors: { body: '#5d8f4a', trim: '#c8b48a', skin: '#7cb35f', aura: '#a3d977', metal: '#8a7a5a' },
    weapon: '裂木棒',
    attacks: [
      { range: 78, cd: 1.3, windup: 0.3, move: IMP_CLUB },
      { range: 220, cd: 4.5, windup: 0.3, move: IMP_LEAP, chance: 0.4 },
    ],
    deathFx: 'boneBurst',
    deathColors: ['#7cb35f', '#c8b48a', '#3a5a2a', '#ffffff'],
    souls: [6, 11],
    desc: '最下層的妖怪雜兵，靠著數量壓人。死亡時骨屑四濺。',
  },
  {
    id: 'spear',
    name: '紅纓骷槍',
    rank: '雜兵',
    ai: 'spear',
    atlas: 1,
    hp: 52,
    atk: 12,
    speed: 142,
    weight: 1.1,
    radius: 28,
    height: 96,
    scale: 1.05,
    colors: { body: '#d8d2c0', trim: '#c0392b', skin: '#efe9d8', aura: '#c0392b', metal: '#9fb0c0' },
    weapon: '紅纓槍',
    attacks: [
      { range: 150, cd: 1.8, windup: 0.34, move: SPEAR_THRUST },
      { range: 120, cd: 4, windup: 0.4, move: SPEAR_SWEEP, chance: 0.35 },
    ],
    deathFx: 'boneShatter',
    deathColors: ['#efe9d8', '#c0392b', '#9fb0c0', '#6a6152'],
    souls: [9, 15],
    desc: '成群結隊的骷髏槍兵，突刺距離長，需要靠翻滾繞背。',
  },
  {
    id: 'ninja',
    name: '狼影忍',
    rank: '雜兵',
    ai: 'ninja',
    atlas: 2,
    hp: 44,
    atk: 10,
    speed: 268,
    weight: 0.7,
    radius: 24,
    height: 88,
    scale: 0.98,
    colors: { body: '#2f3560', trim: '#5b6bd6', skin: '#6a7a9a', aura: '#5b6bd6', metal: '#cfd8e8' },
    weapon: '雙月牙刃',
    attacks: [
      { range: 92, cd: 1.1, windup: 0.2, move: NINJA_SLASH },
      { range: 340, cd: 3.4, windup: 0.3, move: NINJA_SHURIKEN, chance: 0.5 },
    ],
    deathFx: 'smokeVanish',
    deathColors: ['#5b6bd6', '#2f3560', '#cfd8e8', '#1a1e38'],
    souls: [11, 18],
    desc: '速度極快的狼族忍者，會瞬身接近並以三段斬偷襲。',
  },
  {
    id: 'caster',
    name: '黃袍術士',
    rank: '雜兵',
    ai: 'caster',
    atlas: 3,
    hp: 40,
    atk: 13,
    speed: 118,
    weight: 0.6,
    radius: 26,
    height: 92,
    scale: 1,
    colors: { body: '#e0c25a', trim: '#8a5a1a', skin: '#e8dcc0', aura: '#ffd76a', metal: '#f0e0a0' },
    weapon: '玉符杖',
    attacks: [
      { range: 460, cd: 2.2, windup: 0.4, move: CASTER_RUNE },
      { range: 180, cd: 6, windup: 0.5, move: CASTER_NOVA, chance: 0.3 },
    ],
    deathFx: 'talismanScatter',
    deathColors: ['#ffd76a', '#e0c25a', '#fff3c0', '#8a5a1a'],
    souls: [12, 20],
    desc: '施放追蹤符咒的法師，優先擊殺目標，死後符紙漫天飛散。',
  },
  {
    id: 'bomber',
    name: '爆焰甲蟲',
    rank: '雜兵',
    ai: 'bomber',
    atlas: 4,
    hp: 26,
    atk: 22,
    speed: 232,
    weight: 0.9,
    radius: 28,
    height: 60,
    scale: 0.9,
    colors: { body: '#3a2a20', trim: '#ff6a1a', skin: '#5a3a24', aura: '#ff8a3a', metal: '#c8a05a' },
    weapon: '熔核甲殼',
    attacks: [{ range: 120, cd: 1.4, windup: 0.42, move: BOMBER_BLAST }],
    deathFx: 'fieryExplosion',
    deathColors: ['#ff8a3a', '#ff6a1a', '#ffe9a0', '#3a2a20'],
    souls: [8, 14],
    desc: '衝過來自爆的甲蟲妖，可提前擊殺引爆它來傷害其他敵人。',
  },
  {
    id: 'brute',
    name: '石甲巨鬼',
    rank: '菁英',
    ai: 'brute',
    atlas: 5,
    hp: 190,
    atk: 24,
    speed: 96,
    weight: 2.6,
    radius: 44,
    height: 140,
    scale: 1.55,
    colors: { body: '#6a5a4a', trim: '#ff8a3a', skin: '#8a7a62', aura: '#ff8a3a', metal: '#c8b89a' },
    weapon: '巖棘巨鎚',
    attacks: [
      { range: 140, cd: 2.6, windup: 0.56, move: BRUTE_SLAM },
      { range: 420, cd: 6.5, windup: 0.5, move: BRUTE_CHARGE, chance: 0.4 },
    ],
    deathFx: 'rockShatter',
    deathColors: ['#8a7a62', '#ff8a3a', '#c8b89a', '#3a2f24'],
    souls: [26, 40],
    desc: '擁有霸體的石甲巨鬼，重擊可把玩家打飛，需要用浮空技破解。',
  },
  {
    id: 'archer',
    name: '妖弓手',
    rank: '雜兵',
    ai: 'ranged',
    atlas: 1,
    hp: 38,
    atk: 11,
    speed: 150,
    weight: 0.7,
    radius: 24,
    height: 90,
    scale: 1,
    colors: { body: '#4a6a5a', trim: '#a8d84a', skin: '#7aa88a', aura: '#a8d84a', metal: '#d8e8c0' },
    weapon: '骨弓',
    attacks: [
      { range: 520, cd: 2.4, windup: 0.36, move: ARCHER_SHOT },
      { range: 400, cd: 8, windup: 0.5, move: ARCHER_RAIN, chance: 0.3 },
    ],
    deathFx: 'featherBurst',
    deathColors: ['#a8d84a', '#4a6a5a', '#d8e8c0', '#2a3a30'],
    souls: [10, 16],
    desc: '保持在遠處放箭的弓手，箭雨會封走位，需用仙術突進貼身。',
  },
  {
    id: 'hound',
    name: '獄炎犬',
    rank: '雜兵',
    ai: 'chaser',
    atlas: 2,
    hp: 30,
    atk: 9,
    speed: 292,
    weight: 0.6,
    radius: 26,
    height: 62,
    scale: 0.92,
    colors: { body: '#4a1a2a', trim: '#ff4a6a', skin: '#7a2a3a', aura: '#ff4a6a', metal: '#e8b0a0' },
    weapon: '獄炎獠牙',
    attacks: [{ range: 84, cd: 0.9, windup: 0.22, move: HOUND_BITE }],
    deathFx: 'emberDissolve',
    deathColors: ['#ff4a6a', '#7a2a3a', '#ffb0a0', '#2a0a14'],
    souls: [7, 12],
    desc: '成群疾衝的獄犬，速度快但血薄，適合用範圍技一次清理。',
  },
  {
    id: 'shaman',
    name: '咒旗巫者',
    rank: '菁英',
    ai: 'caster',
    atlas: 3,
    hp: 110,
    atk: 15,
    speed: 132,
    weight: 1,
    radius: 28,
    height: 96,
    scale: 1.1,
    colors: { body: '#6a2a7a', trim: '#ff5ad6', skin: '#c090d0', aura: '#ff5ad6', metal: '#ffe0a0' },
    weapon: '咒骨旗',
    attacks: [
      { range: 520, cd: 3.2, windup: 0.44, move: SHAMAN_BOLT },
      { range: 300, cd: 9, windup: 0.6, move: SHAMAN_BUFF, chance: 0.6 },
    ],
    deathFx: 'starDust',
    deathColors: ['#ff5ad6', '#6a2a7a', '#ffe0a0', '#2a0a3a'],
    souls: [22, 34],
    desc: '插旗強化周圍敵人的巫者，會讓雜兵攻速與傷害上升，務必優先處理。',
  },
];

/* ============================== 首領 ============================== */

const BOSS_SLAM: MoveDef = move({
  id: 'b_slam',
  name: '巨岩墜拳',
  kind: 'combo',
  duration: 1.4,
  events: [
    sfx(0.04, 'charge', 1, 0.6),
    fx(0.2, 'chargeAura', { oz: 90, scale: 2, color: '#e0a558' }),
    motion(0.4, 300, 0, 0.2),
    sfx(0.58, 'swingHeavy', 1, 0.6),
    melee(0.66, 30, 90, { w: 220, h: 180, kb: { x: 620, z: 520 }, launch: true, hitstop: 0.16, shake: 34, fx: 'impactRock', sfx: 'hitCrit', aoe: 200 }),
    fx(0.68, 'groundCrack', { scale: 3 }),
    fx(0.7, 'shockRing', { scale: 3.4, color: '#e0a558' }),
    proj(0.7, 'rockShard', 16, { count: 6, spread: 1.2, speed: 480, oz: 30, size: 1.2, life: 1.2 }),
    shake(0.66, 32),
    flash(0.66, '#ffd8a0', 0.35, 0.3),
  ],
});
const BOSS_ROCKRAIN: MoveDef = move({
  id: 'b_rockrain',
  name: '落石陣',
  kind: 'skill',
  duration: 2.2,
  events: [
    sfx(0.04, 'bossRoar', 0.9, 0.8),
    fx(0.2, 'shockRing', { scale: 3, color: '#c8a05a' }),
    proj(0.5, 'rockShard', 18, { count: 7, spread: 2.2, speed: 380, oz: 320, size: 1.4, life: 2 }),
    proj(1.0, 'rockShard', 18, { count: 7, spread: 2.2, speed: 420, oz: 340, size: 1.4, life: 2 }),
    proj(1.5, 'rockShard', 20, { count: 9, spread: 2.4, speed: 460, oz: 360, size: 1.5, life: 2 }),
    shake(0.5, 12),
    shake(1.0, 14),
    shake(1.5, 18),
  ],
});
const BOSS_CHARGE: MoveDef = move({
  id: 'b_charge',
  name: '山崩衝撞',
  kind: 'skill',
  duration: 1.8,
  events: [
    sfx(0.02, 'dash', 1, 0.4),
    fx(0.1, 'dashGhost', { scale: 2.4, color: '#8a6a4a' }),
    motion(0.14, 760, 0, 0.9),
    ...multiHits(0.3, 6, 0.14, 18, 80, { w: 190, h: 170, pierce: true, kb: { x: 700, z: 300 }, hitstop: 0.07, shake: 18, fx: 'impactRock' }),
    melee(1.1, 34, 86, { w: 220, h: 190, kb: { x: 900, z: 620 }, launch: true, hitstop: 0.18, shake: 36, fx: 'impactRock', sfx: 'hitCrit', aoe: 220 }),
    fx(1.12, 'groundCrack', { scale: 3.4 }),
    fx(1.14, 'shockRing', { scale: 4, color: '#e0a558' }),
    shake(1.1, 34),
  ],
});
const BOSS_FIREBEAM: MoveDef = move({
  id: 'b_firebeam',
  name: '焰獄光束',
  kind: 'skill',
  duration: 2.4,
  events: [
    sfx(0.04, 'charge', 1, 0.7),
    sfx(0.1, 'bossRoar', 0.9, 1.1),
    fx(0.3, 'chargeAura', { oz: 90, scale: 2.2, color: '#ff5a1a' }),
    proj(0.7, 'bossBeam', 14, { count: 3, spread: 0.14, speed: 900, oz: 80, size: 1.6, life: 1.6 }),
    proj(1.2, 'bossBeam', 14, { count: 5, spread: 0.5, speed: 950, oz: 80, size: 1.6, life: 1.6 }),
    proj(1.7, 'bossBeam', 18, { count: 1, speed: 1200, oz: 80, size: 2.6, life: 1.8 }),
    flash(1.7, '#ff6a2a', 0.4, 0.4),
    shake(1.7, 26),
  ],
});
const BOSS_METEOR: MoveDef = move({
  id: 'b_meteor',
  name: '焚星隕雨',
  kind: 'skill',
  duration: 3,
  events: [
    sfx(0.04, 'bossRoar', 1, 0.7),
    fx(0.2, 'shockRing', { scale: 4, color: '#ff3b52' }),
    proj(0.5, 'starFlame', 22, { count: 8, spread: 2.6, speed: 420, oz: 420, size: 1.5, life: 2.4 }),
    proj(1.1, 'starFlame', 22, { count: 10, spread: 2.6, speed: 460, oz: 460, size: 1.5, life: 2.4 }),
    proj(1.7, 'starFlame', 26, { count: 12, spread: 2.8, speed: 500, oz: 500, size: 1.7, life: 2.4 }),
    proj(2.3, 'starFlame', 30, { count: 6, spread: 1.2, speed: 540, oz: 520, size: 2.2, life: 2.4 }),
    shake(0.5, 14),
    shake(1.1, 16),
    shake(1.7, 20),
    shake(2.3, 28),
  ],
});
const BOSS_THUNDER: MoveDef = move({
  id: 'b_thunder',
  name: '九霄雷獄',
  kind: 'skill',
  duration: 2.2,
  events: [
    sfx(0.04, 'charge', 1, 1.2),
    fx(0.3, 'lightning', { oz: 120, scale: 1.6 }),
    sfx(0.44, 'thunder', 1),
    proj(0.46, 'thunderSpear', 20, { count: 5, spread: 1.4, speed: 1100, oz: 90, size: 1.4, life: 1.2 }),
    fx(0.9, 'lightning', { oz: 120, scale: 1.8, color: '#9fe8ff' }),
    sfx(1.0, 'thunder', 1, 0.9),
    proj(1.02, 'thunderSpear', 20, { count: 7, spread: 1.8, speed: 1200, oz: 90, size: 1.4, life: 1.2 }),
    flash(0.46, '#dff6ff', 0.5, 0.3),
    flash(1.02, '#dff6ff', 0.5, 0.3),
    shake(0.46, 22),
    shake(1.02, 26),
  ],
});
const BOSS_SPEARCOMBO: MoveDef = move({
  id: 'b_spearcombo',
  name: '天罡七連刺',
  kind: 'combo',
  duration: 2,
  events: [
    sfx(0.04, 'swingHeavy', 1, 1.1),
    motion(0.1, 480, 0, 0.3),
    ...multiHits(0.2, 6, 0.16, 16, 100, { w: 200, h: 90, pierce: true, kb: { x: 320, z: 60 }, hitstop: 0.05, shake: 12, fx: 'slashIron' }),
    melee(1.3, 32, 104, { w: 230, h: 130, kb: { x: 820, z: 560 }, launch: true, hitstop: 0.17, shake: 34, fx: 'impactIron', sfx: 'hitCrit', aoe: 200 }),
    fx(1.32, 'shockRing', { scale: 3.4, color: '#ffe6a8' }),
    flash(1.3, '#fff0c0', 0.4, 0.3),
  ],
});
const BOSS_TAILSWEEP: MoveDef = move({
  id: 'b_tailsweep',
  name: '九尾橫掃',
  kind: 'combo',
  duration: 1.5,
  events: [
    sfx(0.06, 'wind', 1, 0.6),
    motion(0.2, -260, 0, 0.2),
    fx(0.3, 'slashFox', { ox: 60, oz: 80, scale: 3.2, color: '#a56bff' }),
    melee(0.4, 28, 70, { w: 320, h: 160, pierce: true, multi: 2, multiGap: 0.16, kb: { x: 780, z: 480 }, launch: true, hitstop: 0.14, shake: 30, fx: 'impactFox', sfx: 'hitCrit', aoe: 240 }),
    proj(0.5, 'foxfire', 16, { count: 10, spread: 1.6, speed: 480, oz: 70, size: 1.2, life: 2, homing: 1.4 }),
    fx(0.5, 'shockRing', { scale: 3.8, color: '#a56bff' }),
    shake(0.4, 28),
  ],
});

export const BOSSES: EnemyDef[] = [
  {
    id: 'boss_shixiao',
    name: '石魈',
    rank: '首領',
    ai: 'boss',
    atlas: 5,
    hp: 1250,
    atk: 26,
    speed: 128,
    weight: 4,
    radius: 60,
    height: 190,
    scale: 2.3,
    colors: { body: '#6a5a48', trim: '#ffc93c', skin: '#8a7a60', aura: '#ff8a3a', metal: '#d8c8a0' },
    weapon: '靈嶽巨拳',
    attacks: [
      { range: 200, cd: 2.4, windup: 0.6, move: BOSS_SLAM },
      { range: 900, cd: 7, windup: 0.6, move: BOSS_ROCKRAIN, chance: 0.5 },
      { range: 700, cd: 8, windup: 0.55, move: BOSS_CHARGE, chance: 0.4 },
    ],
    deathFx: 'bossRockCollapse',
    deathColors: ['#8a7a60', '#ffc93c', '#ff8a3a', '#3a2f24'],
    souls: [160, 220],
    boss: {
      title: '靈嶽守將',
      phases: 2,
      enrageHp: [0.5],
      intro: '守護靈嶽千年的石之巨將，因天宮墮令而甦醒。',
      quote: '山之重量，你承擔不起。',
    },
  },
  {
    id: 'boss_chijiao',
    name: '赤角焰侯',
    rank: '首領',
    ai: 'boss',
    atlas: 4,
    hp: 2100,
    atk: 32,
    speed: 148,
    weight: 4.6,
    radius: 62,
    height: 200,
    scale: 2.4,
    colors: { body: '#7a1a10', trim: '#ff6a1a', skin: '#c04a2a', aura: '#ff3b1a', metal: '#ffc93c' },
    weapon: '焰獄雙戟',
    attacks: [
      { range: 220, cd: 2.2, windup: 0.5, move: BOSS_SLAM },
      { range: 900, cd: 6, windup: 0.7, move: BOSS_FIREBEAM, chance: 0.55 },
      { range: 760, cd: 7.5, windup: 0.5, move: BOSS_CHARGE, chance: 0.45 },
      { range: 300, cd: 9, windup: 0.6, move: BOSS_TAILSWEEP, chance: 0.35 },
    ],
    deathFx: 'bossFlameNova',
    deathColors: ['#ff6a1a', '#ffc93c', '#7a1a10', '#ffe9a0'],
    souls: [240, 320],
    boss: {
      title: '焰獄雙生之主',
      phases: 3,
      enrageHp: [0.66, 0.33],
      intro: '焰獄深處的雙生魔將，半身熔岩、半身黑煙。',
      quote: '把你的骨頭，留給我的火。',
    },
  },
  {
    id: 'boss_xuanxiao',
    name: '玄霄元帥',
    rank: '首領',
    ai: 'boss',
    atlas: 1,
    hp: 3200,
    atk: 38,
    speed: 176,
    weight: 5,
    radius: 58,
    height: 205,
    scale: 2.35,
    colors: { body: '#1b2a6b', trim: '#9fe8ff', skin: '#e8dcc0', aura: '#9fe8ff', metal: '#ffe6a8' },
    weapon: '天罡雷槍',
    attacks: [
      { range: 260, cd: 2, windup: 0.42, move: BOSS_SPEARCOMBO },
      { range: 900, cd: 6.5, windup: 0.6, move: BOSS_THUNDER, chance: 0.55 },
      { range: 700, cd: 8, windup: 0.5, move: BOSS_CHARGE, chance: 0.4 },
      { range: 320, cd: 10, windup: 0.6, move: BOSS_TAILSWEEP, chance: 0.3 },
    ],
    deathFx: 'bossHolyBurst',
    deathColors: ['#9fe8ff', '#ffe6a8', '#1b2a6b', '#ffffff'],
    souls: [360, 460],
    boss: {
      title: '天宮叛將',
      phases: 3,
      enrageHp: [0.7, 0.35],
      intro: '曾鎮守九霄門的元帥，因不滿天帝降罪義賊團而叛變。',
      quote: '秩序即是正義——你們只是噪音。',
    },
  },
  {
    id: 'boss_jintian',
    name: '燼天',
    rank: '首領',
    ai: 'boss',
    atlas: 4,
    hp: 5200,
    atk: 46,
    speed: 158,
    weight: 6.5,
    radius: 76,
    height: 250,
    scale: 3,
    colors: { body: '#1a0a14', trim: '#ff3b52', skin: '#4a1a2a', aura: '#ff3b52', metal: '#ffc93c' },
    weapon: '九瞳魔戟',
    attacks: [
      { range: 300, cd: 2.6, windup: 0.55, move: BOSS_TAILSWEEP },
      { range: 1000, cd: 8, windup: 0.7, move: BOSS_METEOR, chance: 0.6 },
      { range: 900, cd: 7, windup: 0.6, move: BOSS_FIREBEAM, chance: 0.5 },
      { range: 800, cd: 9, windup: 0.6, move: BOSS_THUNDER, chance: 0.45 },
      { range: 760, cd: 8.5, windup: 0.5, move: BOSS_CHARGE, chance: 0.4 },
    ],
    deathFx: 'bossApocalypse',
    deathColors: ['#ff3b52', '#ffc93c', '#1a0a14', '#ffffff'],
    souls: [800, 1000],
    boss: {
      title: '九瞳魔皇',
      phases: 4,
      enrageHp: [0.75, 0.5, 0.25],
      intro: '被封印於天柱之下的九瞳魔皇，欲以義賊團之魂重開焚世之門。',
      quote: '渺小的人啊，來看看天的盡頭。',
      scaleMul: 1.15,
    },
  },
];

export const ENEMY_MAP: Record<string, EnemyDef> = Object.fromEntries([...ENEMIES, ...BOSSES].map((e) => [e.id, e]));
export const ALL_ENEMIES: EnemyDef[] = [...ENEMIES, ...BOSSES];

/** 菁英變體：血量、攻擊、外觀光環提升 */
export function eliteVariant(def: EnemyDef): EnemyDef {
  return {
    ...def,
    id: def.id + '_elite',
    name: '狂・' + def.name,
    rank: '菁英',
    hp: Math.round(def.hp * 2.4),
    atk: Math.round(def.atk * 1.35),
    speed: def.speed * 1.12,
    scale: def.scale * 1.22,
    radius: def.radius * 1.15,
    height: def.height * 1.15,
    souls: [def.souls[0] * 3, def.souls[1] * 3],
    colors: { ...def.colors, aura: '#ff3b52', trim: '#ff3b52' },
    deathFx: 'eliteBurst',
  };
}
