/**
 * 關卡／場景／波次資料
 * ------------------------------------------------------------------
 * 一章 = 四幕，每幕由 2~3 個「場景」組成，場景之間會有運鏡轉場與背景變化；
 * 每個場景包含數波敵人，最後一幕出現首領。
 * 無盡模式「獄塔」則以程序化方式無限加難。
 */
import type { BiomeId, SceneDef, ScenePalette, SpawnSpec, StageDef, WaveDef } from '../core/types';

const sp = (enemy: string, count: number, opts: Partial<SpawnSpec> = {}): SpawnSpec => ({ enemy, count, ...opts });
const wave = (spawns: SpawnSpec[], announce?: string, heal?: number): WaveDef => ({ spawns, announce, heal });

/* ============================ 場景調色盤 ============================ */
const PALETTES: Record<string, ScenePalette> = {
  peakDawn: {
    skyTop: '#2a2f63', skyBottom: '#ff9d5c', haze: '#ffd3a0', ground: '#7a6446', groundDark: '#3d3122',
    fog: '#ffc79a', light: '#fff2d0', tint: '#ff9a4a', tintAlpha: 0.09,
  },
  peakDay: {
    skyTop: '#1d5f8f', skyBottom: '#9fe0f0', haze: '#dff2f8', ground: '#6f7a4a', groundDark: '#333a22',
    fog: '#cfe8e0', light: '#ffffff', tint: '#7fd4ff', tintAlpha: 0.05,
  },
  peakDusk: {
    skyTop: '#2b1a44', skyBottom: '#ff6a4a', haze: '#ffa070', ground: '#5c4433', groundDark: '#2a1e16',
    fog: '#c07a6a', light: '#ffd0a0', tint: '#ff5a5a', tintAlpha: 0.12,
  },
  peakCave: {
    skyTop: '#101826', skyBottom: '#2a4a5a', haze: '#4a7a8a', ground: '#3a4250', groundDark: '#171b22',
    fog: '#5a8a9a', light: '#9fe8ff', tint: '#2ad4ff', tintAlpha: 0.14,
  },
  flameDay: {
    skyTop: '#3a0a08', skyBottom: '#ff6a1a', haze: '#ffa050', ground: '#4a2a1e', groundDark: '#1e0e08',
    fog: '#c05030', light: '#ffd08a', tint: '#ff4a1a', tintAlpha: 0.16,
  },
  flameNight: {
    skyTop: '#150407', skyBottom: '#7a1a10', haze: '#a03020', ground: '#2e1a14', groundDark: '#120705',
    fog: '#802a1a', light: '#ff8a4a', tint: '#ff2a10', tintAlpha: 0.2,
  },
  flameDeep: {
    skyTop: '#2a0606', skyBottom: '#ff3a0a', haze: '#ff8040', ground: '#3a1a10', groundDark: '#160604',
    fog: '#c04020', light: '#ffe0a0', tint: '#ff5a20', tintAlpha: 0.18,
  },
  heavenDay: {
    skyTop: '#2a7fd4', skyBottom: '#eaf6ff', haze: '#ffffff', ground: '#e8e0cc', groundDark: '#a89c82',
    fog: '#ffffff', light: '#fffbe8', tint: '#ffe6a8', tintAlpha: 0.08,
  },
  heavenDusk: {
    skyTop: '#4a2a7a', skyBottom: '#ffb070', haze: '#ffd9b0', ground: '#d8c8b0', groundDark: '#8a7a68',
    fog: '#ffc0a0', light: '#fff0d0', tint: '#ff9a5a', tintAlpha: 0.12,
  },
  heavenThrone: {
    skyTop: '#12081f', skyBottom: '#6a2a9a', haze: '#a060d0', ground: '#2a1a3a', groundDark: '#120818',
    fog: '#8a4ac0', light: '#e0b0ff', tint: '#a05aff', tintAlpha: 0.16,
  },
  void: {
    skyTop: '#05030a', skyBottom: '#3a0a1a', haze: '#6a1030', ground: '#1a0c14', groundDark: '#08040a',
    fog: '#4a0a20', light: '#ff6a8a', tint: '#ff2050', tintAlpha: 0.22,
  },
};

/* ============================ 場景定義 ============================ */
const scene = (
  id: string, name: string, biome: BiomeId, variant: number, palette: ScenePalette,
  weather: SceneDef['weather'], props: string[], waves: WaveDef[], extra: Partial<SceneDef> = {},
): SceneDef => ({ id, name, biome, variant, arenaW: 1760, palette, weather, props, waves, ...extra });

/* ---------------------------- 第一章・花果靈嶽 ---------------------------- */
const C1: SceneDef[][] = [
  // 1-1 桃林初陣
  [
    scene('c1s1', '桃林坡', 'peak', 0, PALETTES.peakDawn, 'petal', ['peach', 'lantern', 'rock', 'grass'], [
      wave([sp('imp', 4, { side: 'both' })], '第一波・嘍囉出沒'),
      wave([sp('imp', 4), sp('hound', 3, { side: 'right' })], '妖犬加入了！'),
      wave([sp('imp', 5), sp('archer', 2, { side: 'both' })], '小心遠處的弓手'),
    ], { interlude: '花瓣落滿山坡，義賊團的第一步從這裡開始。' }),
    scene('c1s2', '石橋溪谷', 'peak', 1, PALETTES.peakDay, 'petal', ['bridge', 'pine', 'rock', 'lantern'], [
      wave([sp('spear', 3), sp('imp', 3)], '骷髏槍兵封住了石橋'),
      wave([sp('ninja', 3, { side: 'both' }), sp('archer', 2)], '有影子在動——'),
      wave([sp('imp', 6), sp('bomber', 2, { side: 'right' })], '甲蟲身上的裂縫在發光！', 20),
    ], { interlude: '溪水反射著天光，橋那頭傳來骨骼摩擦的聲音。' }),
  ],
  // 1-2 靈嶽山道
  [
    scene('c2s1', '靈嶽山道', 'peak', 0, PALETTES.peakDay, 'petal', ['pine', 'stone', 'lantern', 'grass'], [
      wave([sp('imp', 5), sp('spear', 2)]),
      wave([sp('hound', 6, { side: 'both' })], '犬群包抄！'),
      wave([sp('caster', 2, { side: 'right' }), sp('imp', 5)], '術士在後面施法'),
    ]),
    scene('c2s2', '千階鳥居', 'peak', 2, PALETTES.peakDusk, 'petal', ['gate', 'lantern', 'banner', 'stone'], [
      wave([sp('spear', 4), sp('archer', 2)], '紅纓陣'),
      wave([sp('ninja', 4), sp('caster', 2)], '影與咒的夾擊'),
      wave([sp('shaman', 1, { side: 'left' }), sp('imp', 6)], '旗手出現了——先解決他！', 25),
    ], { interlude: '夕陽把鳥居染成血紅，階梯盡頭有東西在等。' }),
  ],
  // 1-3 水簾洞窟
  [
    scene('c3s1', '水簾洞口', 'peak', 1, PALETTES.peakDusk, 'rain', ['waterfall', 'rock', 'pine', 'lantern'], [
      wave([sp('imp', 6), sp('bomber', 2)]),
      wave([sp('spear', 4), sp('shaman', 1)], '咒旗插進了岩壁'),
      wave([sp('ninja', 4), sp('archer', 3, { side: 'both' })], '箭雨與影刃', 30),
    ]),
    scene('c3s2', '洞窟深處', 'peak', 3, PALETTES.peakCave, 'none', ['crystal', 'stone', 'chain', 'brazier'], [
      wave([sp('hound', 8, { side: 'both' })], '洞窟裡全是眼睛'),
      wave([sp('brute', 1), sp('imp', 5)], '石甲巨鬼！！'),
      wave([sp('caster', 3), sp('spear', 4), sp('bomber', 3)], '最後的守軍'),
    ], { interlude: '鐘乳石滴著水，深處傳來沉重的呼吸。' }),
  ],
  // 1-4 守將之巔
  [
    scene('c4s1', '靈嶽之巔', 'peak', 2, PALETTES.peakDawn, 'petal', ['stone', 'banner', 'pine', 'cloud'], [
      wave([sp('spear', 4), sp('archer', 3)]),
      wave([sp('brute', 1), sp('ninja', 4)], '巨鬼帶隊'),
    ]),
    scene('c4s2', '守將石台', 'peak', 0, PALETTES.peakDusk, 'ember', ['statue', 'stone', 'banner', 'brazier'], [
      wave([sp('imp', 6, { side: 'both' })], '甦醒吧——守將'),
    ], { boss: 'boss_shixiao', interlude: '石台震動，千年的守將睜開了眼。' }),
  ],
];

/* ---------------------------- 第二章・焰獄荒漠 ---------------------------- */
const C2: SceneDef[][] = [
  [
    scene('f1s1', '焦土邊境', 'flame', 0, PALETTES.flameDay, 'ash', ['ruin', 'bone', 'brazier', 'rock'], [
      wave([sp('imp', 5), sp('hound', 4)], '焰獄的狗不一樣'),
      wave([sp('bomber', 4, { side: 'both' }), sp('archer', 2)], '地上到處是裂縫'),
      wave([sp('spear', 4), sp('shaman', 1)], '咒旗在熱風中獵獵作響', 30),
    ]),
    scene('f1s2', '灰烬哨站', 'flame', 1, PALETTES.flameNight, 'ember', ['ruin', 'chain', 'brazier', 'banner'], [
      wave([sp('ninja', 4), sp('caster', 2)]),
      wave([sp('brute', 1), sp('imp', 6)], '巨鬼踩碎了哨站'),
      wave([sp('bomber', 5), sp('hound', 5, { side: 'both' })], '自爆連鎖！', 35),
    ]),
  ],
  [
    scene('f2s1', '骨骸峽谷', 'flame', 0, PALETTES.flameNight, 'ash', ['bone', 'rock', 'chain', 'skull'], [
      wave([sp('spear', 5), sp('archer', 3)]),
      wave([sp('hound', 7), sp('ninja', 3)], '峽谷兩側都有'),
      wave([sp('caster', 3), sp('brute', 1)], '法術與蠻力的組合', 30),
    ]),
    scene('f2s2', '墜龍遺骸', 'flame', 2, PALETTES.flameDeep, 'ember', ['bone', 'brazier', 'statue', 'chain'], [
      wave([sp('imp', 8, { side: 'both' })], '從骨頭裡爬出來的'),
      wave([sp('shaman', 2), sp('spear', 4)], '雙旗陣'),
      wave([sp('brute', 2), sp('bomber', 3)], '兩隻巨鬼！', 40),
    ], { interlude: '巨龍的肋骨插在地面，像一座白色森林。' }),
  ],
  [
    scene('f3s1', '熔岩回廊', 'flame', 2, PALETTES.flameDeep, 'ember', ['pillar', 'brazier', 'lava', 'chain'], [
      wave([sp('ninja', 5), sp('caster', 2)]),
      wave([sp('bomber', 6, { side: 'both' })], '整條回廊都在發光'),
      wave([sp('brute', 1), sp('spear', 5), sp('archer', 2)], '回廊守軍', 40),
    ]),
    scene('f3s2', '焰心熔爐', 'flame', 1, PALETTES.flameNight, 'ember', ['lava', 'pillar', 'brazier', 'statue'], [
      wave([sp('hound', 8), sp('shaman', 1)]),
      wave([sp('caster', 4), sp('ninja', 4)], '咒雷與影刃'),
      wave([sp('brute', 2), sp('imp', 8)], '熔爐全開', 45),
    ]),
  ],
  [
    scene('f4s1', '焰獄雙門', 'flame', 0, PALETTES.flameDay, 'ash', ['gate', 'statue', 'brazier', 'banner'], [
      wave([sp('spear', 5), sp('archer', 3)]),
      wave([sp('brute', 2), sp('ninja', 4)], '門前的精銳'),
    ]),
    scene('f4s2', '焰侯王座', 'flame', 2, PALETTES.flameDeep, 'ember', ['statue', 'brazier', 'chain', 'lava'], [
      wave([sp('imp', 8, { side: 'both' })], '門開了'),
    ], { boss: 'boss_chijiao', interlude: '熔岩從王座下湧出，雙生魔將站了起來。' }),
  ],
];

/* ---------------------------- 第三章・九霄天宮 ---------------------------- */
const C3: SceneDef[][] = [
  [
    scene('h1s1', '雲梯入口', 'heaven', 0, PALETTES.heavenDay, 'light', ['cloud', 'arch', 'lantern', 'lotus'], [
      wave([sp('spear', 5), sp('caster', 2)], '天兵列陣'),
      wave([sp('ninja', 5), sp('archer', 3)], '天宮也有影'),
      wave([sp('brute', 1), sp('imp', 6), sp('shaman', 1)], '天將出巡', 40),
    ]),
    scene('h1s2', '白玉石階', 'heaven', 1, PALETTES.heavenDay, 'light', ['pillar', 'lotus', 'banner', 'statue'], [
      wave([sp('caster', 4), sp('spear', 4)]),
      wave([sp('bomber', 5), sp('hound', 5, { side: 'both' })], '天火蟲群'),
      wave([sp('brute', 2), sp('archer', 3)], '重甲與遠射', 45),
    ]),
  ],
  [
    scene('h2s1', '白玉廣場', 'heaven', 0, PALETTES.heavenDusk, 'light', ['bell', 'pillar', 'lotus', 'banner'], [
      wave([sp('spear', 6), sp('ninja', 4)]),
      wave([sp('shaman', 2), sp('caster', 3)], '雙巫陣'),
      wave([sp('brute', 2), sp('bomber', 4)], '廣場震動', 50),
    ]),
    scene('h2s2', '蓮池迴廊', 'heaven', 1, PALETTES.heavenDusk, 'petal', ['lotus', 'bridge', 'lantern', 'cloud'], [
      wave([sp('hound', 9, { side: 'both' })], '池水裡有東西'),
      wave([sp('archer', 5), sp('ninja', 4)], '箭與影'),
      wave([sp('brute', 1), sp('shaman', 1), sp('imp', 8)], '迴廊守軍', 50),
    ]),
  ],
  [
    scene('h3s1', '天罡殿前', 'heaven', 2, PALETTES.heavenDusk, 'light', ['statue', 'pillar', 'banner', 'bell'], [
      wave([sp('spear', 6), sp('caster', 3)]),
      wave([sp('ninja', 6), sp('bomber', 4)], '天罡精銳'),
      wave([sp('brute', 2), sp('shaman', 2)], '雙旗雙鬼', 55),
    ]),
    scene('h3s2', '雷獄祭壇', 'heaven', 0, PALETTES.heavenThrone, 'light', ['crystal', 'statue', 'chain', 'brazier'], [
      wave([sp('caster', 5), sp('archer', 4)], '雷與箭'),
      wave([sp('brute', 3), sp('hound', 6)], '祭壇守衛全開'),
      wave([sp('shaman', 2), sp('ninja', 5), sp('bomber', 4)], '最後的天兵', 60),
    ]),
  ],
  [
    scene('h4s1', '玄霄殿門', 'heaven', 2, PALETTES.heavenThrone, 'light', ['gate', 'statue', 'banner', 'pillar'], [
      wave([sp('spear', 6), sp('brute', 1)], '殿門前的最後防線'),
      wave([sp('ninja', 5), sp('caster', 4)], '元帥的近衛'),
    ]),
    scene('h4s2', '玄霄大殿', 'heaven', 0, PALETTES.heavenThrone, 'light', ['throne', 'pillar', 'bell', 'banner'], [
      wave([sp('imp', 8, { side: 'both' })], '元帥起身了'),
    ], { boss: 'boss_xuanxiao', interlude: '大殿的雷光中，元帥的槍尖指向了你。' }),
  ],
];

/* ---------------------------- 終章・焚世天柱 ---------------------------- */
const C4: SceneDef[][] = [
  [
    scene('v1s1', '天柱裂縫', 'void', 0, PALETTES.void, 'ember', ['chain', 'crystal', 'ruin', 'brazier'], [
      wave([sp('brute', 2), sp('ninja', 5)], '裂縫深處的精銳'),
      wave([sp('caster', 5), sp('shaman', 2)], '咒雷風暴'),
      wave([sp('bomber', 6), sp('hound', 8, { side: 'both' })], '魔物洪流', 60),
    ]),
    scene('v1s2', '封印迴廊', 'void', 1, PALETTES.void, 'ash', ['statue', 'chain', 'pillar', 'crystal'], [
      wave([sp('brute', 3), sp('spear', 6)]),
      wave([sp('shaman', 2), sp('brute', 2), sp('archer', 4)], '封印守軍'),
      wave([sp('ninja', 6), sp('caster', 5), sp('bomber', 5)], '全軍出動', 70),
    ]),
  ],
  [
    scene('v2s1', '魔皇王座', 'void', 2, PALETTES.void, 'ember', ['throne', 'statue', 'brazier', 'chain'], [
      wave([sp('brute', 2), sp('shaman', 2)], '王座前的儀式'),
    ], { boss: 'boss_jintian', interlude: '九隻眼睛同時睜開——天柱開始崩塌。' }),
  ],
];

/* ============================ 關卡定義 ============================ */
export const CHAPTERS = [
  { id: 1, name: '花果靈嶽', sub: 'CHAPTER I — 靈嶽之亂', color: '#ff9d5c' },
  { id: 2, name: '焰獄荒漠', sub: 'CHAPTER II — 焰獄試煉', color: '#ff5a1a' },
  { id: 3, name: '九霄天宮', sub: 'CHAPTER III — 天宮叛將', color: '#ffe6a8' },
  { id: 4, name: '焚世天柱', sub: 'FINAL — 逆天之戰', color: '#ff2d40' },
];

export const STAGES: StageDef[] = [
  { id: '1-1', chapter: 1, index: 1, name: '桃林初陣', subtitle: '花瓣與第一滴血', desc: '義賊團集結後的第一戰，熟悉操作與連段的好去處。', biome: 'peak', scenes: C1[0], souls: 220 },
  { id: '1-2', chapter: 1, index: 2, name: '靈嶽山道', subtitle: '千階鳥居', desc: '山道上的骷髏槍兵與影忍，開始需要走位與閃避。', biome: 'peak', scenes: C1[1], souls: 280, unlockReq: { chapter: 1, index: 1 } },
  { id: '1-3', chapter: 1, index: 3, name: '水簾洞窟', subtitle: '鐘乳石之眼', desc: '洞窟中出現石甲巨鬼，學會用浮空技破解霸體。', biome: 'peak', scenes: C1[2], souls: 340, unlockReq: { chapter: 1, index: 2 } },
  { id: '1-4', chapter: 1, index: 4, name: '守將之巔', subtitle: 'BOSS — 石魈', desc: '第一章首領：靈嶽守將石魈。落石陣與山崩衝撞是致命威脅。', biome: 'peak', scenes: C1[3], souls: 520, unlockReq: { chapter: 1, index: 3 } },

  { id: '2-1', chapter: 2, index: 1, name: '焦土邊境', subtitle: '熱風中的骨頭', desc: '焰獄的第一課：爆焰甲蟲會主動衝過來自爆。', biome: 'flame', scenes: C2[0], souls: 420, unlockReq: { chapter: 1, index: 4 } },
  { id: '2-2', chapter: 2, index: 2, name: '骨骸峽谷', subtitle: '墜龍的肋骨', desc: '狹窄峽谷中的多方向包抄，考驗範圍技與走位。', biome: 'flame', scenes: C2[1], souls: 500, unlockReq: { chapter: 2, index: 1 } },
  { id: '2-3', chapter: 2, index: 3, name: '熔岩回廊', subtitle: '會呼吸的火', desc: '高密度敵群與雙巨鬼，適合測試法印流派。', biome: 'flame', scenes: C2[2], souls: 600, unlockReq: { chapter: 2, index: 2 } },
  { id: '2-4', chapter: 2, index: 4, name: '焰獄雙門', subtitle: 'BOSS — 赤角焰侯', desc: '第二章首領：焰侯的焰獄光束需要靠側移與無敵技穿越。', biome: 'flame', scenes: C2[3], souls: 860, unlockReq: { chapter: 2, index: 3 } },

  { id: '3-1', chapter: 3, index: 1, name: '雲梯入口', subtitle: '天兵的列陣', desc: '天宮守軍紀律嚴明，槍陣與法術的組合拳。', biome: 'heaven', scenes: C3[0], souls: 700, unlockReq: { chapter: 2, index: 4 } },
  { id: '3-2', chapter: 3, index: 2, name: '白玉廣場', subtitle: '蓮池迴廊', desc: '大量天火蟲與重甲兵，奧義充能的最佳舞臺。', biome: 'heaven', scenes: C3[1], souls: 800, unlockReq: { chapter: 3, index: 1 } },
  { id: '3-3', chapter: 3, index: 3, name: '天罡殿前', subtitle: '雷獄祭壇', desc: '天罡精銳全數出動，需要完整流派才能撐住。', biome: 'heaven', scenes: C3[2], souls: 920, unlockReq: { chapter: 3, index: 2 } },
  { id: '3-4', chapter: 3, index: 4, name: '玄霄大殿', subtitle: 'BOSS — 玄霄元帥', desc: '第三章首領：天罡七連刺與九霄雷獄的連段極快。', biome: 'heaven', scenes: C3[3], souls: 1300, unlockReq: { chapter: 3, index: 3 } },

  { id: '4-1', chapter: 4, index: 1, name: '天柱裂縫', subtitle: '封印迴廊', desc: '終章前哨，敵軍密度與強度都是最高等級。', biome: 'void', scenes: C4[0], souls: 1500, unlockReq: { chapter: 3, index: 4 } },
  { id: '4-2', chapter: 4, index: 2, name: '焚世王座', subtitle: 'FINAL BOSS — 燼天', desc: '九瞳魔皇燼天，四階段變化，逆天之戰的最後一擊。', biome: 'void', scenes: C4[1], souls: 3000, unlockReq: { chapter: 4, index: 1 } },
];

export const STAGE_MAP: Record<string, StageDef> = Object.fromEntries(STAGES.map((s) => [s.id, s]));

/** 關卡難度曲線：敵人血量／攻擊倍率 */
export function stageScale(stageId: string) {
  const st = STAGE_MAP[stageId];
  if (!st) return { hp: 1, atk: 1, speed: 1, souls: 1 };
  const n = (st.chapter - 1) * 4 + st.index;
  return {
    hp: 1 + (n - 1) * 0.26,
    atk: 1 + (n - 1) * 0.16,
    speed: 1 + Math.min(0.22, (n - 1) * 0.018),
    souls: 1 + (n - 1) * 0.1,
  };
}

/** 無盡獄塔：程序化產生第 n 層 */
export function endlessFloor(floor: number): SceneDef {
  const biomes: BiomeId[] = ['peak', 'flame', 'heaven', 'void'];
  const biome = biomes[Math.min(3, Math.floor((floor - 1) / 4))];
  const pal = biome === 'peak' ? PALETTES.peakDusk : biome === 'flame' ? PALETTES.flameDeep : biome === 'heaven' ? PALETTES.heavenThrone : PALETTES.void;
  const pool = ['imp', 'spear', 'ninja', 'caster', 'bomber', 'hound', 'archer', 'shaman', 'brute'];
  const diff = 1 + floor * 0.18;
  const waves: WaveDef[] = [];
  const waveCount = 3 + Math.min(3, Math.floor(floor / 3));
  for (let i = 0; i < waveCount; i++) {
    const spawns: SpawnSpec[] = [];
    const kinds = 2 + Math.min(3, Math.floor(floor / 4));
    for (let k = 0; k < kinds; k++) {
      const e = pool[(Math.random() * pool.length) | 0];
      const count = Math.max(2, Math.round((3 + floor * 0.5) / kinds));
      spawns.push(sp(e, Math.min(9, count), { side: Math.random() < 0.4 ? 'both' : undefined, elite: Math.random() < Math.min(0.4, floor * 0.04) }));
    }
    waves.push(wave(spawns, `獄塔 第 ${floor} 層 — 第 ${i + 1} 波`, i === waveCount - 1 ? 30 : 0));
  }
  const isBossFloor = floor % 5 === 0;
  return scene(`endless_${floor}`, `獄塔 第 ${floor} 層`, biome, floor % 3, pal, biome === 'flame' ? 'ember' : biome === 'heaven' ? 'light' : 'petal',
    ['statue', 'brazier', 'chain', 'crystal'], waves, {
      boss: isBossFloor ? (floor >= 20 ? 'boss_jintian' : floor >= 12 ? 'boss_xuanxiao' : floor >= 6 ? 'boss_chijiao' : 'boss_shixiao') : undefined,
      interlude: `無盡獄塔 第 ${floor} 層 · 強度 x${diff.toFixed(2)}`,
    });
}

export { PALETTES };
