/**
 * 裝備資料：六個欄位 × R / SR / SSR / UR
 * ------------------------------------------------------------------
 * SSR 以上裝備會附加「固有技」與「外觀進化」（改變氣場、拖尾、頭冠、披風、羽翼）。
 * 裝備可於據點「霄客樓」用魂魄強化等級（每級 +8% 數值，最高 10 級）。
 */
import type { EquipDef, EquipInstance, Rarity, SlotId } from '../core/types';

export const EQUIPS: EquipDef[] = [
  /* ------------------------------ 頭冠 ------------------------------ */
  {
    id: 'crown_cloth', slot: 'crown', name: '粗布頭巾', rarity: 'R', icon: 'crown',
    desc: '修行者最基礎的頭巾，聊勝於無。', mods: { hpMax: 8 }, value: 20,
  },
  {
    id: 'crown_bronze', slot: 'crown', name: '青銅小盔', rarity: 'R', icon: 'shield',
    desc: '鏽跡斑斑的青銅盔，勉強能擋一下。', mods: { armor: 0.05 }, value: 24,
  },
  {
    id: 'crown_night', slot: 'crown', name: '夜行耳飾', rarity: 'SR', icon: 'moon',
    desc: '夜色中行动更敏銳的耳飾，大幅提升精力回復。',
    mods: { staminaRegen: 1.45, staminaMax: 12, speedMul: 1.04 }, value: 120,
  },
  {
    id: 'crown_twin', slot: 'crown', name: '雙曜角飾', rarity: 'SSR', icon: 'horn',
    desc: '一金一銀兩支妖角，擊殺敵人時引發魂爆。',
    mods: { atkMul: 1.14, critChance: 0.06 }, traits: ['onKillExplode'],
    skill: { name: '固有技・雙曜衝擊', desc: '每擊殺 8 名敵人，自動引爆一次全屏魂爆（攻擊力 180%）。', passive: 'twinBurst' },
    look: { aura: '#ffc93c', crown: '#ffc93c' }, value: 420,
  },
  {
    id: 'crown_phoenix', slot: 'crown', name: '朱雀翎冠', rarity: 'SSR', icon: 'feather',
    desc: '插著朱雀尾羽的冠飾，火焰永不熄滅。',
    mods: { atkMul: 1.1, hpRegen: 1.2 }, traits: ['onHitBurn'],
    skill: { name: '固有技・翎焰護身', desc: '生命低於 30% 時自動展開焰翼，3 秒內減傷 50% 並持續灼燒貼身敵人（冷卻 25 秒）。', passive: 'phoenixWing' },
    look: { aura: '#ff5a1a', trail: '#ffb03a', wings: true }, value: 460,
  },
  {
    id: 'crown_nine', slot: 'crown', name: '九旒天冠', rarity: 'UR', icon: 'crown',
    desc: '傳說中天帝賞賜叛將之冠，九旒垂珠映照天命。',
    mods: { hpMax: 60, armor: 0.12, revives: 1, ultChargeMul: 1.25, luck: 0.2 },
    traits: ['reviveOnce'],
    skill: { name: '固有技・天命不滅', desc: '首次致死時復活並回復 60% 生命，同時清空全場敵人（每場一次）。', passive: 'divineRevive' },
    look: { aura: '#ffc93c', trail: '#fff0b8', crown: '#ffe6a8', cape: true, wings: true }, value: 1600,
  },

  /* ------------------------------ 戰袍 ------------------------------ */
  {
    id: 'armor_monk', slot: 'armor', name: '修行僧衣', rarity: 'R', icon: 'scroll',
    desc: '樸素的僧衣，意外地耐打。', mods: { hpMax: 14 }, value: 22,
  },
  {
    id: 'armor_leather', slot: 'armor', name: '硬皮戰甲', rarity: 'R', icon: 'shield',
    desc: '獸皮鞣製的輕甲。', mods: { armor: 0.06, hpMax: 6 }, value: 26,
  },
  {
    id: 'armor_jade', slot: 'armor', name: '玉鱗戰袍', rarity: 'SR', icon: 'drop',
    desc: '以玉鱗編成的戰袍，被打中會發出清脆聲響。',
    mods: { armor: 0.14, hpMax: 30, thorns: 0.15 }, value: 140,
  },
  {
    id: 'armor_flame', slot: 'armor', name: '焰心護甲', rarity: 'SSR', icon: 'flame',
    desc: '內部燃燒著不滅焰心的重甲，靠近者皆被灼傷。',
    mods: { hpMax: 55, armor: 0.16, atkMul: 1.08 }, traits: ['thornAura'],
    skill: { name: '固有技・焰心領域', desc: '周身常駐焰心領域，半徑 180 內敵人每秒受到攻擊力 35% 的火焰傷害。', passive: 'flameField' },
    look: { aura: '#ff3b1a', trail: '#ff8a3a', cape: true }, value: 480,
  },
  {
    id: 'armor_frost', slot: 'armor', name: '霜翎羽衣', rarity: 'SSR', icon: 'snow',
    desc: '以靈鶴落羽織成的輕衣，行走時無聲無息。',
    mods: { dodgeChance: 0.16, speedMul: 1.12, hpMax: 25 }, traits: ['perfectDodge'],
    skill: { name: '固有技・見切羽舞', desc: '完美閃避成功後 2 秒內暴擊率 +50%、攻速 +25%。', passive: 'frostDance' },
    look: { aura: '#9fe8ff', trail: '#eaf6ff', wings: true }, value: 470,
  },
  {
    id: 'armor_void', slot: 'armor', name: '虛空魔鎧', rarity: 'UR', icon: 'skull',
    desc: '以虛空鍛造的黑鎧，被擊中的瞬間會吞噬傷害。',
    mods: { hpMax: 90, armor: 0.24, shieldMax: 60, shieldOnWave: 40, lifesteal: 0.04 },
    traits: ['waveShield'],
    skill: { name: '固有技・虛空吞食', desc: '護盾存在時，所有傷害先由護盾吸收，並將吸收量的 40% 轉為奧義充能。', passive: 'voidDevour' },
    look: { aura: '#a56bff', trail: '#5b2a86', cape: true }, value: 1650,
  },

  /* ------------------------------ 手甲 ------------------------------ */
  {
    id: 'bracer_cloth', slot: 'bracer', name: '麻布護腕', rarity: 'R', icon: 'chain',
    desc: '纏了幾圈麻布，至少不會磨破皮。', mods: { atkMul: 1.04 }, value: 18,
  },
  {
    id: 'bracer_iron', slot: 'bracer', name: '鐵片手甲', rarity: 'R', icon: 'shield',
    desc: '鐵片縫製的手甲。', mods: { atkMul: 1.06, armor: 0.03 }, value: 22,
  },
  {
    id: 'bracer_tiger', slot: 'bracer', name: '虎嘯護臂', rarity: 'SR', icon: 'fist',
    desc: '揮拳時會發出虎嘯聲，暴擊率提升。',
    mods: { critChance: 0.1, critDmg: 0.25, atkMul: 1.06 }, value: 150,
  },
  {
    id: 'bracer_thunder', slot: 'bracer', name: '雷紋手甲', rarity: 'SSR', icon: 'bolt',
    desc: '刻著古老雷紋的手甲，命中時竄出電弧。',
    mods: { atkMul: 1.16, critChance: 0.05 }, traits: ['chainLightning'],
    skill: { name: '固有技・雷紋爆發', desc: '連擊每達 15 段，釋放一次雷紋爆發，對範圍內敵人造成攻擊力 220% 的雷傷並麻痺 1 秒。', passive: 'thunderBurst' },
    look: { aura: '#9fe8ff', trail: '#dff6ff' }, value: 490,
  },
  {
    id: 'bracer_blood', slot: 'bracer', name: '血誓腕環', rarity: 'SSR', icon: 'drop',
    desc: '以自身鮮血立下誓約的腕環。',
    mods: { lifesteal: 0.07, atkMul: 1.12, hpRegen: 0.8 }, traits: ['onHitBleed'],
    skill: { name: '固有技・血之收割', desc: '對流血中的敵人傷害 +30%，擊殺流血敵人回復 8 點生命。', passive: 'bloodHarvest' },
    look: { aura: '#ff2d40', trail: '#7a1020' }, value: 500,
  },
  {
    id: 'bracer_god', slot: 'bracer', name: '神力縛腕', rarity: 'UR', icon: 'fist',
    desc: '封印著古神力量的縛腕，戴上後拳頭會自己找敵人。',
    mods: { atkMul: 1.3, critDmg: 0.6, comboDmg: 0.02, hitstopMul: 1.3 },
    traits: ['onHitShockwave', 'giantSlayer'],
    skill: { name: '固有技・神拳・破天', desc: '第三段普攻必定暴擊並產生破天衝擊波，傷害隨連擊層數提升（每層 +2%，上限 60%）。', passive: 'godFist' },
    look: { aura: '#ffc93c', trail: '#ff3b52' }, value: 1700,
  },

  /* ------------------------------ 腰佩 ------------------------------ */
  {
    id: 'belt_rope', slot: 'belt', name: '草繩腰帶', rarity: 'R', icon: 'chain',
    desc: '一條草繩，能掛東西就好。', mods: { staminaMax: 8 }, value: 16,
  },
  {
    id: 'belt_leather', slot: 'belt', name: '皮革腰封', rarity: 'R', icon: 'shield',
    desc: '結實的皮革腰封。', mods: { hpMax: 10, staminaMax: 6 }, value: 20,
  },
  {
    id: 'belt_soul', slot: 'belt', name: '魂囊腰佩', rarity: 'SR', icon: 'coin',
    desc: '能自動吸取魂魄的法囊。',
    mods: { soulMul: 1.3, pickupRadius: 90 }, value: 130,
  },
  {
    id: 'belt_star', slot: 'belt', name: '星宿玉帶', rarity: 'SSR', icon: 'star',
    desc: '對應二十八宿的玉帶，會牽引命運。',
    mods: { luck: 0.45, soulMul: 1.2, ultChargeMul: 1.15 },
    skill: { name: '固有技・星宿敕令', desc: '每次選擇法印時多一個選項，且有 25% 機率提升其稀有度。', passive: 'starDecree' },
    look: { aura: '#b98bff', trail: '#e3ccff' }, value: 520,
  },
  {
    id: 'belt_king', slot: 'belt', name: '鬼王腰甲', rarity: 'SSR', icon: 'horn',
    desc: '鬼王遺落的腰甲，沉重卻令人安心。',
    mods: { armor: 0.18, hpMax: 50, kbMul: 0.25 },
    skill: { name: '固有技・不動霸體', desc: '受到傷害時有 35% 機率完全不進入硬直，且反傷 30%。', passive: 'immovable' },
    look: { aura: '#ff3b52', trail: '#7a1020' }, value: 510,
  },
  {
    id: 'belt_heaven', slot: 'belt', name: '天綱玉帶', rarity: 'UR', icon: 'circle',
    desc: '以天綱織成的玉帶，繫上後萬法歸宗。',
    mods: { atkMul: 1.15, hpMax: 45, staminaMax: 25, cdReduce: 0.15, soulMul: 1.35, luck: 0.3 },
    traits: ['secondWind'],
    skill: { name: '固有技・天綱共振', desc: '所有法印效果提升 15%，每波結束時回復 15% 生命與全部精力。', passive: 'heavenResonance' },
    look: { aura: '#ffe6a8', trail: '#ffc93c', cape: true }, value: 1750,
  },

  /* ------------------------------ 足具 ------------------------------ */
  {
    id: 'boots_straw', slot: 'boots', name: '草鞋', rarity: 'R', icon: 'boot',
    desc: '走長路必備。', mods: { speedMul: 1.05 }, value: 16,
  },
  {
    id: 'boots_leather', slot: 'boots', name: '硬皮靴', rarity: 'R', icon: 'boot',
    desc: '耐磨的皮靴。', mods: { speedMul: 1.04, armor: 0.03 }, value: 20,
  },
  {
    id: 'boots_wind', slot: 'boots', name: '御風靴', rarity: 'SR', icon: 'wing',
    desc: '靴底刻著風咒，跑起來像被推著走。',
    mods: { speedMul: 1.14, dashCdMul: 0.82, jumpMul: 1.08 }, value: 145,
  },
  {
    id: 'boots_flame', slot: 'boots', name: '焰影踏', rarity: 'SSR', icon: 'flame',
    desc: '每一步都留下焰痕的戰靴。',
    mods: { speedMul: 1.1, dashCdMul: 0.75, atkMul: 1.06 }, traits: ['dashFireTrail', 'dashStrike'],
    skill: { name: '固有技・焰影連踏', desc: '連續衝刺時冷卻遞減（最多 -50%），且衝刺傷害每次疊加 15%。', passive: 'flameStep' },
    look: { aura: '#ff6a1a', trail: '#ff2d40' }, value: 500,
  },
  {
    id: 'boots_cloud', slot: 'boots', name: '踏雲履', rarity: 'SSR', icon: 'cloud',
    desc: '踩在雲上的感覺，就是這麼輕。',
    mods: { jumpMul: 1.28, speedMul: 1.08, airDmg: 0.25 }, traits: ['airComboMaster'],
    skill: { name: '固有技・凌雲三跳', desc: '獲得第三段跳躍，且空中攻擊可無限連段（滞空時）。', passive: 'cloudStep' },
    look: { aura: '#eaf6ff', trail: '#9fe8ff', wings: true }, value: 520,
  },
  {
    id: 'boots_god', slot: 'boots', name: '神行太保靴', rarity: 'UR', icon: 'bolt',
    desc: '傳說中日行千里的神靴，穿上後連影子都追不上。',
    mods: { speedMul: 1.24, dashCdMul: 0.6, jumpMul: 1.2, dodgeChance: 0.1 },
    traits: ['perfectDodge', 'dashStrike'],
    skill: { name: '固有技・神行無影', desc: '衝刺後 0.6 秒內完全無敵且移動不留殘影；完美閃避觸發 2 秒子彈時間。', passive: 'godStep' },
    look: { aura: '#dff6ff', trail: '#9fe8ff' }, value: 1720,
  },

  /* ------------------------------ 法器 ------------------------------ */
  {
    id: 'relic_beads', slot: 'relic', name: '念珠', rarity: 'R', icon: 'orb',
    desc: '靜心用的念珠。', mods: { hpRegen: 0.4 }, value: 18,
  },
  {
    id: 'relic_talisman', slot: 'relic', name: '護身符', rarity: 'R', icon: 'scroll',
    desc: '廟口求來的護身符，好像有點用。', mods: { armor: 0.04, shieldMax: 10 }, value: 22,
  },
  {
    id: 'relic_mirror', slot: 'relic', name: '照妖鏡', rarity: 'SR', icon: 'eye',
    desc: '能照出妖怪弱點的銅鏡。',
    mods: { critChance: 0.09, critDmg: 0.3, executeBelow: 0.1, executeMul: 1.4 }, value: 160,
  },
  {
    id: 'relic_bell', slot: 'relic', name: '招魂鈴', rarity: 'SR', icon: 'bell',
    desc: '鈴聲一響，魂魄匯聚。',
    mods: { ultChargeMul: 1.35, soulMul: 1.15 }, value: 170,
  },
  {
    id: 'relic_gourd', slot: 'relic', name: '靈葫蘆', rarity: 'SSR', icon: 'drop',
    desc: '裝著靈藥的葫蘆，關鍵時刻會自己打開。',
    mods: { hpMax: 40, hpRegen: 1.5, shieldMax: 40, healOnKill: 2 },
    skill: { name: '固有技・靈藥回春', desc: '生命首次低於 25% 時，葫蘆自動回滿 50% 生命並清除所有負面狀態（每場一次）。', passive: 'gourdHeal' },
    look: { aura: '#7cb35f', trail: '#a3d977' }, value: 540,
  },
  {
    id: 'relic_seal', slot: 'relic', name: '逆天璽', rarity: 'UR', icon: 'crown',
    desc: '刻著「逆天」二字的古璽，據說曾蓋過天帝的詔書。',
    mods: { atkMul: 1.22, critChance: 0.1, critDmg: 0.5, ultChargeMul: 1.4, cdReduce: 0.2, hpMax: 40 },
    traits: ['summonShade', 'timeSlowOnUlt'],
    skill: { name: '固有技・逆天改命', desc: '召喚影武者共同作戰；奧義施放後 4 秒子彈時間，且奧義傷害 +40%。', passive: 'reverseFate' },
    look: { aura: '#ff2d40', trail: '#ffc93c', cape: true, wings: true }, value: 1900,
  },
];

export const EQUIP_MAP: Record<string, EquipDef> = Object.fromEntries(EQUIPS.map((e) => [e.id, e]));
export const EQUIP_BY_SLOT: Record<SlotId, EquipDef[]> = {
  crown: [], armor: [], bracer: [], belt: [], boots: [], relic: [],
};
for (const e of EQUIPS) EQUIP_BY_SLOT[e.slot].push(e);

export const RARITY_WEIGHTS: Record<Rarity, number> = { R: 52, SR: 30, SSR: 15, UR: 3 };

/** 寶匣抽取：依幸運值決定稀有度，再從該稀有度池隨機挑一件 */
export function rollEquip(luck = 0, guarantee?: Rarity): EquipDef {
  let rarity: Rarity;
  if (guarantee) rarity = guarantee;
  else {
    const l = Math.max(0, luck);
    const w = {
      R: Math.max(4, RARITY_WEIGHTS.R - l * 30),
      SR: RARITY_WEIGHTS.SR + l * 6,
      SSR: RARITY_WEIGHTS.SSR + l * 15,
      UR: RARITY_WEIGHTS.UR + l * 9,
    };
    const total = w.R + w.SR + w.SSR + w.UR;
    let r = Math.random() * total;
    rarity = 'R';
    for (const k of ['R', 'SR', 'SSR', 'UR'] as Rarity[]) {
      r -= w[k];
      if (r <= 0) { rarity = k; break; }
    }
  }
  let pool = EQUIPS.filter((e) => e.rarity === rarity);
  if (!pool.length) pool = EQUIPS.filter((e) => e.rarity === 'R');
  return pool[(Math.random() * pool.length) | 0];
}

/** 裝備等級加成：每級 +8% */
export const equipLevelMul = (lvl: number) => 1 + (lvl - 1) * 0.08;
export const equipUpgradeCost = (lvl: number, rarity: Rarity) => {
  const base = { R: 60, SR: 160, SSR: 420, UR: 1100 }[rarity];
  return Math.round(base * Math.pow(1.55, lvl - 1));
};

let uidCounter = 1;
export function makeEquipInstance(def: EquipDef, level = 1): EquipInstance {
  return { uid: `e${Date.now().toString(36)}_${uidCounter++}`, def: def.id, level };
}

/** 取得某稀有度以上的所有裝備（用於图鉴顯示） */
export const equipsOfRarity = (r: Rarity) => EQUIPS.filter((e) => e.rarity === r);
