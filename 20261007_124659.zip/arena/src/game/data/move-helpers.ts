/**
 * 招式時間軸建構工具
 * ------------------------------------------------------------------
 * 所有角色／敵兵的招式都以「事件時間軸」描述，
 * 由 entities 系統的 MoveRunner 依時間推進並觸發判定、特效、位移、音效。
 * 這裡提供簡潔的建造函式，讓資料檔能以宣告式方式撰寫大量招式。
 */
import type { FxId, MoveDef, MoveEvent, ProjId, SfxId } from '../core/types';

export interface MeleeOpts {
  dur?: number;
  oy?: number;
  w?: number;
  h?: number;
  kb?: { x?: number; y?: number; z?: number };
  hitstop?: number;
  shake?: number;
  launch?: boolean;
  multi?: number;
  multiGap?: number;
  pierce?: boolean;
  aoe?: number;
  fx?: FxId;
  sfx?: SfxId;
}

/** 近戰判定事件 */
export function melee(t: number, dmg: number, ox: number, opts: MeleeOpts = {}): MoveEvent {
  return {
    t,
    type: 'hit',
    dur: opts.dur ?? 0.12,
    dmg,
    ox,
    oy: opts.oy ?? 0,
    w: opts.w ?? 96,
    h: opts.h ?? 92,
    kb: { x: opts.kb?.x ?? 210, y: opts.kb?.y ?? 0, z: opts.kb?.z ?? 40 },
    hitstop: opts.hitstop ?? 0.055,
    shake: opts.shake ?? 6,
    launch: opts.launch,
    multi: opts.multi,
    multiGap: opts.multiGap,
    pierce: opts.pierce,
    aoe: opts.aoe,
    fx: opts.fx ?? 'impactFlame',
    sfx: opts.sfx ?? 'hit',
  } as MoveEvent;
}

export interface ProjOpts {
  count?: number;
  spread?: number;
  speed?: number;
  ox?: number;
  oy?: number;
  oz?: number;
  fx?: FxId;
  sfx?: SfxId;
  homing?: number;
  size?: number;
  life?: number;
}

/** 投射物事件 */
export function proj(t: number, id: ProjId, dmg: number, opts: ProjOpts = {}): MoveEvent {
  return { t, type: 'proj', proj: id, dmg, ...opts } as MoveEvent;
}

/** 純視覺特效事件 */
export function fx(t: number, id: FxId, opts: { ox?: number; oy?: number; oz?: number; scale?: number; color?: string } = {}): MoveEvent {
  return { t, type: 'fx', fx: id, ...opts } as MoveEvent;
}

export function sfx(t: number, id: SfxId, vol = 1, rate = 1): MoveEvent {
  return { t, type: 'sfx', sfx: id, vol, rate } as MoveEvent;
}

/** 位移事件（衝刺、跳躍、後撤） */
export function motion(t: number, vx: number, vz = 0, dur = 0.14, vy = 0): MoveEvent {
  return { t, type: 'move', vx, vz, vy, dur } as MoveEvent;
}

export function shake(t: number, amount: number): MoveEvent {
  return { t, type: 'shake', amount } as MoveEvent;
}

export function flash(t: number, color = '#ffffff', alpha = 0.5, dur = 0.18): MoveEvent {
  return { t, type: 'flash', color, alpha, dur } as MoveEvent;
}

/** 組出完整招式定義，事件自動依時間排序 */
export function move(def: Omit<MoveDef, 'events'> & { events: MoveEvent[] }): MoveDef {
  return { ...def, events: [...def.events].sort((a, b) => a.t - b.t) };
}

/** 多段連擊的通用產生器：n 段，每段間隔 gap */
export function multiHits(
  startT: number,
  n: number,
  gap: number,
  dmg: number,
  ox: number,
  opts: MeleeOpts = {},
): MoveEvent[] {
  const out: MoveEvent[] = [];
  for (let i = 0; i < n; i++) {
    out.push(
      melee(startT + i * gap, dmg, ox + (i % 2 === 0 ? 0 : 10), {
        ...opts,
        kb: { x: (opts.kb?.x ?? 180) * (i === n - 1 ? 1.6 : 0.75), y: opts.kb?.y ?? 0, z: opts.kb?.z ?? 20 },
        hitstop: opts.hitstop ?? 0.04,
        shake: (opts.shake ?? 5) * (i === n - 1 ? 1.8 : 1),
      }),
    );
    out.push(sfx(startT + i * gap - 0.07, opts.sfx ?? 'swing', 0.7, 1 + i * 0.06));
  }
  return out;
}
