/**
 * 可操作部隊資料（六位原創角色）
 * ------------------------------------------------------------------
 * 每位角色擁有：三段地面連段、浮空技、空中連段、兩種仙術、一套奧義演出。
 * 招式全部以事件時間軸描述，新增角色只要照此格式擴充即可。
 */
import type { HeroDef, MoveDef } from '../core/types';
import { flash, fx, melee, motion, move, multiHits, proj, shake, sfx } from './move-helpers';

/* ============================== 一號・燐 ============================== */
const LIN_COMBO_1: MoveDef = move({
  id: 'lin_c1',
  name: '焰牙拳',
  kind: 'combo',
  duration: 0.36,
  next: 'lin_c2',
  tag: '普攻一段',
  events: [
    sfx(0.02, 'swing', 0.6, 1.1),
    fx(0.08, 'slashFlame', { ox: 52, oz: 62, scale: 0.8 }),
    melee(0.1, 11, 58, { w: 96, h: 84, kb: { x: 190, z: 20 }, hitstop: 0.05, shake: 5, fx: 'impactFlame' }),
    motion(0.06, 220, 0, 0.12),
  ],
});
const LIN_COMBO_2: MoveDef = move({
  id: 'lin_c2',
  name: '裂空迴踢',
  kind: 'combo',
  duration: 0.4,
  next: 'lin_c3',
  tag: '普攻二段',
  events: [
    sfx(0.02, 'swing', 0.7, 1.0),
    motion(0.05, 260, 0, 0.14),
    fx(0.1, 'slashWind', { ox: 56, oz: 56, scale: 0.95 }),
    melee(0.13, 13, 62, { w: 108, h: 90, kb: { x: 240, z: 40 }, hitstop: 0.055, shake: 7, fx: 'impactFlame' }),
  ],
});
const LIN_COMBO_3: MoveDef = move({
  id: 'lin_c3',
  name: '焰旋棍・崩',
  kind: 'combo',
  duration: 0.62,
  next: null,
  tag: '普攻三段',
  events: [
    sfx(0.02, 'swingHeavy', 0.8),
    motion(0.06, 300, 0, 0.2),
    fx(0.1, 'chargeAura', { oz: 60, scale: 0.7, color: '#ff7a1a' }),
    ...multiHits(0.14, 3, 0.09, 8, 58, { w: 118, h: 104, pierce: true, hitstop: 0.035, shake: 5, fx: 'impactFlame', sfx: 'hit' }),
    melee(0.44, 22, 66, { w: 140, h: 112, kb: { x: 520, z: 320 }, launch: true, hitstop: 0.11, shake: 16, fx: 'impactFlame', sfx: 'hitHeavy', aoe: 70 }),
    shake(0.44, 14),
    fx(0.46, 'shockRing', { oz: 60, scale: 1.1, color: '#ffc93c' }),
  ],
});
const LIN_LAUNCH: MoveDef = move({
  id: 'lin_launch',
  name: '昇焰踢',
  kind: 'launcher',
  duration: 0.52,
  tag: '浮空技',
  events: [
    sfx(0.02, 'swingHeavy', 0.9, 1.2),
    motion(0.04, 120, 380, 0.3),
    fx(0.08, 'slashFlame', { ox: 40, oz: 90, scale: 1.3, color: '#ffb03a' }),
    melee(0.1, 16, 48, { oy: 40, w: 96, h: 150, kb: { x: 120, z: 760 }, launch: true, hitstop: 0.09, shake: 12, fx: 'impactFlame', sfx: 'hitHeavy' }),
    fx(0.12, 'groundCrack', { scale: 0.6 }),
  ],
});
const LIN_AIR_1: MoveDef = move({
  id: 'lin_a1',
  name: '空牙連斬',
  kind: 'air',
  airOnly: true,
  duration: 0.34,
  next: 'lin_a2',
  events: [
    sfx(0.02, 'swing', 0.6, 1.2),
    fx(0.07, 'slashFlame', { ox: 50, oz: 0, scale: 0.8 }),
    melee(0.09, 10, 56, { oy: -10, w: 104, h: 84, kb: { x: 150, z: 30 }, hitstop: 0.04, shake: 4 }),
  ],
});
const LIN_AIR_2: MoveDef = move({
  id: 'lin_a2',
  name: '焰舞雙踢',
  kind: 'air',
  airOnly: true,
  duration: 0.44,
  next: null,
  events: [
    sfx(0.02, 'swing', 0.7, 1.1),
    ...multiHits(0.08, 2, 0.1, 9, 54, { oy: -10, w: 110, h: 90, kb: { x: 200, z: -60 }, hitstop: 0.045, shake: 6 }),
    fx(0.2, 'shockRing', { oz: 10, scale: 0.7, color: '#ff7a1a' }),
  ],
});
/** T0 招式：俯衝爆擊踢 —— 下落高度越高傷害越高（combat 依 tag 加成） */
const LIN_DIVE: MoveDef = move({
  id: 'lin_dive',
  name: '俯衝爆擊踢',
  kind: 'air',
  airOnly: true,
  duration: 0.7,
  tag: 'dive',
  desc: '空中向下猛踹，墜落越高傷害越高，落地引發爆焰。',
  events: [
    sfx(0.0, 'charge', 0.7),
    motion(0.02, 260, -1500, 0.5),
    fx(0.04, 'dashGhost', { scale: 1.1, color: '#ff5a1a' }),
    melee(0.1, 26, 40, { oy: -30, w: 92, h: 120, kb: { x: 260, z: -300 }, hitstop: 0.12, shake: 20, fx: 'impactFlame', sfx: 'hitHeavy', aoe: 130 }),
    flash(0.1, '#ff8a2a', 0.45, 0.22),
    shake(0.1, 22),
    fx(0.11, 'groundCrack', { scale: 1.2 }),
    fx(0.13, 'shockRing', { scale: 1.6, color: '#ffc93c' }),
  ],
});
const LIN_SKILL_A: MoveDef = move({
  id: 'lin_sa',
  name: '焰旋突進',
  kind: 'skill',
  duration: 0.78,
  cd: 6.5,
  stamina: 22,
  invuln: [0.05, 0.62],
  desc: '旋轉靈猿棍突進，多段撕裂敵人，突進期間無敵。',
  events: [
    sfx(0.0, 'fire', 0.8),
    sfx(0.05, 'swingHeavy', 0.9, 0.8),
    motion(0.03, 620, 0, 0.5),
    fx(0.04, 'chargeAura', { oz: 60, scale: 1.2, color: '#ff5a1a' }),
    ...multiHits(0.1, 5, 0.09, 9, 52, { w: 126, h: 110, pierce: true, kb: { x: 140, z: 60 }, hitstop: 0.03, shake: 5, fx: 'slashFlame' }),
    melee(0.6, 20, 62, { w: 140, h: 120, kb: { x: 620, z: 380 }, launch: true, hitstop: 0.1, shake: 18, fx: 'impactFlame', sfx: 'hitHeavy', aoe: 90 }),
    fx(0.62, 'shockRing', { scale: 1.3, color: '#ff7a1a' }),
  ],
});
const LIN_SKILL_B: MoveDef = move({
  id: 'lin_sb',
  name: '瞬影三連斬',
  kind: 'skill',
  duration: 0.86,
  cd: 9,
  stamina: 30,
  invuln: [0.0, 0.8],
  desc: '化作殘影瞬身三段斬擊，全程無敵，最後一斬引爆焰柱。',
  events: [
    sfx(0.0, 'dash', 0.9),
    fx(0.0, 'dashGhost', { scale: 1.2, color: '#ff2d40' }),
    motion(0.02, 900, 0, 0.16),
    melee(0.12, 14, 60, { w: 120, h: 100, kb: { x: 90, z: 40 }, pierce: true, hitstop: 0.05, shake: 8, fx: 'slashFlame' }),
    fx(0.24, 'dashGhost', { scale: 1.1, color: '#ffc93c' }),
    motion(0.26, -420, 0, 0.12),
    melee(0.34, 14, 54, { w: 120, h: 100, kb: { x: -90, z: 40 }, pierce: true, hitstop: 0.05, shake: 8, fx: 'slashWind' }),
    fx(0.48, 'dashGhost', { scale: 1.3, color: '#ff2d40' }),
    motion(0.5, 1050, 0, 0.14),
    melee(0.6, 30, 66, { w: 150, h: 130, kb: { x: 760, z: 420 }, launch: true, hitstop: 0.14, shake: 24, fx: 'impactFlame', sfx: 'hitCrit', aoe: 120 }),
    flash(0.6, '#ffb03a', 0.5, 0.24),
    fx(0.62, 'shockRing', { scale: 1.8, color: '#ff2d40' }),
    fx(0.66, 'groundCrack', { scale: 1 }),
  ],
});

const LIN: HeroDef = {
  id: 'lin',
  name: '燐',
  title: '焰心猿・叛逆之刃',
  style: '速度',
  tribe: '焰猿妖族',
  desc: '靈猿棍法與熾焰腿技的高速戰士。跳得越高、墜得越狠，俯衝爆擊踢能一口氣砸穿敵陣。',
  quote: '天要壓我？那就把天也一起燒了。',
  atlas: 0,
  palette: { main: '#e8102e', trim: '#ffc93c', skin: '#f7c99a', hair: '#ff4a22', aura: '#ff7a1a', dark: '#3d0a12', metal: '#e6ecf5' },
  base: { hp: 118, stamina: 100, speed: 352, jump: 800, atk: 12, weight: 1 },
  combo: [LIN_COMBO_1, LIN_COMBO_2, LIN_COMBO_3],
  air: [LIN_AIR_1, LIN_AIR_2, LIN_DIVE],
  skillA: LIN_SKILL_A,
  skillB: LIN_SKILL_B,
  weapon: '靈猿棍',
  ultName: '焚天百裂蹴',
  ultKanji: ['焚', '天', '百', '裂', '蹴'],
  ultDesc: '化身熾焰隕星，百段墜踢轟炸全場，終以巨猿焰相一擊定音。',
  unlockCost: 0,
  unlockReq: '初始成員',
};
LIN.air.push(LIN_LAUNCH);

/* ============================== 二號・磐牙 ============================== */
const PAN_COMBO_1: MoveDef = move({
  id: 'pan_c1',
  name: '碎山橫掃',
  kind: 'combo',
  duration: 0.5,
  next: 'pan_c2',
  events: [
    sfx(0.03, 'swingHeavy', 0.8, 0.85),
    motion(0.06, 180, 0, 0.16),
    fx(0.12, 'slashRock', { ox: 62, oz: 60, scale: 1.2 }),
    melee(0.16, 18, 68, { w: 150, h: 110, kb: { x: 320, z: 40 }, hitstop: 0.08, shake: 10, fx: 'impactRock', sfx: 'hitHeavy' }),
  ],
});
const PAN_COMBO_2: MoveDef = move({
  id: 'pan_c2',
  name: '逆刃挑擊',
  kind: 'combo',
  duration: 0.54,
  next: 'pan_c3',
  events: [
    sfx(0.03, 'swingHeavy', 0.85, 0.9),
    fx(0.14, 'slashIron', { ox: 58, oz: 80, scale: 1.25 }),
    melee(0.18, 20, 62, { oy: 30, w: 140, h: 140, kb: { x: 180, z: 620 }, launch: true, hitstop: 0.09, shake: 12, fx: 'impactRock', sfx: 'hitHeavy' }),
    motion(0.1, 120, 0, 0.14),
  ],
});
const PAN_COMBO_3: MoveDef = move({
  id: 'pan_c3',
  name: '嶽崩・大回旋',
  kind: 'combo',
  duration: 0.86,
  next: null,
  events: [
    sfx(0.04, 'charge', 0.7, 0.7),
    fx(0.1, 'chargeAura', { oz: 70, scale: 1.3, color: '#c8a05a' }),
    motion(0.2, 240, 0, 0.4),
    sfx(0.2, 'swingHeavy', 1, 0.7),
    ...multiHits(0.26, 4, 0.12, 12, 60, { w: 176, h: 130, pierce: true, kb: { x: 200, z: 60 }, hitstop: 0.05, shake: 9, fx: 'slashRock' }),
    melee(0.72, 34, 70, { w: 190, h: 150, kb: { x: 820, z: 460 }, launch: true, hitstop: 0.16, shake: 26, fx: 'impactRock', sfx: 'hitCrit', aoe: 140 }),
    flash(0.72, '#ffd8a0', 0.4, 0.26),
    fx(0.74, 'shockRing', { scale: 2, color: '#e0a558' }),
    fx(0.76, 'groundCrack', { scale: 1.5 }),
    shake(0.72, 24),
  ],
});
const PAN_LAUNCH: MoveDef = move({
  id: 'pan_launch',
  name: '獠牙上挑',
  kind: 'launcher',
  duration: 0.6,
  events: [
    sfx(0.02, 'swingHeavy', 0.9, 0.8),
    motion(0.05, 140, 300, 0.3),
    melee(0.12, 22, 50, { oy: 40, w: 120, h: 160, kb: { x: 130, z: 880 }, launch: true, hitstop: 0.1, shake: 14, fx: 'impactRock', sfx: 'hitHeavy' }),
    fx(0.14, 'groundCrack', { scale: 0.9 }),
  ],
});
const PAN_AIR_1: MoveDef = move({
  id: 'pan_a1',
  name: '空中砸斧',
  kind: 'air',
  airOnly: true,
  duration: 0.44,
  next: 'pan_a2',
  events: [
    sfx(0.02, 'swingHeavy', 0.8, 0.9),
    fx(0.08, 'slashIron', { ox: 46, oz: -10, scale: 1.1 }),
    melee(0.1, 17, 54, { oy: -20, w: 130, h: 110, kb: { x: 200, z: -260 }, hitstop: 0.07, shake: 9, fx: 'impactRock' }),
  ],
});
const PAN_AIR_2: MoveDef = move({
  id: 'pan_a2',
  name: '隕嶽墜擊',
  kind: 'air',
  airOnly: true,
  duration: 0.8,
  tag: 'dive',
  desc: '抱著巨斧垂直墜落，落地造成大范围地震波。',
  events: [
    sfx(0.0, 'charge', 0.8, 0.6),
    motion(0.02, 120, -1700, 0.5),
    fx(0.04, 'dashGhost', { scale: 1.4, color: '#c8a05a' }),
    melee(0.12, 34, 40, { oy: -40, w: 130, h: 150, kb: { x: 200, z: -400 }, hitstop: 0.16, shake: 26, fx: 'impactRock', sfx: 'hitCrit', aoe: 170 }),
    flash(0.12, '#ffe6b0', 0.5, 0.3),
    fx(0.14, 'shockRing', { scale: 2.2, color: '#e0a558' }),
    fx(0.16, 'groundCrack', { scale: 1.8 }),
    shake(0.12, 28),
  ],
});
const PAN_SKILL_A: MoveDef = move({
  id: 'pan_sa',
  name: '巨嶽震波',
  kind: 'skill',
  duration: 0.92,
  cd: 7.5,
  stamina: 28,
  desc: '以斧重擊大地，掀起前進的岩浪，擊飛路徑上所有敵人。',
  events: [
    sfx(0.02, 'charge', 0.9, 0.75),
    fx(0.1, 'chargeAura', { oz: 50, scale: 1.4, color: '#e0a558' }),
    motion(0.2, -140, 0, 0.12),
    sfx(0.3, 'explode', 0.9, 0.7),
    melee(0.32, 30, 60, { w: 200, h: 140, kb: { x: 420, z: 700 }, launch: true, hitstop: 0.13, shake: 22, fx: 'impactRock', sfx: 'hitHeavy', aoe: 150 }),
    proj(0.34, 'rockShard', 26, { count: 3, spread: 0.16, speed: 620, ox: 70, oz: 20, size: 1.3, life: 1.1 }),
    fx(0.34, 'groundCrack', { scale: 2 }),
    fx(0.36, 'shockRing', { scale: 2.4, color: '#c8a05a' }),
    flash(0.32, '#ffd8a0', 0.35, 0.24),
    shake(0.32, 26),
  ],
});
const PAN_SKILL_B: MoveDef = move({
  id: 'pan_sb',
  name: '狂野猪突進',
  kind: 'skill',
  duration: 1.05,
  cd: 10,
  stamina: 32,
  invuln: [0.12, 0.86],
  desc: '低頭猛衝，撞飛一切阻擋者，衝刺結束時引發崩地爆擊。',
  events: [
    sfx(0.0, 'dash', 1, 0.6),
    sfx(0.06, 'charge', 0.8, 0.9),
    fx(0.06, 'dashGhost', { scale: 1.6, color: '#c8a05a' }),
    motion(0.08, 1000, 0, 0.6),
    ...multiHits(0.18, 5, 0.11, 13, 60, { w: 150, h: 120, pierce: true, kb: { x: 520, z: 260 }, hitstop: 0.05, shake: 10, fx: 'impactRock' }),
    melee(0.78, 38, 66, { w: 190, h: 150, kb: { x: 900, z: 560 }, launch: true, hitstop: 0.16, shake: 28, fx: 'impactRock', sfx: 'hitCrit', aoe: 170 }),
    fx(0.8, 'shockRing', { scale: 2.6, color: '#e0a558' }),
    fx(0.82, 'groundCrack', { scale: 2.2 }),
    flash(0.78, '#ffe6b0', 0.45, 0.3),
  ],
});

const PANYA: HeroDef = {
  id: 'panya',
  name: '磐牙',
  title: '巨嶽豬將・崩山之力',
  style: '力量',
  tribe: '山嶽獸族',
  desc: '以怪力揮舞碎山鉞的重擊手。每一擊都能把成群敵人砸上天，抗打能力全隊最高。',
  quote: '站好，別動。俺一斧就夠了。',
  atlas: 1,
  palette: { main: '#5b6472', trim: '#e0a558', skin: '#e0a184', hair: '#3a3f4a', aura: '#e0a558', dark: '#22262e', metal: '#c9d3e0' },
  base: { hp: 172, stamina: 110, speed: 288, jump: 700, atk: 17, weight: 1.5 },
  combo: [PAN_COMBO_1, PAN_COMBO_2, PAN_COMBO_3],
  air: [PAN_AIR_1, PAN_AIR_2, PAN_LAUNCH],
  skillA: PAN_SKILL_A,
  skillB: PAN_SKILL_B,
  weapon: '碎山鉞',
  ultName: '嶽崩千鈞墜',
  ultKanji: ['嶽', '崩', '千', '鈞', '墜'],
  ultDesc: '躍上九霄，召出巨嶽之影隨斧墜落，大地碎裂、岩漿噴發。',
  unlockCost: 0,
  unlockReq: '初始成員',
};

/* ============================== 三號・漣 ============================== */
const LIAN_COMBO_1: MoveDef = move({
  id: 'lian_c1',
  name: '月牙斬',
  kind: 'combo',
  duration: 0.38,
  next: 'lian_c2',
  events: [
    sfx(0.02, 'swing', 0.6, 1.2),
    fx(0.08, 'slashWater', { ox: 56, oz: 60, scale: 1 }),
    melee(0.1, 10, 62, { w: 118, h: 88, kb: { x: 170, z: 20 }, hitstop: 0.045, shake: 5, fx: 'impactWater' }),
  ],
});
const LIAN_COMBO_2: MoveDef = move({
  id: 'lian_c2',
  name: '迴流雙斬',
  kind: 'combo',
  duration: 0.42,
  next: 'lian_c3',
  events: [
    sfx(0.02, 'swing', 0.65, 1.15),
    ...multiHits(0.1, 2, 0.1, 9, 58, { w: 122, h: 92, kb: { x: 180, z: 30 }, hitstop: 0.04, shake: 5, fx: 'slashWater' }),
  ],
});
const LIAN_COMBO_3: MoveDef = move({
  id: 'lian_c3',
  name: '潮刃・放出',
  kind: 'combo',
  duration: 0.56,
  next: null,
  events: [
    sfx(0.04, 'water', 0.8, 1.1),
    fx(0.12, 'slashWater', { ox: 60, oz: 60, scale: 1.4 }),
    melee(0.14, 14, 62, { w: 130, h: 100, kb: { x: 260, z: 60 }, hitstop: 0.06, shake: 8, fx: 'impactWater' }),
    proj(0.2, 'waterCrescent', 20, { count: 1, speed: 780, ox: 70, oz: 62, size: 1.4, life: 1.2 }),
    sfx(0.2, 'water', 0.9),
    fx(0.22, 'shockRing', { scale: 0.9, color: '#4fd8ff' }),
  ],
});
const LIAN_LAUNCH: MoveDef = move({
  id: 'lian_launch',
  name: '湧泉挑斬',
  kind: 'launcher',
  duration: 0.56,
  events: [
    sfx(0.02, 'water', 0.8, 1.2),
    fx(0.1, 'slashWater', { ox: 44, oz: 90, scale: 1.4, color: '#7fe9ff' }),
    melee(0.12, 15, 48, { oy: 40, w: 104, h: 160, kb: { x: 110, z: 820 }, launch: true, hitstop: 0.09, shake: 12, fx: 'impactWater', sfx: 'hitHeavy' }),
    fx(0.14, 'shockRing', { scale: 1, color: '#4fd8ff' }),
  ],
});
const LIAN_AIR_1: MoveDef = move({
  id: 'lian_a1',
  name: '空漣斬',
  kind: 'air',
  airOnly: true,
  duration: 0.34,
  next: 'lian_a2',
  events: [
    sfx(0.02, 'swing', 0.6, 1.2),
    fx(0.08, 'slashWater', { ox: 50, oz: 0, scale: 0.9 }),
    melee(0.1, 9, 56, { oy: -10, w: 112, h: 86, kb: { x: 140, z: 20 }, hitstop: 0.04, shake: 4, fx: 'impactWater' }),
  ],
});
const LIAN_AIR_2: MoveDef = move({
  id: 'lian_a2',
  name: '墜潮射',
  kind: 'air',
  airOnly: true,
  duration: 0.5,
  tag: 'dive',
  desc: '空中向下發射高密度水砲，同時自身快速墜落。',
  events: [
    sfx(0.0, 'water', 0.9, 0.8),
    motion(0.02, 80, -900, 0.4),
    proj(0.06, 'waterCrescent', 24, { count: 2, spread: 0.1, speed: 900, oz: -30, size: 1.2, life: 0.9 }),
    melee(0.12, 20, 40, { oy: -40, w: 100, h: 130, kb: { x: 180, z: -300 }, hitstop: 0.1, shake: 16, fx: 'impactWater', sfx: 'hitHeavy', aoe: 120 }),
    fx(0.14, 'shockRing', { scale: 1.6, color: '#4fd8ff' }),
  ],
});
const LIAN_SKILL_A: MoveDef = move({
  id: 'lian_sa',
  name: '滄瀾刃雨',
  kind: 'skill',
  duration: 0.9,
  cd: 6,
  stamina: 24,
  desc: '扇形射出七道水刃，遠距離掃蕩整排敵人。',
  events: [
    sfx(0.02, 'water', 1, 1.1),
    fx(0.06, 'chargeAura', { oz: 60, scale: 1, color: '#4fd8ff' }),
    proj(0.14, 'waterCrescent', 15, { count: 7, spread: 0.42, speed: 900, ox: 64, oz: 62, size: 1, life: 1.1 }),
    proj(0.32, 'waterCrescent', 15, { count: 5, spread: 0.3, speed: 1020, ox: 64, oz: 62, size: 1.1, life: 1.1 }),
    fx(0.16, 'shockRing', { scale: 1.1, color: '#7fe9ff' }),
    sfx(0.32, 'water', 0.8, 1.2),
  ],
});
const LIAN_SKILL_B: MoveDef = move({
  id: 'lian_sb',
  name: '潮湧瞬身',
  kind: 'skill',
  duration: 0.92,
  cd: 9.5,
  stamina: 26,
  invuln: [0.04, 0.5],
  desc: '化為浪潮向前湧動，穿越敵人時造成傷害並留下滯留水刃。',
  events: [
    sfx(0.0, 'water', 1, 0.8),
    fx(0.0, 'dashGhost', { scale: 1.3, color: '#4fd8ff' }),
    motion(0.02, 980, 0, 0.34),
    ...multiHits(0.08, 4, 0.08, 11, 50, { w: 120, h: 110, pierce: true, kb: { x: 260, z: 120 }, hitstop: 0.04, shake: 6, fx: 'slashWater' }),
    proj(0.4, 'waterCrescent', 18, { count: 5, spread: 0.5, speed: 420, ox: 30, oz: 60, size: 1, life: 1.6 }),
    melee(0.44, 20, 58, { w: 140, h: 120, kb: { x: 520, z: 380 }, launch: true, hitstop: 0.1, shake: 16, fx: 'impactWater', sfx: 'hitHeavy', aoe: 110 }),
    fx(0.46, 'shockRing', { scale: 1.7, color: '#4fd8ff' }),
  ],
});

const LIAN: HeroDef = {
  id: 'lian',
  name: '漣',
  title: '流沙蛟・滄海射手',
  style: '遠程',
  tribe: '江海蛟族',
  desc: '以月牙鏟操縱水刃的遠距離射手。能在安全距離外把敵陣切成碎片，擅長控場。',
  quote: '潮水會記得每一筆債。',
  atlas: 2,
  palette: { main: '#1f6f8b', trim: '#7fe9ff', skin: '#f2d0a9', hair: '#2fd4c8', aura: '#4fd8ff', dark: '#0c2430', metal: '#d6f2ff' },
  base: { hp: 104, stamina: 118, speed: 322, jump: 760, atk: 11, weight: 0.9 },
  combo: [LIAN_COMBO_1, LIAN_COMBO_2, LIAN_COMBO_3],
  air: [LIAN_AIR_1, LIAN_AIR_2, LIAN_LAUNCH],
  skillA: LIAN_SKILL_A,
  skillB: LIAN_SKILL_B,
  weapon: '月牙鏟',
  ultName: '滄瀾萬刃雨',
  ultKanji: ['滄', '瀾', '萬', '刃', '雨'],
  ultDesc: '召來倒懸之海，萬千水刃傾瀉而下，最後以海嘯洗淨全場。',
  unlockCost: 0,
  unlockReq: '初始成員',
};

/* ============================== 四號・霜翎 ============================== */
const SHUANG_COMBO_1: MoveDef = move({
  id: 'shuang_c1',
  name: '鶴翼扇斬',
  kind: 'combo',
  duration: 0.34,
  next: 'shuang_c2',
  events: [
    sfx(0.02, 'wind', 0.6, 1.3),
    fx(0.07, 'slashWind', { ox: 52, oz: 62, scale: 0.95 }),
    melee(0.09, 9, 58, { w: 104, h: 84, kb: { x: 160, z: 30 }, hitstop: 0.04, shake: 4, fx: 'impactWind' }),
  ],
});
const SHUANG_COMBO_2: MoveDef = move({
  id: 'shuang_c2',
  name: '羽刃連舞',
  kind: 'combo',
  duration: 0.46,
  next: 'shuang_c3',
  events: [
    sfx(0.02, 'wind', 0.7, 1.2),
    ...multiHits(0.09, 3, 0.09, 7, 54, { w: 112, h: 92, kb: { x: 130, z: 40 }, hitstop: 0.035, shake: 4, fx: 'slashWind' }),
    proj(0.36, 'feather', 10, { count: 2, spread: 0.14, speed: 640, ox: 56, oz: 66, size: 0.9 }),
  ],
});
const SHUANG_COMBO_3: MoveDef = move({
  id: 'shuang_c3',
  name: '九霄旋羽',
  kind: 'combo',
  duration: 0.62,
  next: null,
  events: [
    sfx(0.04, 'wind', 0.9, 0.9),
    motion(0.1, 200, 200, 0.34),
    ...multiHits(0.16, 4, 0.1, 8, 56, { w: 132, h: 116, pierce: true, kb: { x: 160, z: 80 }, hitstop: 0.04, shake: 6, fx: 'slashWind' }),
    melee(0.54, 18, 62, { w: 140, h: 130, kb: { x: 420, z: 620 }, launch: true, hitstop: 0.1, shake: 14, fx: 'impactWind', sfx: 'hitHeavy', aoe: 90 }),
    fx(0.56, 'shockRing', { scale: 1.4, color: '#ffffff' }),
  ],
});
const SHUANG_LAUNCH: MoveDef = move({
  id: 'shuang_launch',
  name: '凌霄挑羽',
  kind: 'launcher',
  duration: 0.54,
  events: [
    sfx(0.02, 'wind', 0.9, 1.1),
    motion(0.05, 100, 460, 0.3),
    melee(0.1, 13, 46, { oy: 50, w: 100, h: 170, kb: { x: 90, z: 940 }, launch: true, hitstop: 0.08, shake: 11, fx: 'impactWind', sfx: 'hitHeavy' }),
    fx(0.12, 'slashWind', { ox: 40, oz: 110, scale: 1.5, color: '#ffffff' }),
  ],
});
const SHUANG_AIR_1: MoveDef = move({
  id: 'shuang_a1',
  name: '空中鶴舞',
  kind: 'air',
  airOnly: true,
  duration: 0.4,
  next: 'shuang_a2',
  events: [
    sfx(0.02, 'wind', 0.7, 1.2),
    ...multiHits(0.07, 3, 0.08, 7, 52, { oy: -10, w: 116, h: 96, kb: { x: 120, z: -20 }, hitstop: 0.035, shake: 4, fx: 'slashWind' }),
  ],
});
const SHUANG_AIR_2: MoveDef = move({
  id: 'shuang_a2',
  name: '墜羽螺旋',
  kind: 'air',
  airOnly: true,
  duration: 0.66,
  tag: 'dive',
  desc: '螺旋墜落，羽毛化為刀刃四散，可於空中二段跳後接續。',
  events: [
    sfx(0.0, 'wind', 0.9, 0.7),
    motion(0.02, 200, -1300, 0.45),
    fx(0.04, 'dashGhost', { scale: 1.2, color: '#eaf6ff' }),
    ...multiHits(0.1, 3, 0.08, 8, 46, { oy: -20, w: 110, h: 120, pierce: true, kb: { x: 140, z: -60 }, hitstop: 0.04, shake: 6, fx: 'slashWind' }),
    melee(0.34, 22, 44, { oy: -30, w: 120, h: 130, kb: { x: 300, z: -200 }, hitstop: 0.11, shake: 18, fx: 'impactWind', sfx: 'hitHeavy', aoe: 140 }),
    proj(0.36, 'feather', 12, { count: 8, spread: 1.6, speed: 460, oz: 10, size: 1 }),
    fx(0.36, 'shockRing', { scale: 1.8, color: '#ffffff' }),
  ],
});
const SHUANG_SKILL_A: MoveDef = move({
  id: 'shuang_sa',
  name: '千羽刃暴',
  kind: 'skill',
  duration: 0.95,
  cd: 6.5,
  stamina: 24,
  desc: '召出羽刃風暴，在周身形成持續切割的龍捲。',
  events: [
    sfx(0.02, 'wind', 1, 0.9),
    fx(0.06, 'chargeAura', { oz: 60, scale: 1.4, color: '#eaf6ff' }),
    proj(0.14, 'feather', 11, { count: 12, spread: 3.1, speed: 560, oz: 70, size: 1, life: 1.3 }),
    proj(0.34, 'feather', 11, { count: 12, spread: 3.1, speed: 640, oz: 70, size: 1, life: 1.3 }),
    proj(0.54, 'feather', 11, { count: 10, spread: 3.1, speed: 720, oz: 70, size: 1, life: 1.3 }),
    melee(0.2, 8, 0, { w: 170, h: 150, pierce: true, multi: 6, multiGap: 0.1, kb: { x: 60, z: 90 }, hitstop: 0.02, shake: 3, fx: 'slashWind' }),
    fx(0.7, 'shockRing', { scale: 2, color: '#eaf6ff' }),
  ],
});
const SHUANG_SKILL_B: MoveDef = move({
  id: 'shuang_sb',
  name: '鶴翼昇天',
  kind: 'skill',
  duration: 1.1,
  cd: 10,
  stamina: 28,
  invuln: [0.0, 0.6],
  desc: '展翅升空後俯衝交叉斬，全程無敵並重置空中行動。',
  events: [
    sfx(0.0, 'wind', 1, 1.2),
    motion(0.02, 60, 1250, 0.34),
    fx(0.04, 'shockRing', { scale: 1.4, color: '#ffffff' }),
    fx(0.2, 'chargeAura', { oz: 40, scale: 1.6, color: '#eaf6ff' }),
    motion(0.4, 780, -1500, 0.3),
    melee(0.5, 16, 50, { oy: -20, w: 140, h: 130, pierce: true, kb: { x: 320, z: 200 }, hitstop: 0.07, shake: 12, fx: 'slashWind' }),
    melee(0.62, 16, 50, { oy: -20, w: 140, h: 130, pierce: true, kb: { x: -320, z: 200 }, hitstop: 0.07, shake: 12, fx: 'slashWind' }),
    melee(0.78, 26, 52, { oy: -20, w: 160, h: 150, kb: { x: 520, z: 520 }, launch: true, hitstop: 0.13, shake: 22, fx: 'impactWind', sfx: 'hitCrit', aoe: 130 }),
    fx(0.8, 'shockRing', { scale: 2.2, color: '#7fe9ff' }),
    flash(0.78, '#ffffff', 0.4, 0.24),
  ],
});

const SHUANGLING: HeroDef = {
  id: 'shuangling',
  name: '霜翎',
  title: '白鶴仙・九霄舞者',
  style: '空戰',
  tribe: '靈鶴仙族',
  desc: '擁有二段跳與空中連段的空戰特化者。幾乎全程待在天上的高機動刺客。',
  quote: '風會替我記得路。',
  atlas: 3,
  palette: { main: '#f2f6ff', trim: '#ffc93c', skin: '#fbe0cf', hair: '#dfe9f5', aura: '#9fe8ff', dark: '#8fa3bd', metal: '#ffffff' },
  base: { hp: 96, stamina: 126, speed: 366, jump: 900, atk: 10, weight: 0.8 },
  combo: [SHUANG_COMBO_1, SHUANG_COMBO_2, SHUANG_COMBO_3],
  air: [SHUANG_AIR_1, SHUANG_AIR_2, SHUANG_LAUNCH],
  skillA: SHUANG_SKILL_A,
  skillB: SHUANG_SKILL_B,
  weapon: '鶴羽扇',
  ultName: '九霄鶴舞斬',
  ultKanji: ['九', '霄', '鶴', '舞', '斬'],
  ultDesc: '白鶴巨影蔽天，霜翎於光中交錯斬擊百次，最後一刀延遲綻放。',
  unlockCost: 2600,
  unlockReq: '通過第一章・第四幕',
};

/* ============================== 五號・玄角 ============================== */
const XUAN_COMBO_1: MoveDef = move({
  id: 'xuan_c1',
  name: '鐵拳連打',
  kind: 'combo',
  duration: 0.44,
  next: 'xuan_c2',
  events: [
    sfx(0.02, 'swingHeavy', 0.7, 0.9),
    ...multiHits(0.09, 2, 0.11, 14, 56, { w: 116, h: 100, kb: { x: 200, z: 20 }, hitstop: 0.06, shake: 8, fx: 'impactIron' }),
    motion(0.06, 160, 0, 0.16),
  ],
});
const XUAN_COMBO_2: MoveDef = move({
  id: 'xuan_c2',
  name: '角撞',
  kind: 'combo',
  duration: 0.5,
  next: 'xuan_c3',
  events: [
    sfx(0.03, 'swingHeavy', 0.85, 0.8),
    motion(0.06, 420, 0, 0.2),
    fx(0.12, 'slashIron', { ox: 50, oz: 70, scale: 1.2 }),
    melee(0.16, 22, 54, { w: 132, h: 120, kb: { x: 520, z: 240 }, hitstop: 0.1, shake: 16, fx: 'impactIron', sfx: 'hitHeavy', aoe: 80 }),
    fx(0.18, 'shockRing', { scale: 1.2, color: '#ff3b52' }),
  ],
});
const XUAN_COMBO_3: MoveDef = move({
  id: 'xuan_c3',
  name: '鬼王大摔',
  kind: 'combo',
  duration: 0.78,
  next: null,
  events: [
    sfx(0.04, 'charge', 0.8, 0.8),
    fx(0.12, 'chargeAura', { oz: 60, scale: 1.3, color: '#ff3b52' }),
    melee(0.24, 26, 58, { w: 140, h: 130, kb: { x: 120, z: 700 }, launch: true, hitstop: 0.11, shake: 16, fx: 'impactIron', sfx: 'hitHeavy' }),
    motion(0.3, 100, 400, 0.2),
    melee(0.5, 34, 54, { oy: 30, w: 150, h: 150, kb: { x: 300, z: -900 }, hitstop: 0.18, shake: 30, fx: 'impactIron', sfx: 'hitCrit', aoe: 180 }),
    flash(0.5, '#ff3b52', 0.45, 0.3),
    fx(0.52, 'groundCrack', { scale: 2 }),
    fx(0.54, 'shockRing', { scale: 2.4, color: '#ff3b52' }),
  ],
});
const XUAN_LAUNCH: MoveDef = move({
  id: 'xuan_launch',
  name: '挑角',
  kind: 'launcher',
  duration: 0.56,
  events: [
    sfx(0.02, 'swingHeavy', 0.9, 0.75),
    motion(0.05, 160, 260, 0.26),
    melee(0.12, 20, 48, { oy: 40, w: 116, h: 160, kb: { x: 140, z: 860 }, launch: true, hitstop: 0.1, shake: 14, fx: 'impactIron', sfx: 'hitHeavy' }),
  ],
});
const XUAN_AIR_1: MoveDef = move({
  id: 'xuan_a1',
  name: '空中重拳',
  kind: 'air',
  airOnly: true,
  duration: 0.4,
  next: 'xuan_a2',
  events: [
    sfx(0.02, 'swingHeavy', 0.75, 0.9),
    melee(0.1, 16, 52, { oy: -16, w: 122, h: 104, kb: { x: 200, z: -80 }, hitstop: 0.07, shake: 9, fx: 'impactIron' }),
  ],
});
const XUAN_AIR_2: MoveDef = move({
  id: 'xuan_a2',
  name: '鬼王墜地',
  kind: 'air',
  airOnly: true,
  duration: 0.82,
  tag: 'dive',
  desc: '雙手抱拳向下砸，墜落高度轉換成衝擊波半徑。',
  events: [
    sfx(0.0, 'charge', 0.9, 0.6),
    motion(0.02, 60, -1800, 0.5),
    fx(0.04, 'dashGhost', { scale: 1.6, color: '#ff3b52' }),
    melee(0.12, 36, 40, { oy: -40, w: 140, h: 160, kb: { x: 260, z: -500 }, hitstop: 0.18, shake: 30, fx: 'impactIron', sfx: 'hitCrit', aoe: 190 }),
    flash(0.12, '#ff8090', 0.5, 0.32),
    fx(0.14, 'shockRing', { scale: 2.6, color: '#ff3b52' }),
    fx(0.16, 'groundCrack', { scale: 2.2 }),
    shake(0.12, 30),
  ],
});
const XUAN_SKILL_A: MoveDef = move({
  id: 'xuan_sa',
  name: '角抵衝鋒',
  kind: 'skill',
  duration: 1.1,
  cd: 8,
  stamina: 26,
  invuln: [0.1, 0.8],
  desc: '低頭全力衝撞，撞到的敵人會被頂著一起推進並撞上牆。',
  events: [
    sfx(0.0, 'dash', 1, 0.5),
    fx(0.04, 'dashGhost', { scale: 1.8, color: '#ff3b52' }),
    motion(0.06, 900, 0, 0.66),
    ...multiHits(0.14, 6, 0.1, 14, 56, { w: 150, h: 130, pierce: true, kb: { x: 620, z: 180 }, hitstop: 0.05, shake: 11, fx: 'impactIron' }),
    melee(0.82, 36, 62, { w: 180, h: 150, kb: { x: 980, z: 620 }, launch: true, hitstop: 0.17, shake: 30, fx: 'impactIron', sfx: 'hitCrit', aoe: 170 }),
    fx(0.84, 'shockRing', { scale: 2.6, color: '#ff3b52' }),
    fx(0.86, 'groundCrack', { scale: 2 }),
    flash(0.82, '#ff3b52', 0.4, 0.3),
  ],
});
const XUAN_SKILL_B: MoveDef = move({
  id: 'xuan_sb',
  name: '鬼王咆哮',
  kind: 'skill',
  duration: 1.2,
  cd: 13,
  stamina: 30,
  desc: '放出震懾咆哮，範圍內敵人恐懼僵直，自身獲得攻勢強化 8 秒。',
  events: [
    sfx(0.02, 'bossRoar', 1, 1.2),
    fx(0.1, 'chargeAura', { oz: 70, scale: 2, color: '#ff3b52' }),
    fx(0.3, 'shockRing', { scale: 3.2, color: '#ff3b52' }),
    melee(0.32, 18, 0, { w: 300, h: 220, pierce: true, multi: 2, multiGap: 0.12, kb: { x: 420, z: 120 }, hitstop: 0.08, shake: 18, fx: 'impactIron', sfx: 'hitHeavy', aoe: 220 }),
    fx(0.5, 'shockRing', { scale: 4, color: '#7a1020' }),
    shake(0.3, 22),
    flash(0.3, '#5a0a14', 0.35, 0.5),
  ],
});

const XUANJIAO: HeroDef = {
  id: 'xuanjiao',
  name: '玄角',
  title: '鐵角鬼王・不破壁垒',
  style: '重型',
  tribe: '牛角魔族',
  desc: '血量與霸體最高的坦克型戰士。衝撞可把整排敵人推著走，咆哮能震懾全場。',
  quote: '想過去？先問問我的角。',
  atlas: 4,
  palette: { main: '#7a1020', trim: '#ff3b52', skin: '#c05a4a', hair: '#2a1216', aura: '#ff3b52', dark: '#30121a', metal: '#f0d6a8' },
  base: { hp: 210, stamina: 96, speed: 274, jump: 660, atk: 19, weight: 2.1 },
  combo: [XUAN_COMBO_1, XUAN_COMBO_2, XUAN_COMBO_3],
  air: [XUAN_AIR_1, XUAN_AIR_2, XUAN_LAUNCH],
  skillA: XUAN_SKILL_A,
  skillB: XUAN_SKILL_B,
  weapon: '鬼王尖角',
  ultName: '角抵山河破',
  ultKanji: ['角', '抵', '山', '河', '破'],
  ultDesc: '巨角化作山河之影，一次貫穿全場的破壞衝撞，空間為之撕裂。',
  unlockCost: 3400,
  unlockReq: '通過第二章・第四幕',
};

/* ============================== 六號・緋月 ============================== */
const FEI_COMBO_1: MoveDef = move({
  id: 'fei_c1',
  name: '符咒打',
  kind: 'combo',
  duration: 0.36,
  next: 'fei_c2',
  events: [
    sfx(0.02, 'swing', 0.55, 1.3),
    fx(0.07, 'slashFox', { ox: 50, oz: 62, scale: 0.9 }),
    melee(0.09, 9, 56, { w: 100, h: 86, kb: { x: 150, z: 20 }, hitstop: 0.04, shake: 4, fx: 'impactFox' }),
  ],
});
const FEI_COMBO_2: MoveDef = move({
  id: 'fei_c2',
  name: '狐火掌',
  kind: 'combo',
  duration: 0.4,
  next: 'fei_c3',
  events: [
    sfx(0.02, 'fire', 0.6, 1.3),
    fx(0.1, 'slashFox', { ox: 54, oz: 60, scale: 1.05 }),
    melee(0.12, 11, 58, { w: 108, h: 92, kb: { x: 190, z: 40 }, hitstop: 0.05, shake: 6, fx: 'impactFox' }),
    proj(0.16, 'foxfire', 8, { count: 1, speed: 420, ox: 60, oz: 66, size: 0.8, life: 1.4, homing: 2.2 }),
  ],
});
const FEI_COMBO_3: MoveDef = move({
  id: 'fei_c3',
  name: '九尾掃',
  kind: 'combo',
  duration: 0.6,
  next: null,
  events: [
    sfx(0.04, 'wind', 0.8, 0.9),
    fx(0.12, 'slashFox', { ox: 40, oz: 60, scale: 1.6 }),
    melee(0.16, 16, 44, { w: 170, h: 120, kb: { x: 380, z: 300 }, launch: true, hitstop: 0.09, shake: 14, fx: 'impactFox', sfx: 'hitHeavy', aoe: 100 }),
    proj(0.24, 'foxfire', 10, { count: 4, spread: 0.6, speed: 520, ox: 50, oz: 60, size: 0.9, life: 1.6, homing: 2.6 }),
    fx(0.26, 'shockRing', { scale: 1.5, color: '#a56bff' }),
  ],
});
const FEI_LAUNCH: MoveDef = move({
  id: 'fei_launch',
  name: '妖火昇騰',
  kind: 'launcher',
  duration: 0.54,
  events: [
    sfx(0.02, 'fire', 0.9, 1.2),
    fx(0.1, 'slashFox', { ox: 40, oz: 90, scale: 1.5, color: '#7fd4ff' }),
    melee(0.12, 13, 46, { oy: 40, w: 104, h: 168, kb: { x: 100, z: 840 }, launch: true, hitstop: 0.08, shake: 12, fx: 'impactFox', sfx: 'hitHeavy' }),
    proj(0.16, 'foxfire', 9, { count: 3, spread: 0.4, speed: 380, oz: 90, size: 0.9, homing: 2, life: 1.6 }),
  ],
});
const FEI_AIR_1: MoveDef = move({
  id: 'fei_a1',
  name: '空中符陣',
  kind: 'air',
  airOnly: true,
  duration: 0.4,
  next: 'fei_a2',
  events: [
    sfx(0.02, 'fire', 0.6, 1.2),
    proj(0.08, 'foxfire', 9, { count: 3, spread: 0.3, speed: 620, oz: -10, size: 0.85, homing: 2.4, life: 1.4 }),
    melee(0.1, 7, 52, { oy: -10, w: 104, h: 88, kb: { x: 120, z: 10 }, hitstop: 0.03, shake: 3, fx: 'impactFox' }),
  ],
});
const FEI_AIR_2: MoveDef = move({
  id: 'fei_a2',
  name: '焚星墜',
  kind: 'air',
  airOnly: true,
  duration: 0.7,
  tag: 'dive',
  desc: '召出星形妖火與自身一同墜落，落地形成燃燒結界。',
  events: [
    sfx(0.0, 'charge', 0.9, 1.1),
    motion(0.02, 100, -1200, 0.45),
    fx(0.04, 'dashGhost', { scale: 1.2, color: '#a56bff' }),
    proj(0.06, 'starFlame', 14, { count: 5, spread: 0.8, speed: 520, oz: -20, size: 1, life: 1.2, homing: 1.6 }),
    melee(0.3, 22, 44, { oy: -30, w: 120, h: 140, kb: { x: 220, z: -200 }, hitstop: 0.12, shake: 20, fx: 'impactFox', sfx: 'hitHeavy', aoe: 160 }),
    fx(0.32, 'shockRing', { scale: 2, color: '#a56bff' }),
    flash(0.3, '#c9a0ff', 0.4, 0.28),
  ],
});
const FEI_SKILL_A: MoveDef = move({
  id: 'fei_sa',
  name: '九尾妖火彈',
  kind: 'skill',
  duration: 0.86,
  cd: 5.5,
  stamina: 22,
  desc: '射出九發自動追蹤的妖火彈，可轉折追擊逃跑的敵人。',
  events: [
    sfx(0.02, 'fire', 1, 1.2),
    fx(0.06, 'chargeAura', { oz: 60, scale: 1.2, color: '#7fd4ff' }),
    proj(0.14, 'foxfire', 13, { count: 9, spread: 1.2, speed: 520, ox: 56, oz: 66, size: 1.05, life: 2.2, homing: 4.2 }),
    fx(0.16, 'shockRing', { scale: 1.1, color: '#7fd4ff' }),
    sfx(0.3, 'fire', 0.7, 1.4),
  ],
});
const FEI_SKILL_B: MoveDef = move({
  id: 'fei_sb',
  name: '結界・焚星陣',
  kind: 'skill',
  duration: 1.2,
  cd: 12,
  stamina: 32,
  invuln: [0.1, 0.5],
  desc: '於自身周圍展開妖火結界，持續 4 秒灼燒範圍內所有敵人。',
  events: [
    sfx(0.02, 'thunder', 0.9, 1.4),
    fx(0.1, 'shockRing', { scale: 2.4, color: '#a56bff' }),
    flash(0.12, '#7a3aff', 0.35, 0.3),
    melee(0.16, 10, 0, { w: 260, h: 200, pierce: true, multi: 8, multiGap: 0.4, kb: { x: 80, z: 100 }, hitstop: 0.03, shake: 6, fx: 'impactFox', aoe: 200 }),
    proj(0.2, 'starFlame', 12, { count: 14, spread: 3.14, speed: 300, oz: 70, size: 1.1, life: 2, homing: 1.2 }),
    shake(0.14, 14),
  ],
});

const FEIYUE: HeroDef = {
  id: 'feiyue',
  name: '緋月',
  title: '狐火巫女・星焚之術',
  style: '法術',
  tribe: '九尾狐仙',
  desc: '以妖火與符陣作戰的法術型角色。追蹤彈可越過地形追殺，結界能長時間控場。',
  quote: '月亮看著呢——你逃不掉的。',
  atlas: 5,
  palette: { main: '#5b2a86', trim: '#7fd4ff', skin: '#fbe3d6', hair: '#b06bff', aura: '#a56bff', dark: '#241036', metal: '#ffe6a8' },
  base: { hp: 92, stamina: 140, speed: 312, jump: 780, atk: 10, weight: 0.75 },
  combo: [FEI_COMBO_1, FEI_COMBO_2, FEI_COMBO_3],
  air: [FEI_AIR_1, FEI_AIR_2, FEI_LAUNCH],
  skillA: FEI_SKILL_A,
  skillB: FEI_SKILL_B,
  weapon: '九尾符扇',
  ultName: '九尾焚星陣',
  ultKanji: ['九', '尾', '焚', '星', '陣'],
  ultDesc: '九條狐尾展開星陣，萬千妖火流星轟炸，最終以九尾合一焚盡天際。',
  unlockCost: 4200,
  unlockReq: '通過第三章・第二幕',
};

/* ============================ 匯出 ============================ */
export const HEROES: HeroDef[] = [LIN, PANYA, LIAN, SHUANGLING, XUANJIAO, FEIYUE];
export const HERO_MAP: Record<string, HeroDef> = Object.fromEntries(HEROES.map((h) => [h.id, h]));
export const STARTER_HEROES = HEROES.filter((h) => h.unlockCost === 0).map((h) => h.id);

/** 依 id 取得招式（含所有連段） */
export function findMove(hero: HeroDef, id: string): MoveDef | undefined {
  return [...hero.combo, ...hero.air, hero.skillA, hero.skillB].find((m) => m.id === id);
}
