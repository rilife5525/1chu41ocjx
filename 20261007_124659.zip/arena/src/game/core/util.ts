/**
 * 通用工具：數學、隨機、緩動、物件池、顏色處理
 * 效能敏感路徑一律使用這裡的輕量函式，避免配置物件造成 GC 抖動。
 */

export const TAU = Math.PI * 2;

export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const invLerp = (a: number, b: number, v: number) => (b === a ? 0 : (v - a) / (b - a));
export const smoothstep = (t: number) => t * t * (3 - 2 * t);
export const approach = (v: number, target: number, step: number) =>
  v < target ? Math.min(v + step, target) : Math.max(v - step, target);

/** 與幀率無關的指數平滑 */
export const damp = (a: number, b: number, lambda: number, dt: number) => lerp(a, b, 1 - Math.exp(-lambda * dt));

export const rand = (a = 1, b?: number) => (b === undefined ? Math.random() * a : a + Math.random() * (b - a));
export const randInt = (a: number, b?: number) => Math.floor(rand(a, b));
export const pick = <T>(arr: T[]): T => arr[(Math.random() * arr.length) | 0];
export const chance = (p: number) => Math.random() < p;
export const sign = (v: number) => (v < 0 ? -1 : 1);

/* ---------------------------- 緩動函式 ---------------------------- */
export type Ease = (t: number) => number;
export const Ease = {
  linear: (t: number) => t,
  inQuad: (t: number) => t * t,
  outQuad: (t: number) => t * (2 - t),
  inOutQuad: (t: number) => (t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t),
  inCubic: (t: number) => t * t * t,
  outCubic: (t: number) => --t * t * t + 1,
  inOutCubic: (t: number) => (t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1),
  outBack: (t: number) => 1 + 2.2 * Math.pow(t - 1, 3) + 1.4 * Math.pow(t - 1, 2),
  outElastic: (t: number) => (t === 0 || t === 1 ? t : Math.pow(2, -9 * t) * Math.sin((t - 0.075) * (TAU) / 0.3) + 1),
  outExpo: (t: number) => (t === 1 ? 1 : 1 - Math.pow(2, -9 * t)),
  inExpo: (t: number) => (t === 0 ? 0 : Math.pow(2, 9 * t - 9)),
  outBounce: (t: number) => {
    const n = 7.5625,
      d = 2.75;
    if (t < 1 / d) return n * t * t;
    if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
    if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
    return n * (t -= 2.625 / d) * t + 0.984375;
  },
};

/* ---------------------------- 顏色工具 ---------------------------- */
export function hexToRgb(hex: string): [number, number, number] {
  let h = hex.replace('#', '');
  if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  const n = parseInt(h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
export function rgba(hex: string, a: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${a})`;
}
export function mixHex(a: string, b: string, t: number): string {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  const r = Math.round(lerp(r1, r2, t)),
    g = Math.round(lerp(g1, g2, t)),
    bl = Math.round(lerp(b1, b2, t));
  return `#${((1 << 24) + (r << 16) + (g << 8) + bl).toString(16).slice(1)}`;
}

/* ---------------------------- 物件池 ---------------------------- */
/**
 * 泛型物件池：所有高頻生滅的物件（粒子、投射物、傷害數字、敵人）
 * 都透過池回收，避免執行期記憶體抖動。
 */
export class Pool<T> {
  private free: T[] = [];
  public active: T[] = [];
  private factory: () => T;
  private reset: (o: T) => void;
  public created = 0;
  public max: number;

  constructor(factory: () => T, reset: (o: T) => void, prealloc = 64, max = 4096) {
    this.factory = factory;
    this.reset = reset;
    this.max = max;
    for (let i = 0; i < prealloc; i++) {
      this.free.push(factory());
      this.created++;
    }
  }

  obtain(): T | null {
    const o = this.free.pop() ?? (this.created < this.max ? (this.created++, this.factory()) : null);
    if (!o) return null;
    this.active.push(o);
    return o;
  }

  /** 釋放（保持 active 陣列順序，回圈中呼叫安全） */
  release(o: T) {
    const i = this.active.indexOf(o);
    if (i >= 0) {
      this.active[i] = this.active[this.active.length - 1];
      this.active.pop();
    }
    this.reset(o);
    this.free.push(o);
  }

  releaseAll() {
    while (this.active.length) {
      const o = this.active.pop()!;
      this.reset(o);
      this.free.push(o);
    }
  }

  get size() {
    return this.active.length;
  }
}

/** 快速迭代並移除：呼叫 end() 會把當前元素換到陣列尾端 */
export function swapRemove<T>(arr: T[], i: number) {
  arr[i] = arr[arr.length - 1];
  arr.pop();
}

/* ---------------------------- 計時器 ---------------------------- */
export class Timer {
  t = 0;
  constructor(public dur = 0) {}
  reset(dur?: number) {
    if (dur !== undefined) this.dur = dur;
    this.t = 0;
  }
  tick(dt: number) {
    this.t += dt;
    return this.t >= this.dur;
  }
  get p() {
    return clamp(this.t / this.dur, 0, 1);
  }
}

/* ---------------------------- 格式 ---------------------------- */
export const fmtNum = (n: number) => (n >= 10000 ? (n / 10000).toFixed(1) + '萬' : Math.floor(n).toLocaleString('zh-TW'));
export const fmtTime = (s: number) => {
  const m = Math.floor(s / 60);
  const ss = Math.floor(s % 60);
  return `${m.toString().padStart(2, '0')}:${ss.toString().padStart(2, '0')}`;
};

/** 簡易 seeded RNG（用於關卡生成的可重現隨機） */
export class Rng {
  private s: number;
  constructor(seed = 1) {
    this.s = seed >>> 0;
  }
  next() {
    this.s = (this.s * 1664525 + 1013904223) >>> 0;
    return this.s / 4294967296;
  }
  range(a: number, b: number) {
    return a + this.next() * (b - a);
  }
  int(a: number, b: number) {
    return Math.floor(this.range(a, b + 1));
  }
  pick<T>(arr: T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
}
