/**
 * 《逆天熾魂錄 REBEL SOULS》核心型別定義
 * ------------------------------------------------------------------
 * 所有子系統共用的介面、常數與列舉都集中在這裡，
 * 方便後續擴充（新增部隊／關卡／敵兵／法印／裝備）時只需動資料檔。
 */

/* ============================ 畫面常數 ============================ */
export const DESIGN_W = 1280; // 設計解析度寬
export const DESIGN_H = 720; // 設計解析度高
export const GROUND_Y = 556; // 深度 0 時的地面螢幕 Y
export const DEPTH_SCALE = 1; // 深度(Y)換算成螢幕 Y 的比例
export const DEPTH_MIN = -92; // 可行走深度下緣（遠）
export const DEPTH_MAX = 104; // 可行走深度上緣（近）
export const GRAVITY = 2350; // 重力加速度 (px/s^2)

/** 世界座標 → 螢幕座標（y 為深度、z 為高度） */
export const worldToScreenY = (y: number, z: number) => GROUND_Y + y * DEPTH_SCALE - z;
/** 深度造成的遠近縮放（越遠越小） */
export const depthScale = (y: number) => 1 + y * 0.0016;

/* ============================ 基本數學 ============================ */
export interface Vec2 {
  x: number;
  y: number;
}
export interface Vec3 {
  x: number;
  y: number;
  z: number;
}
export interface RGB {
  r: number;
  g: number;
  b: number;
}

/* ============================ 稀有度 ============================ */
export type Rarity = 'R' | 'SR' | 'SSR' | 'UR';

export const RARITY_ORDER: Rarity[] = ['R', 'SR', 'SSR', 'UR'];

/** 稀有度對應的設計系統色票（UI / 特效 / 邊框共用） */
export const RARITY_COLOR: Record<Rarity, { main: string; glow: string; ink: string; label: string }> = {
  R: { main: '#7fb2d9', glow: '#bfe2ff', ink: '#0d1a26', label: '稀有' },
  SR: { main: '#b98bff', glow: '#e3ccff', ink: '#180c2b', label: '精良' },
  SSR: { main: '#ffc93c', glow: '#fff0b8', ink: '#2b1c00', label: '傳說' },
  UR: { main: '#ff3b52', glow: '#ffd0d8', ink: '#2b0409', label: '天命' },
};

/* ============================ 屬性修正 ============================ */
/** 由法印／裝備／據點強化累積出來的數值修正集合 */
export interface Mods {
  atkMul: number; // 攻擊倍率
  atkFlat: number; // 攻擊加值
  hpMax: number; // 生命加值
  hpRegen: number; // 每秒回血
  speedMul: number; // 移動速度倍率
  jumpMul: number; // 跳躍力倍率
  dashCdMul: number; // 衝刺冷卻倍率（越小越好）
  staminaMax: number; // 精力加值
  staminaRegen: number; // 精力回復倍率
  critChance: number; // 暴擊率
  critDmg: number; // 暴擊傷害倍率
  cdReduce: number; // 仙術冷卻縮減
  ultChargeMul: number; // 奧義魂 gauge 充能倍率
  projSpeedMul: number; // 投射物速度
  projExtra: number; // 額外投射物數
  aoeMul: number; // 範圍倍率
  kbMul: number; // 擊退倍率
  lifesteal: number; // 吸血比例
  thorns: number; // 反傷
  dodgeChance: number; // 閃避機率
  armor: number; // 減傷（固定值）
  luck: number; // 法印稀有度幸運值
  soulMul: number; // 魂魄取得倍率
  healOnKill: number; // 擊殺回血
  staminaOnKill: number; // 擊殺回精力
  comboDmg: number; // 每段連擊疊加的傷害%
  airDmg: number; // 空中攻擊傷害加成
  chargeDmg: number; // 蓄力攻擊傷害加成
  executeBelow: number; // 處決血量門檻 (0~1)
  executeMul: number; // 處決傷害倍率
  shieldMax: number; // 護盾上限
  shieldOnWave: number; // 每波開始獲得護盾
  revives: number; // 復活次數
  pickupRadius: number; // 魂魄拾取範圍
  hitstopMul: number; // 打击感停頓倍率
  expMul: number; // 經驗倍率
}

export const BASE_MODS: Mods = {
  atkMul: 1,
  atkFlat: 0,
  hpMax: 0,
  hpRegen: 0,
  speedMul: 1,
  jumpMul: 1,
  dashCdMul: 1,
  staminaMax: 0,
  staminaRegen: 1,
  critChance: 0.05,
  critDmg: 1.6,
  cdReduce: 0,
  ultChargeMul: 1,
  projSpeedMul: 1,
  projExtra: 0,
  aoeMul: 1,
  kbMul: 1,
  lifesteal: 0,
  thorns: 0,
  dodgeChance: 0,
  armor: 0,
  luck: 0,
  soulMul: 1,
  healOnKill: 0,
  staminaOnKill: 0,
  comboDmg: 0,
  airDmg: 0,
  chargeDmg: 0,
  executeBelow: 0,
  executeMul: 1,
  shieldMax: 0,
  shieldOnWave: 0,
  revives: 0,
  pickupRadius: 90,
  hitstopMul: 1,
  expMul: 1,
};

/** 可疊加的數值欄位（其餘為覆蓋型） */
export const ADDITIVE_MODS: (keyof Mods)[] = [
  'atkFlat',
  'hpMax',
  'hpRegen',
  'staminaMax',
  'critChance',
  'critDmg',
  'cdReduce',
  'projExtra',
  'kbMul',
  'lifesteal',
  'thorns',
  'dodgeChance',
  'armor',
  'luck',
  'soulMul',
  'healOnKill',
  'staminaOnKill',
  'comboDmg',
  'airDmg',
  'chargeDmg',
  'executeBelow',
  'shieldMax',
  'shieldOnWave',
  'revives',
  'pickupRadius',
];

/** 乘法型欄位 */
export const MULTIPLICATIVE_MODS: (keyof Mods)[] = [
  'atkMul',
  'speedMul',
  'jumpMul',
  'dashCdMul',
  'staminaRegen',
  'ultChargeMul',
  'projSpeedMul',
  'aoeMul',
  'expMul',
  'hitstopMul',
];

/* ============================ 特殊詞條 ============================ */
/** 需要引擎掛勾實作的特殊效果，法印與 UR 裝備都能授予 */
export type TraitId =
  | 'onKillExplode' // 擊殺時引爆
  | 'onKillSoulBurst' // 擊殺噴出更多魂魄
  | 'dashFireTrail' // 衝刺留下火焰
  | 'dashIceTrail' // 衝刺留下冰霧
  | 'dashStrike' // 衝刺本身帶傷害
  | 'chainLightning' // 命中時連鎖閃電
  | 'onHitBurn' // 命中附加燃燒
  | 'onHitFreeze' // 命中附加緩速
  | 'onHitBleed' // 命中附加流血
  | 'onHitShockwave' // 第三下連擊產生衝擊波
  | 'critNova' // 暴擊時爆發新星
  | 'thornAura' // 周身荊棘光環
  | 'guardianWisp' // 召喚護法妖火（自動攻擊）
  | 'summonShade' // 召喚影武者分身
  | 'reviveOnce' // 致死時復活一次
  | 'waveShield' // 每波開始獲得護盾
  | 'timeSlowOnUlt' // 奧義後短暫子彈時間
  | 'executersMark' // 低血量敵人出現殺氣標記
  | 'comboHeal' // 高連擊時回血
  | 'projHoming' // 投射物追蹤
  | 'projPierce' // 投射物穿透
  | 'projSplit' // 投射物命中後分裂
  | 'secondWind' // 精力見底時爆發加速
  | 'giantSlayer' // 對首領／菁英傷害提升
  | 'airComboMaster' // 空中連段延長
  | 'perfectDodge'; // 完美閃避觸發子彈時間

export const TRAIT_NAME: Record<TraitId, string> = {
  onKillExplode: '魂爆',
  onKillSoulBurst: '貪魂',
  dashFireTrail: '焰影步',
  dashIceTrail: '霜影步',
  dashStrike: '突進斬',
  chainLightning: '連雷',
  onHitBurn: '灼燒',
  onHitFreeze: '冰封',
  onHitBleed: '放血',
  onHitShockwave: '震波',
  critNova: '暴擊新星',
  thornAura: '荊棘光環',
  guardianWisp: '護法妖火',
  summonShade: '影武者',
  reviveOnce: '不滅',
  waveShield: '結界',
  timeSlowOnUlt: '剎那',
  executersMark: '殺氣',
  comboHeal: '嗜戰',
  projHoming: '追魂',
  projPierce: '貫穿',
  projSplit: '分裂',
  secondWind: '回氣',
  giantSlayer: '屠神',
  airComboMaster: '空連',
  perfectDodge: '見切',
};

/* ============================ 招式時間軸 ============================ */
export type FxId =
  | 'slashFlame'
  | 'slashWater'
  | 'slashWind'
  | 'slashRock'
  | 'slashFox'
  | 'slashIron'
  | 'impactFlame'
  | 'impactWater'
  | 'impactWind'
  | 'impactRock'
  | 'impactFox'
  | 'impactIron'
  | 'shockRing'
  | 'groundCrack'
  | 'dustPuff'
  | 'jumpDust'
  | 'dashGhost'
  | 'chargeAura'
  | 'beamFire'
  | 'beamWater'
  | 'beamHoly'
  | 'lightning'
  | 'inkSplat';

export type SfxId =
  | 'swing'
  | 'swingHeavy'
  | 'hit'
  | 'hitHeavy'
  | 'hitCrit'
  | 'block'
  | 'jump'
  | 'dash'
  | 'land'
  | 'hurt'
  | 'die'
  | 'explode'
  | 'fire'
  | 'water'
  | 'wind'
  | 'thunder'
  | 'charge'
  | 'ult'
  | 'pickup'
  | 'levelup'
  | 'ui'
  | 'uiBig'
  | 'waveStart'
  | 'bossRoar';

export type ProjId =
  | 'fireball'
  | 'waterCrescent'
  | 'feather'
  | 'rockShard'
  | 'foxfire'
  | 'thunderSpear'
  | 'ironWave'
  | 'enemyArrow'
  | 'enemyRune'
  | 'enemyBomb'
  | 'bossBeam'
  | 'starFlame';

export interface HitSpec {
  t: number; // 觸發時間 (秒)
  dur: number; // 判定持續時間
  dmg: number; // 基礎傷害
  /** 判定盒（相對角色，x 依面朝方向翻轉） */
  ox: number;
  oy: number; // 相對於地面的高度
  w: number;
  h: number;
  kb: Vec3; // 擊退向量
  hitstop: number;
  shake: number;
  fx: FxId;
  sfx: SfxId;
  launch?: boolean; // 浮空
  multi?: number; // 多段判定次數
  multiGap?: number;
  pierce?: boolean; // 可命中同一目標多次
  aoe?: number; // 額外爆炸半徑
}

export type MoveEvent =
  | ({ t: number; type: 'hit' } & Omit<HitSpec, 't'>)
  | {
      t: number;
      type: 'proj';
      proj: ProjId;
      dmg: number;
      count?: number;
      spread?: number;
      speed?: number;
      ox?: number;
      oy?: number;
      oz?: number;
      fx?: FxId;
      sfx?: SfxId;
      homing?: number;
      size?: number;
      life?: number;
    }
  | { t: number; type: 'fx'; fx: FxId; ox?: number; oy?: number; oz?: number; scale?: number; color?: string }
  | { t: number; type: 'sfx'; sfx: SfxId; vol?: number; rate?: number }
  | { t: number; type: 'move'; vx?: number; vy?: number; vz?: number; dur?: number }
  | { t: number; type: 'shake'; amount: number }
  | { t: number; type: 'flash'; color?: string; alpha?: number; dur?: number };

export type MoveKind = 'combo' | 'air' | 'launcher' | 'skill' | 'ult' | 'dash';

export interface MoveDef {
  id: string;
  name: string;
  kind: MoveKind;
  duration: number; // 總時長 (秒)
  events: MoveEvent[];
  stamina?: number;
  cd?: number;
  invuln?: [number, number]; // 無敵區間
  next?: string | null; // 連段下一招
  airOnly?: boolean;
  groundOnly?: boolean;
  lockTurn?: boolean; // 出招中不可轉身
  desc?: string;
  tag?: string;
}

/* ============================ 角色 ============================ */
export type HeroStyle = '速度' | '力量' | '遠程' | '空戰' | '重型' | '法術';

export interface HeroPalette {
  main: string; // 主色（服裝）
  trim: string; // 副色
  skin: string;
  hair: string;
  aura: string; // 氣場／特效色
  dark: string; // 陰影
  metal: string; // 武器金屬色
}

export interface HeroBaseStats {
  hp: number;
  stamina: number;
  speed: number;
  jump: number;
  atk: number;
  weight: number; // 受擊穩定度
}

export interface HeroDef {
  id: string;
  name: string;
  title: string;
  style: HeroStyle;
  tribe: string; // 血統（妖／神）
  desc: string;
  quote: string;
  atlas: number; // 立繪圖集中的格子索引
  palette: HeroPalette;
  base: HeroBaseStats;
  combo: MoveDef[];
  air: MoveDef[];
  skillA: MoveDef;
  skillB: MoveDef;
  ultName: string;
  ultKanji: string[];
  ultDesc: string;
  weapon: string;
  unlockCost: number; // 解鎖所需魂魄
  unlockReq?: string; // 解鎖條件描述
}

/* ============================ 敵兵 ============================ */
export type AiKind = 'chaser' | 'spear' | 'ranged' | 'shield' | 'caster' | 'bomber' | 'ninja' | 'brute' | 'boss';

export interface EnemyAttackDef {
  range: number; // 觸發距離
  cd: number;
  windup: number; // 前搖
  move: MoveDef;
  chance?: number;
}

export interface EnemyDef {
  id: string;
  name: string;
  rank: '雜兵' | '菁英' | '首領';
  ai: AiKind;
  atlas: number;
  hp: number;
  atk: number;
  speed: number;
  weight: number;
  radius: number;
  height: number;
  scale: number;
  colors: { body: string; trim: string; skin: string; aura: string; metal: string };
  weapon: string;
  attacks: EnemyAttackDef[];
  deathFx: string; // 獨有的死亡演出識別
  deathColors: string[];
  souls: [number, number];
  flying?: boolean;
  desc?: string;
  /** 首領專用 */
  boss?: {
    title: string;
    phases: number;
    enrageHp: number[];
    intro: string;
    quote: string;
    scaleMul?: number;
  };
}

/* ============================ 法印（Roguelite 強化） ============================ */
export interface SigilDef {
  id: string;
  name: string;
  desc: string;
  flavor: string; // 風味文字
  rarity: Rarity;
  tags: string[];
  mods?: Partial<Mods>;
  traits?: TraitId[];
  maxStacks: number;
  hero?: string; // 限定角色
  requires?: string[]; // 需要先持有的法印
  icon: string;
}

/* ============================ 裝備 ============================ */
export type SlotId = 'crown' | 'armor' | 'bracer' | 'belt' | 'boots' | 'relic';

export const SLOT_NAME: Record<SlotId, string> = {
  crown: '頭冠',
  armor: '戰袍',
  bracer: '手甲',
  belt: '腰佩',
  boots: '足具',
  relic: '法器',
};

export interface EquipDef {
  id: string;
  slot: SlotId;
  name: string;
  rarity: Rarity;
  desc: string;
  mods?: Partial<Mods>;
  traits?: TraitId[];
  /** SSR / UR 附加的固有技 */
  skill?: { name: string; desc: string; move?: MoveDef; passive?: string };
  /** 外觀強化：改變角色氣場／拖尾顏色 */
  look?: { aura?: string; trail?: string; crown?: string; cape?: boolean; wings?: boolean };
  icon: string;
  value: number; // 出售／分解價值
}

/* ============================ 關卡 ============================ */
export type BiomeId = 'peak' | 'flame' | 'heaven' | 'void';
export type WeatherId = 'petal' | 'ember' | 'ash' | 'snow' | 'light' | 'rain' | 'none';

export interface ScenePalette {
  skyTop: string;
  skyBottom: string;
  haze: string;
  ground: string;
  groundDark: string;
  fog: string;
  light: string;
  tint: string; // 整體色調疊加
  tintAlpha: number;
}

export interface SpawnSpec {
  enemy: string;
  count: number;
  elite?: boolean;
  side?: 'left' | 'right' | 'both' | 'sky';
  delay?: number;
}

export interface WaveDef {
  spawns: SpawnSpec[];
  announce?: string;
  heal?: number;
}

export interface SceneDef {
  id: string;
  name: string;
  biome: BiomeId;
  variant: number; // 同生物群系的不同取景（裁切／色調）
  arenaW: number;
  palette: ScenePalette;
  weather: WeatherId;
  props: string[]; // 程序化前景／中景物件
  waves: WaveDef[];
  boss?: string;
  interlude?: string; // 場景敘事文字
}

export interface StageDef {
  id: string;
  chapter: number;
  index: number;
  name: string;
  subtitle: string;
  desc: string;
  biome: BiomeId;
  scenes: SceneDef[];
  souls: number;
  unlockReq?: { chapter: number; index: number };
  endless?: boolean;
}

/* ============================ 存檔 ============================ */
export interface EquipInstance {
  uid: string;
  def: string;
  level: number;
}

export interface SaveData {
  version: number;
  souls: number;
  totalSouls: number;
  heroLevels: Record<string, number>;
  unlocked: string[];
  upgrades: Record<string, number>;
  inventory: EquipInstance[];
  equipped: Partial<Record<SlotId, string | null>>;
  codex: string[]; // 已見過的法印
  bestiary: string[]; // 已擊殺的敵種
  stats: {
    runs: number;
    kills: number;
    bestCombo: number;
    deepest: string;
    time: number;
    bosses: number;
    wins: number;
  };
  settings: { music: number; sfx: number; quality: 'auto' | 'high' | 'mid' | 'low'; shake: number };
  chestPulls: number;
}

/* ============================ 執行期狀態 ============================ */
export type Phase =
  | 'boot'
  | 'title'
  | 'select'
  | 'hub'
  | 'intro'
  | 'play'
  | 'draft'
  | 'pause'
  | 'clear'
  | 'gameover';

export interface HudSnapshot {
  phase: Phase;
  hp: number;
  hpMax: number;
  shield: number;
  shieldMax: number;
  stamina: number;
  staminaMax: number;
  ult: number; // 0~100
  level: number;
  exp: number;
  expNext: number;
  combo: number;
  comboRank: string;
  comboTimer: number;
  souls: number;
  kills: number;
  scene: string;
  sceneIndex: number;
  sceneCount: number;
  wave: number;
  waveCount: number;
  stageName: string;
  stageSubtitle: string;
  chapter: number;
  heroId: string;
  heroName: string;
  skillA: { cd: number; cdMax: number; ready: boolean };
  skillB: { cd: number; cdMax: number; ready: boolean };
  dashCd: number;
  boss: null | { name: string; title: string; hp: number; hpMax: number; phase: number; active: boolean };
  enemies: number;
  draft: null | { choices: SigilDef[]; rerolls: number; level: number };
  result: null | RunResult;
  sigils: { id: string; name: string; stacks: number; rarity: Rarity }[];
  fps: number;
  time: number;
  buff: { id: string; t: number }[];
}

export interface RunResult {
  win: boolean;
  souls: number;
  kills: number;
  bestCombo: number;
  time: number;
  deepest: string;
  sigils: number;
  level: number;
  drops: EquipInstance[];
  heroId: string;
  bossKilled: string[];
}
