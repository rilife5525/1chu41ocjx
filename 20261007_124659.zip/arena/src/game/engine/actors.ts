/**
 * 角色實體系統
 * ------------------------------------------------------------------
 * Actor 為玩家／敵兵／分身共用的實體；MoveRunner 依事件時間軸推進招式，
 * PlayerController 負責手感（輸入緩衝、連段取消、完美閃避、蓄力），
 * EnemyAI 依九種原型（chaser/spear/ranged/caster/bomber/ninja/brute/shield/boss）行為。
 */
import type { EnemyDef, HeroDef, MoveDef, MoveEvent, HitSpec, ProjId, SfxId, FxId } from '../core/types';
import { DEPTH_MAX, DEPTH_MIN, GRAVITY } from '../core/types';
import { TAU, chance, clamp, damp, rand } from '../core/util';
import type { IWorld } from './combat';
import type { StatusKind } from './combat';
import { applyStatus, resolveHit } from './combat';
import type { Input } from './input';

export type ActorState =
  | 'idle' | 'run' | 'jump' | 'fall' | 'dash' | 'attack' | 'skill'
  | 'charge' | 'hurt' | 'down' | 'dead' | 'spawn' | 'ult' | 'cast' | 'blink';

export interface Status {
  kind: StatusKind; t: number; dur: number; power: number; stacks: number; tick: number;
}

interface PendingHit { hit: HitSpec; left: number; gap: number; t: number; diveScale: number; }

let uidSeq = 1;

export class Actor {
  uid = uidSeq++;
  team: 'player' | 'enemy' | 'ally' = 'enemy';
  hero: HeroDef | null = null;
  def: EnemyDef | null = null;

  x = 0; y = 0; z = 0;
  vx = 0; vy = 0; vz = 0;
  facing: 1 | -1 = 1;
  grounded = true;
  airborne = false;
  launched = false;
  maxZ = 0;

  hp = 100; maxHp = 100;
  stamina = 100; staminaMax = 100;
  shield = 0;
  atkMul = 1;
  armor = 0;
  weight = 1;
  speedMul = 1;
  radius = 26; height = 90; scale = 1;

  state: ActorState = 'idle';
  stateT = 0;
  animT = 0;
  move: MoveDef | null = null;
  moveT = 0;
  eventIdx = 0;
  hitIds = new Set<number>();
  pending: PendingHit[] = [];
  invuln = 0;
  hitstun = 0;
  flashT = 0;
  dead = false;
  deadT = 0;
  dashing = 0;
  dashCd = 0;
  superArmor = 0;

  /* 玩家專用 */
  comboStep = 0;
  airStep = 0;
  airJumps = 1;
  airJumpsMax = 1;
  skillCd: [number, number] = [0, 0];
  chargeT = 0;
  charging = false;
  buffer: { act: 'attack' | 'heavy' | 'jump' | 'dash'; t: number } | null = null;
  buffT = 0; // 鬼王咆哮等自我強化
  buffMul = 1;

  /* 敵人專用 */
  aiT = 0;
  aiState: 'approach' | 'circle' | 'windup' | 'attack' | 'recover' | 'reposition' | 'flee' | 'blink' = 'approach';
  atkCds: number[] = [];
  aggro = 0;
  spawnT = 0;
  phase = 0;
  elite = false;
  buffed = 0;
  targetX = 0;
  targetY = 0;
  circleDir = 1;
  stunVisual = 0;

  status: Status[] = [];
  marked = false;

  /** 招式位移衝量剩餘時間（期間不套用摩擦力） */
  moveImpulseT = 0;
  /** 玩家精力回復速率（每秒） */
  staminaRegen = 18;
  /** AI 目前準備施放的攻擊 */
  pendingAttack: { range: number; cd: number; windup: number; move: MoveDef; chance?: number } | null = null;
  /** 目前招式的附加參數 */
  moveOpts: { charged?: boolean; diveScale?: number; skillMul?: number } = {};

  get moveProgress() { return this.move ? clamp(this.moveT / this.move.duration, 0, 1) : 0; }
}

/* ============================ 建立實體 ============================ */
export function createPlayer(hero: HeroDef, mods: { hpMax: number; staminaMax: number; speedMul: number; jumpMul: number; atkMul: number; armor: number; shieldMax: number }): Actor {
  const a = new Actor();
  a.team = 'player';
  a.hero = hero;
  a.maxHp = Math.round(hero.base.hp + mods.hpMax);
  a.hp = a.maxHp;
  a.staminaMax = Math.round(hero.base.stamina + mods.staminaMax);
  a.stamina = a.staminaMax;
  a.speedMul = mods.speedMul;
  a.atkMul = hero.base.atk * mods.atkMul * 0.1;
  a.armor = mods.armor;
  a.weight = hero.base.weight;
  a.radius = 26; a.height = 96; a.scale = 1;
  a.shield = mods.shieldMax;
  a.airJumpsMax = hero.id === 'shuangling' ? 2 : 1;
  a.airJumps = a.airJumpsMax;
  return a;
}

export function createEnemy(def: EnemyDef, opts: { x: number; y: number; elite?: boolean; scale?: { hp: number; atk: number; speed: number } }): Actor {
  const a = new Actor();
  a.team = 'enemy';
  a.def = def;
  const sc = opts.scale ?? { hp: 1, atk: 1, speed: 1 };
  const eliteMul = opts.elite ? 2.4 : 1;
  a.maxHp = Math.round(def.hp * sc.hp * eliteMul);
  a.hp = a.maxHp;
  a.atkMul = def.atk * sc.atk * (opts.elite ? 1.35 : 1) * 0.1;
  a.weight = def.weight;
  a.radius = def.radius;
  a.height = def.height;
  a.scale = def.scale * (opts.elite ? 1.22 : 1);
  a.elite = !!opts.elite;
  a.x = opts.x; a.y = opts.y; a.z = def.flying ? 90 : 0;
  a.grounded = !def.flying;
  a.speedMul = sc.speed;
  a.armor = def.rank === '首領' ? 0.25 : def.ai === 'brute' ? 0.15 : 0;
  a.superArmor = def.rank === '首領' ? 999 : def.ai === 'brute' ? 3 : 0;
  a.atkCds = def.attacks.map(() => rand(0.3, 1.4));
  a.state = 'spawn';
  a.spawnT = 0;
  a.phase = 0;
  return a;
}

/* ============================ 招式執行 ============================ */
export function startMove(a: Actor, move: MoveDef, w: IWorld, opts: { charged?: boolean; diveScale?: number; skillMul?: number; silent?: boolean } = {}) {
  a.move = move;
  a.moveT = 0;
  a.eventIdx = 0;
  a.hitIds.clear();
  a.pending.length = 0;
  a.state = move.kind === 'skill' || move.kind === 'ult' ? 'skill' : 'attack';
  a.stateT = 0;
  a.moveOpts = opts;
  if (move.invuln) a.invuln = Math.max(a.invuln, move.invuln[1] - move.invuln[0]);
  if (!opts.silent && move.kind === 'skill') w.sfx('charge', 0.5, 1.2);
}

function fireEvent(a: Actor, w: IWorld, ev: MoveEvent, opts: { charged?: boolean; diveScale?: number; skillMul?: number }) {
  const dir = a.facing;
  const isPlayer = a.team === 'player';
  switch (ev.type) {
    case 'hit': {
      const hit: HitSpec = {
        t: ev.t, dur: ev.dur, dmg: ev.dmg, ox: ev.ox, oy: ev.oy, w: ev.w, h: ev.h,
        kb: ev.kb, hitstop: ev.hitstop, shake: ev.shake, launch: ev.launch,
        multi: ev.multi, multiGap: ev.multiGap, pierce: ev.pierce, aoe: ev.aoe, fx: ev.fx, sfx: ev.sfx,
      };
      const dmgMul = (opts.charged ? 1 + (isPlayer ? w.mods.chargeDmg : 0) : 1) * (a.buffMul ?? 1) * (opts.skillMul ?? 1);
      const scaled: HitSpec = { ...hit, dmg: hit.dmg * dmgMul };
      if (ev.multi && ev.multi > 1) {
        a.pending.push({ hit: scaled, left: ev.multi, gap: ev.multiGap ?? 0.1, t: 0, diveScale: opts.diveScale ?? 1 });
      } else {
        resolveHit(a, scaled, w, {
          fx: ev.fx, color: undefined, diveScale: opts.diveScale, attacker: a,
        });
      }
      // 命中特效
      w.fx.spawn(ev.fx, a.x + hit.ox * dir, a.y, a.z + 50 + hit.oy, {
        dir: dir, scale: (hit.w / 110) * (isPlayer ? w.mods.aoeMul : 1), color: undefined,
      });
      break;
    }
    case 'proj': {
      const extra = isPlayer ? w.mods.projExtra : 0;
      const count = (ev.count ?? 1) + (extra > 0 ? Math.round(extra * (ev.count && ev.count > 3 ? 0.6 : 1)) : 0);
      const spread = ev.spread ?? 0;
      const homing = isPlayer && w.traits.has('projHoming') ? Math.max(ev.homing ?? 0, 2.6) : ev.homing;
      const speed = (ev.speed ?? 600) * (isPlayer ? w.mods.projSpeedMul : 1) * w.stageScale.speed;
      for (let i = 0; i < count; i++) {
        const off = count > 1 ? (i / (count - 1) - 0.5) * spread : 0;
        const p = w.projectiles.spawn({
          def: ev.proj as ProjId, team: isPlayer ? 'player' : 'enemy',
          x: a.x + (ev.ox ?? 40) * dir, y: a.y, z: a.z + (ev.oz ?? 60),
          dir, angle: off, speed, dmg: ev.dmg * (opts.charged ? 1 + w.mods.chargeDmg : 1) * a.buffMul * (a.team === 'player' ? 1 : w.stageScale.atk * 0.9),
          size: ev.size ?? 1, life: ev.life, homing, owner: a,
        });
        if (p && isPlayer && w.traits.has('projPierce')) p.pierce += 2;
      }
      if (ev.fx) w.fx.spawn(ev.fx, a.x + (ev.ox ?? 40) * dir, a.y, a.z + (ev.oz ?? 60), { dir, scale: 0.8 });
      if (ev.sfx) w.sfx(ev.sfx, 0.8);
      break;
    }
    case 'fx':
      w.fx.spawn(ev.fx as FxId, a.x + (ev.ox ?? 0) * dir, a.y + (ev.oy ?? 0), a.z + (ev.oz ?? 40), {
        dir, scale: ev.scale ?? 1, color: ev.color, x2: a.x + 700 * dir,
      });
      break;
    case 'sfx':
      w.sfx(ev.sfx as SfxId, ev.vol ?? 1, ev.rate ?? 1);
      break;
    case 'move': {
      const dur = ev.dur ?? 0.14;
      a.vx += (ev.vx ?? 0) * dir;
      a.vy += ev.vy ?? 0;
      a.vz += ev.vz ?? 0;
      if (ev.vz && ev.vz > 200) { a.grounded = false; }
      a.moveImpulseT = dur;
      break;
    }
    case 'shake':
      w.shake(ev.amount);
      break;
    case 'flash':
      w.screen.flash(ev.color ?? '#ffffff', ev.alpha ?? 0.4, ev.dur ?? 0.2);
      break;
  }
}

/** 推進招式時間軸（含多段判定） */
export function advanceMove(a: Actor, w: IWorld, dt: number) {
  if (!a.move) return;
  const opts = a.moveOpts ?? {};
  a.moveT += dt;
  // 無敵區間
  if (a.move.invuln) {
    const [s, e] = a.move.invuln;
    a.invuln = a.moveT >= s && a.moveT <= e ? Math.max(a.invuln, 0.05) : a.invuln;
  }
  while (a.eventIdx < a.move.events.length && a.move.events[a.eventIdx].t <= a.moveT) {
    fireEvent(a, w, a.move.events[a.eventIdx], opts);
    a.eventIdx++;
  }
  // 多段判定
  for (let i = a.pending.length - 1; i >= 0; i--) {
    const p = a.pending[i];
    p.t -= dt;
    if (p.t <= 0) {
      a.hitIds.clear();
      resolveHit(a, p.hit, w, { fx: p.hit.fx, diveScale: p.diveScale, attacker: a });
      p.left--;
      p.t = p.gap;
      if (p.left <= 0) a.pending.splice(i, 1);
    }
  }
  if (a.moveT >= a.move.duration) endMove(a);
}

export function endMove(a: Actor) {
  a.move = null;
  a.moveT = 0;
  a.eventIdx = 0;
  a.pending.length = 0;
  a.hitIds.clear();
  if (a.state === 'attack' || a.state === 'skill') { a.state = a.grounded ? 'idle' : 'fall'; a.stateT = 0; }
}

/** 是否處於可取消窗口（連段手感關鍵） */
export function canCancel(a: Actor) {
  if (!a.move) return false;
  const cancelAt = a.move.kind === 'combo' ? 0.52 : a.move.kind === 'skill' ? 0.72 : 0.6;
  return a.moveT >= a.move.duration * cancelAt;
}

/* ============================ 通用物理 ============================ */
export function physics(a: Actor, w: IWorld, dt: number) {
  const friction = a.grounded ? 9.5 : 2.2;
  if (a.moveImpulseT > 0) {
    a.moveImpulseT -= dt;
  } else if (a.state !== 'dash') {
    const f = Math.exp(-friction * dt);
    a.vx *= f; a.vy *= f;
  }
  // 重力
  const flying = a.def?.flying;
  if (!flying || a.launched) {
    a.vz -= GRAVITY * dt;
    a.z += a.vz * dt;
    if (a.z <= 0) {
      if (!a.grounded && a.vz < -320) {
        // 落地演出
        w.fx.dust(a.x, a.y, { color: '#c8b89a', w: a.team === 'player' ? 56 : 46, scale: 0.8 });
        if (a.team === 'player') w.sfx('land', 0.5, clamp(1 + Math.abs(a.vz) / 2200, 0.8, 1.5));
        if (a.launched && a.team === 'enemy') {
          a.state = 'down'; a.stateT = 0; a.hitstun = 0.7;
          w.shake(9);
          w.ps.emit({ kind: 'dust', x: a.x, y: a.y, z: 6, count: Math.round(10 * w.quality), speed: [80, 300], vz: [40, 200], life: [0.3, 0.7], size: [10, 26], color: '#c8b89a', grav: 60 });
        }
      }
      a.z = 0; a.vz = 0; a.grounded = true; a.airborne = false;
      if (a.team === 'player') { a.airJumps = a.airJumpsMax; a.airStep = 0; }
      a.launched = false;
      a.maxZ = 0;
    } else {
      a.grounded = false;
      a.airborne = true;
      a.maxZ = Math.max(a.maxZ, a.z);
    }
  } else {
    // 飛行單位：維持高度並轻微漂浮
    a.z = damp(a.z, 90 + Math.sin(w.time * 2 + a.uid) * 12, 4, dt);
    a.vz = 0;
    a.grounded = false;
  }

  a.x += a.vx * dt;
  a.y += a.vy * dt;
  a.y = clamp(a.y, DEPTH_MIN, DEPTH_MAX);
  a.x = clamp(a.x, 46, w.arenaW - 46);

  if (a.invuln > 0) a.invuln -= dt;
  if (a.dashCd > 0) a.dashCd -= dt;
  if (a.dashing > 0) a.dashing -= dt;
  if (a.flashT > 0) a.flashT -= dt;
  if (a.hitstun > 0) a.hitstun -= dt;
  if (a.buffT > 0) { a.buffT -= dt; if (a.buffT <= 0) a.buffMul = 1; }
  if (a.buffed > 0) a.buffed -= dt;
  a.stateT += dt;
  a.animT += dt;
  a.speedMul = damp(a.speedMul, 1, 2, dt);
  if (a.team === 'player') {
    for (let i = 0; i < 2; i++) if (a.skillCd[i] > 0) a.skillCd[i] = Math.max(0, a.skillCd[i] - dt);
    a.stamina = Math.min(a.staminaMax, a.stamina + (a.staminaRegen ?? 18) * dt);
  }
  if (a.dead) a.deadT += dt;
  if (a.stunVisual > 0) a.stunVisual -= dt;
}



/* ============================ 玩家控制 ============================ */
export function airLightMoves(hero: HeroDef) {
  return hero.air.filter((m) => m.kind === 'air' && m.tag !== 'dive');
}
export function findDive(hero: HeroDef) {
  return hero.air.find((m) => m.tag === 'dive') ?? hero.air[hero.air.length - 1];
}
export function findLauncher(hero: HeroDef) {
  return [...hero.air, ...hero.combo].find((m) => m.kind === 'launcher') ?? hero.combo[0];
}

export function updatePlayer(p: Actor, w: IWorld, input: Input, dt: number) {
  if (p.dead) return;
  const hero = p.hero!;
  const m = w.mods;
  const busy = p.state === 'attack' || p.state === 'skill' || p.state === 'charge' || p.state === 'ult';

  // 輸入緩衝
  if (p.buffer) { p.buffer.t -= dt; if (p.buffer.t <= 0) p.buffer = null; }
  const buf = (act: 'attack' | 'heavy' | 'jump' | 'dash') => {
    if (input.press(act)) p.buffer = { act, t: 0.26 };
    return p.buffer?.act === act;
  };
  const wantAttack = buf('attack');
  const wantHeavy = buf('heavy');
  const wantJump = buf('jump');
  const wantDash = buf('dash');

  // 硬直中
  if (p.hitstun > 0) {
    p.state = p.grounded ? 'hurt' : 'fall';
    return;
  }

  const axis = input.axis();

  /* -------- 衝刺 -------- */
  if (wantDash && p.dashCd <= 0 && p.stamina >= 10 && p.state !== 'dash') {
    const dashDir = Math.abs(axis.x) > 0.1 ? Math.sign(axis.x) : p.facing;
    p.state = 'dash'; p.stateT = 0; p.dashing = 0.24;
    p.invuln = Math.max(p.invuln, m.dodgeChance > 0 ? 0.3 : 0.24);
    p.dashCd = 0.62 * m.dashCdMul;
    p.stamina -= 10;
    p.vx = dashDir * hero.base.speed * 2.9 * m.speedMul;
    p.vy = axis.y * hero.base.speed * 1.2;
    p.facing = dashDir > 0 ? 1 : -1;
    p.buffer = null;
    w.sfx('dash', 0.7);
    w.fx.ghost(p.x, p.y, p.z, { color: hero.palette.aura, dir: dashDir, scale: p.scale });
    // 完美閃避判定：附近是否有敵人正在前搖
    if (w.traits.has('perfectDodge')) {
      for (const e of w.actors) {
        if (e.dead || e.team === 'player') continue;
        if (Math.hypot(e.x - p.x, (e.y - p.y) * 2) < 210 && e.aiState === 'windup') {
          w.screen.slowmo(0.22, 1.4);
          w.screen.flash('#9fe8ff', 0.4, 0.3);
          w.fx.ring(p.x, p.y, 60, { color: '#9fe8ff', w: 260, h: 90, dur: 0.6 });
          w.texts.spawn({ x: p.x, y: p.y, z: p.height + 60, text: '見切！', color: '#9fe8ff', style: 'buff', size: 34 });
          w.sfx('uiBig', 0.8, 1.4);
          p.stamina = p.staminaMax;
          p.dashCd = 0;
          break;
        }
      }
    }
    if (w.traits.has('dashFireTrail') || w.traits.has('dashIceTrail')) {
      const fire = w.traits.has('dashFireTrail');
      w.fx.wave(p.x, p.y, { color: fire ? '#ff6a1a' : '#9fe8ff', color2: fire ? '#ffc93c' : '#eaf6ff', dir: dashDir, w: 260, h: 60, dur: 0.7 });
      for (const e of w.actors) {
        if (e.dead) continue;
        if (Math.abs(e.x - p.x) < 150 && Math.abs(e.y - p.y) < 46) {
          if (fire) applyStatus(e, 'burn', 2.5, 6 + p.atkMul * 6);
          else applyStatus(e, 'freeze', 2, 0);
        }
      }
    }
    if (w.traits.has('dashStrike')) {
      resolveHit(p, {
        t: 0, dur: 0.2, dmg: p.atkMul * 6, ox: 40, oy: 0, w: 120, h: 90,
        kb: { x: 300, y: 0, z: 120 }, hitstop: 0.04, shake: 6, fx: 'slashWind', sfx: 'hit', pierce: true,
      }, w, { attacker: p });
    }
    return;
  }

  /* -------- 蓄力重擊 -------- */
  if (p.grounded && !busy && input.down('heavy')) {
    p.chargeT += dt;
    if (p.chargeT > 0.22 && !p.charging) {
      p.charging = true;
      p.state = 'charge'; p.stateT = 0;
      w.sfx('charge', 0.6, 0.9);
    }
    if (p.charging) {
      w.fx.aura(p.x, p.y, 0, { color: hero.palette.aura, color2: hero.palette.trim, w: 70 + Math.min(60, p.chargeT * 90), h: 130, dur: 0.12 });
      p.vx *= 0.8;
      return;
    }
  }
  if (p.charging && (input.wasReleased('heavy') || !input.down('heavy'))) {
    const charged = p.chargeT > 0.4;
    p.charging = false;
    const launch = findLauncher(hero);
    startMove(p, launch, w, { charged });
    if (charged) {
      w.screen.shake(12);
      w.screen.flash(hero.palette.aura, 0.28, 0.2);
      w.fx.ring(p.x, p.y, 20, { color: hero.palette.aura, w: 300, h: 100, dur: 0.5 });
      w.texts.spawn({ x: p.x, y: p.y, z: p.height + 70, text: '蓄力！', color: hero.palette.trim, style: 'buff', size: 30 });
    }
    p.chargeT = 0;
    p.buffer = null;
    return;
  }
  if (!input.down('heavy')) p.chargeT = 0;

  /* -------- 攻擊 -------- */
  if (wantHeavy && !p.charging) {
    if (p.grounded && (!busy || canCancel(p))) {
      startMove(p, findLauncher(hero), w, {});
      p.buffer = null;
      return;
    }
    if (!p.grounded && (p.state !== 'skill' || canCancel(p))) {
      const dive = findDive(hero);
      const diveScale = 1 + clamp(p.maxZ / 380, 0, 1.3) * (w.traits.has('h_lin1' as never) ? 1.5 : 1);
      startMove(p, dive, w, { diveScale });
      p.vz = Math.min(p.vz, -200);
      p.buffer = null;
      w.texts.spawn({ x: p.x, y: p.y, z: p.height + 50, text: `x${diveScale.toFixed(1)}`, color: '#ffc93c', style: 'buff', size: 22 });
      return;
    }
  }
  if (wantAttack) {
    if (p.grounded && (!busy || canCancel(p))) {
      const list = hero.combo;
      let idx = p.comboStep;
      if (busy && canCancel(p) && p.move?.next) {
        const nx = list.findIndex((mm) => mm.id === p.move!.next);
        idx = nx >= 0 ? nx : (idx + 1) % list.length;
      } else if (!busy) idx = 0;
      startMove(p, list[idx], w, {});
      p.comboStep = (idx + 1) % list.length;
      p.buffer = null;
      return;
    }
    if (!p.grounded && (!busy || canCancel(p))) {
      const list = airLightMoves(hero);
      const extend = w.traits.has('airComboMaster') ? 4 : list.length;
      let idx = p.airStep % Math.max(1, list.length);
      if (!busy) idx = 0;
      const mv = list[idx] ?? list[list.length - 1];
      startMove(p, mv, w, {});
      p.airStep = (p.airStep + 1) % Math.max(1, Math.min(extend, list.length * 2));
      p.buffer = null;
      return;
    }
  }

  /* -------- 跳躍 -------- */
  if (wantJump && (p.grounded || p.airJumps > 0)) {
    if (!p.grounded) {
      p.airJumps--;
      w.fx.ring(p.x, p.y, p.z + 20, { color: hero.palette.aura, w: 130, h: 44, dur: 0.36 });
      w.ps.emit({ kind: 'feather', x: p.x, y: p.y, z: p.z + 10, count: Math.round(8 * w.quality), speed: [40, 200], vz: [-40, 60], life: [0.4, 0.9], size: [4, 10], color: hero.palette.trim, grav: 120 });
    } else {
      w.fx.spawn('jumpDust', p.x, p.y, 4, { scale: 0.9 });
    }
    p.vz = hero.base.jump * m.jumpMul * (p.grounded ? 1 : 0.86);
    p.grounded = false;
    p.state = 'jump'; p.stateT = 0;
    p.buffer = null;
    w.sfx('jump', 0.6, p.grounded ? 1 : 1.25);
    return;
  }

  /* -------- 仙術 -------- */
  const trySkill = (i: 0 | 1) => {
    const mv = i === 0 ? hero.skillA : hero.skillB;
    if (p.skillCd[i] > 0 || p.stamina < (mv.stamina ?? 0)) {
      if (p.stamina < (mv.stamina ?? 0)) {
        w.texts.spawn({ x: p.x, y: p.y, z: p.height + 40, text: '精力不足', color: '#7fb2d9', style: 'buff', size: 18 });
      }
      return false;
    }
    p.stamina -= mv.stamina ?? 0;
    p.skillCd[i] = (mv.cd ?? 6) * (1 - clamp(m.cdReduce, 0, 0.6));
    startMove(p, mv, w, { skillMul: 1 });
    p.buffer = null;
    w.screen.punch(0.06);
    return true;
  };
  if (input.press('skillA') && (p.hitstun <= 0)) { if (trySkill(0)) return; }
  if (input.press('skillB') && (p.hitstun <= 0)) { if (trySkill(1)) return; }

  /* -------- 移動 -------- */
  if (busy && p.state !== 'dash') {
    // 出招中仍可微量位移（手感）
    const k = 0.25;
    p.vx = damp(p.vx, axis.x * hero.base.speed * m.speedMul * k, 8, dt);
    p.vy = damp(p.vy, axis.y * hero.base.speed * 0.55 * m.speedMul * k, 8, dt);
  } else if (p.state === 'dash') {
    if (p.stateT > 0.22) { p.state = p.grounded ? 'idle' : 'fall'; }
  } else {
    const sp = hero.base.speed * m.speedMul * (p.grounded ? 1 : 0.92) * (p.buffMul > 1 ? 1.1 : 1);
    p.vx = damp(p.vx, axis.x * sp, 16, dt);
    p.vy = damp(p.vy, axis.y * sp * 0.56, 16, dt);
    if (Math.abs(axis.x) > 0.15 && !(p.move?.lockTurn)) p.facing = axis.x > 0 ? 1 : -1;
    p.state = p.grounded ? (axis.mag > 0.12 ? 'run' : 'idle') : p.vz > 0 ? 'jump' : 'fall';
  }
  if (p.state === 'dash' && w.quality > 0.4) {
    w.ps.emit({ kind: 'trail', x: p.x, y: p.y, z: p.height * 0.5, count: 1, speed: [0, 10], life: [0.16, 0.3], size: [p.height * 0.8, p.height], color: hero.palette.aura, additive: true, drag: 0 });
  }
}

/* ============================ 敵人 AI ============================ */
export function updateEnemy(e: Actor, w: IWorld, dt: number) {
  if (e.dead) return;
  const def = e.def!;
  const p = w.player;
  if (e.state === 'spawn') {
    e.spawnT += dt;
    if (e.spawnT > 0.55) { e.state = 'idle'; e.stateT = 0; }
    return;
  }
  if (e.hitstun > 0) {
    if (e.state !== 'down' && e.state !== 'hurt') { e.state = e.grounded ? 'hurt' : 'fall'; }
    return;
  }
  if (e.state === 'down') {
    if (e.stateT > 0.62) { e.state = 'idle'; e.stateT = 0; }
    return;
  }
  if (e.state === 'blink') {
    if (e.stateT > 0.3) { e.state = 'idle'; }
    return;
  }

  // 出招中
  if (e.move) {
    if (e.aiState === 'attack' && e.moveT >= e.move.duration * 0.92) {
      e.aiState = 'recover'; e.aiT = rand(0.25, 0.6) / (def.rank === '首領' ? 1.5 : 1);
    }
    return;
  }

  const dx = p.x - e.x, dy = p.y - e.y;
  const dist = Math.hypot(dx, Math.abs(dy) * 2);
  e.aggro = clamp(e.aggro + dt * 0.6, 0, 1);
  const speed = def.speed * e.speedMul * (e.buffed > 0 ? 1.25 : 1) * (def.rank === '首領' ? 1 + e.phase * 0.12 : 1);
  const faceTarget = () => { if (Math.abs(dx) > 12) e.facing = dx > 0 ? 1 : -1; };

  // 冷卻
  for (let i = 0; i < e.atkCds.length; i++) if (e.atkCds[i] > 0) e.atkCds[i] -= dt;

  e.aiT -= dt;

  switch (e.aiState) {
    case 'approach': {
      faceTarget();
      const desired = def.ai === 'ranged' || def.ai === 'caster' ? 360 : def.ai === 'spear' ? 130 : 54;
      if (dist > desired + 20) {
        const nx = dx / (dist || 1), ny = dy / (Math.abs(dy) || 1);
        e.vx = damp(e.vx, nx * speed, 6, dt);
        e.vy = damp(e.vy, clamp(ny, -1, 1) * speed * 0.5, 6, dt);
        e.state = 'run';
      } else {
        e.aiState = def.ai === 'ranged' || def.ai === 'caster' ? 'circle' : 'attack';
        e.aiT = 0;
      }
      // 特殊：忍者瞬身接近
      if (def.ai === 'ninja' && dist > 240 && chance(dt * 0.5)) {
        e.aiState = 'blink'; e.state = 'blink'; e.stateT = 0;
        const tx = p.x - Math.sign(dx) * 70;
        w.ps.emit({ kind: 'smoke', x: e.x, y: e.y, z: e.height * 0.5, count: Math.round(10 * w.quality), speed: [40, 180], life: [0.3, 0.6], size: [10, 26], color: '#5b6bd6' });
        e.x = clamp(tx, 40, w.arenaW - 40);
        e.y = clamp(p.y + rand(-30, 30), DEPTH_MIN, DEPTH_MAX);
        w.ps.emit({ kind: 'smoke', x: e.x, y: e.y, z: e.height * 0.5, count: Math.round(10 * w.quality), speed: [40, 180], life: [0.3, 0.6], size: [10, 26], color: '#5b6bd6' });
        w.sfx('dash', 0.4, 1.5);
      }
      // 術士：玩家貼近就瞬移拉開
      if (def.ai === 'caster' && dist < 150 && chance(dt * 1.2)) {
        const away = Math.sign(dx) * -1 || 1;
        w.ps.emit({ kind: 'rune', x: e.x, y: e.y, z: e.height * 0.5, count: Math.round(10 * w.quality), speed: [40, 160], life: [0.3, 0.7], size: [6, 14], color: '#ffd76a', additive: true });
        e.x = clamp(e.x + away * rand(220, 340), 40, w.arenaW - 40);
        e.y = clamp(e.y + rand(-60, 60), DEPTH_MIN, DEPTH_MAX);
        e.aiState = 'circle'; e.aiT = 0.4;
        w.sfx('wind', 0.4, 1.4);
      }
      if (e.aiT <= 0 && dist > desired) { e.aiT = rand(0.2, 0.5); }
      tryAttack(e, w, dist);
      break;
    }
    case 'circle': {
      faceTarget();
      e.circleDir = e.circleDir || (chance(0.5) ? 1 : -1);
      const desired = def.ai === 'caster' ? 420 : 380;
      const nx = dx / (dist || 1);
      const push = dist < desired - 60 ? -1 : dist > desired + 60 ? 1 : 0;
      e.vx = damp(e.vx, (nx * push * speed + -Math.sign(dy || 1) * e.circleDir * speed * 0.3), 5, dt);
      e.vy = damp(e.vy, e.circleDir * speed * 0.42, 5, dt);
      e.state = 'run';
      if (e.aiT <= 0) { e.aiState = 'attack'; e.aiT = 0; e.circleDir *= -1; }
      tryAttack(e, w, dist);
      break;
    }
    case 'windup': {
      e.state = 'cast';
      e.vx *= 0.86; e.vy *= 0.86;
      // 前搖警示
      if (w.quality > 0.3 && chance(dt * 20)) {
        w.ps.emit({ kind: 'ember', x: e.x + rand(-20, 20), y: e.y, z: rand(10, e.height), count: 1, speed: [10, 40], vz: [40, 120], life: [0.2, 0.4], size: [2, 5], color: e.def?.colors.aura ?? '#ff3b52', additive: true });
      }
      if (e.aiT <= 0) {
        const atk = e.pendingAttack;
        e.pendingAttack = null;
        if (atk) {
          e.aiState = 'attack';
          faceTarget();
          startMove(e, atk.move, w, { skillMul: e.buffed > 0 ? 1.25 : 1 });
        } else { e.aiState = 'approach'; }
      }
      break;
    }
    case 'attack':
      if (!e.move) { e.aiState = 'recover'; e.aiT = rand(0.3, 0.7); }
      break;
    case 'recover': {
      e.state = 'idle';
      e.vx *= 0.9; e.vy *= 0.9;
      faceTarget();
      if (e.aiT <= 0) { e.aiState = dist > 200 ? 'approach' : 'circle'; e.aiT = rand(0.4, 1.1); }
      break;
    }
    case 'reposition': {
      e.state = 'run';
      const tx = e.targetX, ty = e.targetY;
      const d2 = Math.hypot(tx - e.x, ty - e.y);
      if (d2 < 24 || e.aiT <= 0) { e.aiState = 'approach'; e.aiT = 0; }
      else {
        e.vx = damp(e.vx, ((tx - e.x) / d2) * speed, 6, dt);
        e.vy = damp(e.vy, ((ty - e.y) / d2) * speed * 0.6, 6, dt);
        e.facing = tx > e.x ? 1 : -1;
      }
      break;
    }
    case 'flee': {
      e.state = 'run';
      const nx = dx / (dist || 1);
      e.vx = damp(e.vx, -nx * speed * 1.1, 6, dt);
      e.vy = damp(e.vy, rand(-1, 1) * speed * 0.4, 6, dt);
      if (e.aiT <= 0) { e.aiState = 'circle'; e.aiT = rand(0.6, 1.4); }
      break;
    }
    case 'blink':
      break;
  }

  // 首領階段轉換
  if (def.boss) {
    const hpP = e.hp / e.maxHp;
    const thresholds = def.boss.enrageHp;
    const newPhase = thresholds.filter((t) => hpP < t).length;
    if (newPhase > e.phase) {
      e.phase = newPhase;
      e.atkMul *= 1.16;
      w.screen.flash('#ff2d40', 0.4, 0.5);
      w.shake(30);
      w.sfx('bossRoar', 1, 1 + e.phase * 0.1);
      w.fx.ring(e.x, e.y, e.height * 0.5, { color: def.colors.aura, w: 620, h: 200, dur: 0.9 });
      w.fx.pillar(e.x, e.y, { color: def.colors.aura, color2: def.colors.trim, w: e.radius * 4, h: 1100, dur: 1.1 });
      w.ps.emit({ kind: 'ember', x: e.x, y: e.y, z: e.height * 0.5, count: Math.round(60 * w.quality), speed: [120, 620], vz: [100, 700], life: [0.6, 1.6], size: [4, 14], color: def.colors.aura, additive: true });
      e.hitstun = 0;
      e.invuln = 0.7;
      w.texts.spawn({ x: e.x, y: e.y, z: e.height + 90, text: `第 ${e.phase + 1} 形態`, color: '#ff3b52', style: 'big', size: 40 });
    }
  }

  // 敵人之間的推擠（避免重疊成一團）
  for (const o of w.actors) {
    if (o === e || o.dead) continue;
    const ox = e.x - o.x, oy = (e.y - o.y) * 1.8;
    const d = Math.hypot(ox, oy);
    const min = (e.radius + o.radius) * 0.86;
    if (d < min && d > 0.01) {
      const push = (min - d) * 5.4;
      e.vx += (ox / d) * push * dt * 6;
      e.vy += (oy / d) * push * dt * 3;
    }
  }
}



function tryAttack(e: Actor, w: IWorld, dist: number) {
  const def = e.def!;
  if (e.aiState === 'windup' || e.move) return;
  for (let i = 0; i < def.attacks.length; i++) {
    const atk = def.attacks[i];
    if (e.atkCds[i] > 0) continue;
    if (atk.chance !== undefined && !chance(atk.chance * 0.2)) continue;
    if (dist > atk.range) continue;
    e.atkCds[i] = atk.cd * (def.rank === '首領' ? Math.max(0.5, 1 - e.phase * 0.16) : 1) * rand(0.9, 1.15);
    e.pendingAttack = atk;
    e.aiState = 'windup';
    e.aiT = atk.windup * (def.rank === '首領' ? Math.max(0.62, 1 - e.phase * 0.12) : 1);
    e.vx *= 0.3; e.vy *= 0.3;
    w.sfx('charge', 0.24, def.rank === '首領' ? 0.7 : 1.3);
    return;
  }
}

/* ============================ 分身／召喚 ============================ */
export function createShade(hero: HeroDef, x: number, y: number): Actor {
  const a = new Actor();
  a.team = 'ally';
  a.hero = hero;
  a.maxHp = a.hp = 1;
  a.atkMul = hero.base.atk * 0.05;
  a.radius = 22; a.height = 92; a.scale = 0.94;
  a.x = x; a.y = y;
  a.invuln = 9999;
  a.speedMul = 1;
  return a;
}

export function updateAlly(a: Actor, w: IWorld, dt: number) {
  if (a.dead) return;
  const p = w.player;
  // 尋找最近敵人並攻擊
  let best: Actor | null = null, bd = 620;
  for (const e of w.actors) {
    if (e.dead) continue;
    const d = Math.hypot(e.x - a.x, (e.y - a.y) * 2);
    if (d < bd) { bd = d; best = e; }
  }
  if (!best) {
    a.x = damp(a.x, p.x - p.facing * 70, 3, dt);
    a.y = damp(a.y, p.y + 20, 3, dt);
    a.facing = p.facing;
    a.state = 'idle';
    return;
  }
  const dx = best.x - a.x, dy = best.y - a.y;
  const d = Math.hypot(dx, Math.abs(dy) * 2) || 1;
  a.facing = dx > 0 ? 1 : -1;
  if (d > 90) {
    a.vx = damp(a.vx, (dx / d) * 380, 6, dt);
    a.vy = damp(a.vy, (dy / Math.abs(dy || 1)) * 200, 6, dt);
    a.state = 'run';
  } else {
    a.vx *= 0.9; a.vy *= 0.9;
    a.aiT -= dt;
    if (a.aiT <= 0 && !a.move) {
      a.aiT = rand(0.5, 0.9);
      const list = a.hero!.combo;
      startMove(a, list[(Math.random() * list.length) | 0], w, { skillMul: 0.5, silent: true });
    }
  }
  if (w.quality > 0.4 && chance(dt * 14)) {
    w.ps.emit({ kind: 'trail', x: a.x, y: a.y, z: a.height * 0.5, count: 1, speed: [0, 6], life: [0.2, 0.4], size: [a.height * 0.7, a.height], color: '#1a0a14', additive: false, drag: 0 });
  }
  void TAU;
}
