/**
 * 投射物系統
 * ------------------------------------------------------------------
 * 12 種投射物，每一種都有獨立的飛行行為、碰撞規則、命中演出與繪製方式：
 * 火球／水刃／羽刃／岩礫／妖火／雷矛／鐵波／妖箭／咒符／爆蟲／首領光束／星焰。
 * 支援追蹤、穿透、分裂、重力拋體、彈跳、持續判定等特性。
 */
import type { Actor } from './actors';
import { areaDamage, damage } from './combat';
import type { IWorld } from './combat';
import type { ProjId } from '../core/types';
import { Pool, TAU, clamp, rand, swapRemove } from '../core/util';

export interface Projectile {
  uid: number;
  def: ProjId;
  team: 'player' | 'enemy';
  x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
  dmg: number; life: number; t: number;
  size: number; homing: number; pierce: number; bounce: number;
  hits: number[];
  rot: number; spin: number;
  color: string; color2: string;
  grav: number;
  aoe: number;
  owner: Actor | null;
  data: number[];
  dead: boolean;
  hitTick: number;
}

interface ProjSpec {
  grav: number; pierce: number; aoe: number; bounce: number; homing: number;
  color: string; color2: string; radius: number; spin: number; drag: number;
  life: number; sfx: string; hitSfx: string; kb: { x: number; z: number };
}

const SPECS: Record<ProjId, ProjSpec> = {
  fireball: { grav: 0, pierce: 0, aoe: 96, bounce: 0, homing: 0, color: '#ff7a1a', color2: '#ffe08a', radius: 20, spin: 6, drag: 0.2, life: 1.4, sfx: 'fire', hitSfx: 'explode', kb: { x: 260, z: 180 } },
  waterCrescent: { grav: 0, pierce: 1, aoe: 0, bounce: 0, homing: 0, color: '#4fd8ff', color2: '#eafcff', radius: 26, spin: 14, drag: 0.1, life: 1.3, sfx: 'water', hitSfx: 'hit', kb: { x: 220, z: 120 } },
  feather: { grav: 120, pierce: 2, aoe: 0, bounce: 0, homing: 0, color: '#eaf6ff', color2: '#9fe8ff', radius: 14, spin: 9, drag: 0.6, life: 1.5, sfx: 'wind', hitSfx: 'hit', kb: { x: 140, z: 90 } },
  rockShard: { grav: 1500, pierce: 0, aoe: 70, bounce: 1, homing: 0, color: '#8a7a62', color2: '#e0a558', radius: 22, spin: 8, drag: 0.05, life: 1.6, sfx: 'swingHeavy', hitSfx: 'hitHeavy', kb: { x: 320, z: 260 } },
  foxfire: { grav: -40, pierce: 0, aoe: 60, bounce: 0, homing: 3, color: '#7fd4ff', color2: '#a56bff', radius: 18, spin: 4, drag: 0.5, life: 2.2, sfx: 'fire', hitSfx: 'explode', kb: { x: 180, z: 140 } },
  thunderSpear: { grav: 0, pierce: 4, aoe: 0, bounce: 0, homing: 0, color: '#dff6ff', color2: '#9fe8ff', radius: 18, spin: 0, drag: 0, life: 1.2, sfx: 'thunder', hitSfx: 'hitCrit', kb: { x: 260, z: 100 } },
  ironWave: { grav: 0, pierce: 6, aoe: 0, bounce: 0, homing: 0, color: '#c9d3e0', color2: '#ffc93c', radius: 40, spin: 0, drag: 0.4, life: 1, sfx: 'swingHeavy', hitSfx: 'hitHeavy', kb: { x: 420, z: 260 } },
  enemyArrow: { grav: 420, pierce: 0, aoe: 0, bounce: 0, homing: 0, color: '#c8b48a', color2: '#c0392b', radius: 12, spin: 0, drag: 0.02, life: 2.4, sfx: 'swing', hitSfx: 'hit', kb: { x: 120, z: 60 } },
  enemyRune: { grav: 0, pierce: 0, aoe: 40, bounce: 0, homing: 1.2, color: '#ffd76a', color2: '#fff3c0', radius: 18, spin: 3, drag: 0.2, life: 2.6, sfx: 'charge', hitSfx: 'explode', kb: { x: 160, z: 120 } },
  enemyBomb: { grav: 900, pierce: 0, aoe: 140, bounce: 2, homing: 0, color: '#ff6a1a', color2: '#3a2a20', radius: 20, spin: 5, drag: 0.1, life: 2.2, sfx: 'charge', hitSfx: 'explode', kb: { x: 380, z: 320 } },
  bossBeam: { grav: 0, pierce: 99, aoe: 0, bounce: 0, homing: 0, color: '#ff3b52', color2: '#ffc93c', radius: 34, spin: 0, drag: 0, life: 1.8, sfx: 'charge', hitSfx: 'hitHeavy', kb: { x: 300, z: 160 } },
  starFlame: { grav: 700, pierce: 1, aoe: 110, bounce: 0, homing: 0.8, color: '#ffc93c', color2: '#ff3b52', radius: 24, spin: 10, drag: 0.1, life: 2.6, sfx: 'fire', hitSfx: 'explode', kb: { x: 280, z: 300 } },
};

let uidSeq = 1;
const resetProj = (p: Projectile) => {
  p.uid = 0; p.def = 'fireball'; p.team = 'player';
  p.x = p.y = p.z = p.vx = p.vy = p.vz = 0;
  p.dmg = 0; p.life = 0; p.t = 0; p.size = 1; p.homing = 0; p.pierce = 0; p.bounce = 0;
  p.hits.length = 0; p.rot = 0; p.spin = 0; p.color = '#fff'; p.color2 = '#fff';
  p.grav = 0; p.aoe = 0; p.owner = null; p.data.length = 0; p.dead = false; p.hitTick = 0;
};

export interface SpawnProjOpts {
  def: ProjId; team: 'player' | 'enemy'; x: number; y: number; z: number;
  dir: number; angle?: number; speed: number; dmg: number; size?: number;
  life?: number; homing?: number; owner?: Actor | null; vy?: number; vz?: number;
}

export class ProjectileSystem {
  pool = new Pool<Projectile>(() => ({
    uid: 0, def: 'fireball', team: 'player', x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0,
    dmg: 0, life: 0, t: 0, size: 1, homing: 0, pierce: 0, bounce: 0, hits: [],
    rot: 0, spin: 0, color: '#fff', color2: '#fff', grav: 0, aoe: 0, owner: null,
    data: [], dead: false, hitTick: 0,
  }), resetProj, 64, 420);

  budget = 1;
  setBudget(b: number) { this.budget = clamp(b, 0.3, 1); }

  spawn(o: SpawnProjOpts): Projectile | null {
    const spec = SPECS[o.def];
    const p = this.pool.obtain();
    if (!p) return null;
    const ang = o.angle ?? 0;
    p.uid = uidSeq++;
    p.def = o.def;
    p.team = o.team;
    p.x = o.x; p.y = o.y; p.z = o.z;
    p.vx = Math.cos(ang) * o.speed * o.dir;
    p.vy = (o.vy ?? Math.sin(ang) * o.speed * 0.34);
    p.vz = o.vz ?? 0;
    p.dmg = o.dmg;
    p.life = o.life ?? spec.life;
    p.t = 0;
    p.size = o.size ?? 1;
    p.homing = o.homing ?? spec.homing;
    p.pierce = spec.pierce;
    p.bounce = spec.bounce;
    p.hits.length = 0;
    p.rot = Math.random() * TAU;
    p.spin = spec.spin;
    p.color = spec.color;
    p.color2 = spec.color2;
    p.grav = spec.grav;
    p.aoe = spec.aoe;
    p.owner = o.owner ?? null;
    p.data.length = 0;
    p.data.push(rand(0, TAU), rand(0.8, 1.3));
    p.dead = false;
    p.hitTick = 0;
    return p;
  }

  /** 分裂（分裂咒） */
  split(p: Projectile, w: IWorld) {
    if (!w.traits.has('projSplit') || p.team !== 'player') return;
    for (let i = 0; i < 3; i++) {
      const a = (i - 1) * 0.5 + rand(-0.15, 0.15);
      const sp = this.spawn({
        def: p.def, team: p.team, x: p.x, y: p.y, z: p.z,
        dir: Math.sign(p.vx) || 1, angle: a, speed: Math.hypot(p.vx, p.vy) * 0.72,
        dmg: p.dmg * 0.45, size: p.size * 0.7, life: p.life * 0.6, owner: p.owner,
      });
      if (sp) sp.vz = p.vz * 0.5 + rand(-40, 80);
    }
  }

  update(dt: number, w: IWorld) {
    const arr = this.pool.active;
    for (let i = arr.length - 1; i >= 0; i--) {
      const p = arr[i];
      const spec = SPECS[p.def];
      p.t += dt;
      p.life -= dt;
      p.hitTick = Math.max(0, p.hitTick - dt);
      if (p.life <= 0) { this.expire(p, w); swapRemove(arr, i); this.pool.release(p); continue; }

      // 追蹤：轉向最近的敵對目標
      if (p.homing > 0) {
        let best: Actor | null = null, bd = 700;
        const list = p.team === 'player' ? w.actors : [w.player];
        for (const a of list) {
          if (a.dead) continue;
          if (p.team === 'enemy' && a.team !== 'player') continue;
          const d = Math.hypot(a.x - p.x, (a.y - p.y) * 2);
          if (d < bd) { bd = d; best = a; }
        }
        if (best) {
          const tx = best.x - p.x, ty = (best.y - p.y) * 1.6, tz = best.z + best.height * 0.5 - p.z;
          const len = Math.hypot(tx, ty, tz) || 1;
          const speed = Math.hypot(p.vx, p.vy, p.vz);
          const k = clamp(p.homing * dt * 3.4, 0, 0.5);
          p.vx += ((tx / len) * speed - p.vx) * k;
          p.vy += ((ty / len) * speed - p.vy) * k;
          p.vz += ((tz / len) * speed - p.vz) * k * 0.7;
        }
      }

      // 物理
      p.vz -= p.grav * dt;
      const d = Math.exp(-spec.drag * dt);
      p.vx *= d; p.vy *= d;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.rot += p.spin * dt;

      // 拖尾粒子（每種投射物不同）
      if (w.quality > 0.35) this.trail(p, w, dt);

      // 地面碰撞
      if (p.z <= 6) {
        p.z = 6;
        if (p.bounce > 0) {
          p.bounce--;
          p.vz = Math.abs(p.vz) * 0.55;
          p.vx *= 0.8;
          w.ps.emit({ kind: 'dust', x: p.x, y: p.y, z: 4, count: 3, speed: [30, 120], life: [0.2, 0.5], size: [6, 14], color: p.color2, grav: 40 });
        } else if (p.def === 'rockShard' || p.def === 'starFlame' || p.def === 'enemyBomb') {
          this.hitGround(p, w);
          swapRemove(arr, i); this.pool.release(p);
          continue;
        } else {
          p.vz = 0;
        }
      }
      // 邊界
      if (p.x < -300 || p.x > w.arenaW + 300 || Math.abs(p.y) > 400) {
        swapRemove(arr, i); this.pool.release(p); continue;
      }

      // 命中判定
      if (p.hitTick <= 0) {
        const list = p.team === 'player' ? w.actors : [w.player];
        for (const a of list) {
          if (a.dead || p.hits.includes(a.uid)) continue;
          if (p.team === 'enemy' && a.team !== 'player') continue;
          if (p.team === 'player' && a.team === 'player') continue;
          const dx = a.x - p.x, dy = (a.y - p.y) * 1.7;
          const r = spec.radius * p.size + a.radius;
          if (dx * dx + dy * dy < r * r && p.z < a.z + a.height && p.z + r * 0.6 > a.z) {
            this.onHit(p, a, w);
            p.hits.push(a.uid);
            p.hitTick = 0.06;
            if (p.pierce > 0) { p.pierce--; }
            else {
              swapRemove(arr, i); this.pool.release(p);
              break;
            }
          }
        }
      }
    }
  }

  private onHit(p: Projectile, a: Actor, w: IWorld) {
    const spec = SPECS[p.def];
    const dir = Math.sign(p.vx) || 1;
    damage(a, p.dmg, w, {
      kb: { x: spec.kb.x * dir, y: 0, z: spec.kb.z },
      attacker: p.owner ?? undefined,
      hitstop: p.team === 'player' ? 0.05 : 0.07,
      shake: p.team === 'player' ? 7 : 12,
      color: p.color2,
    });
    w.fx.impact(p.x, p.y, p.z, { elem: this.elemOf(p.def), scale: p.size * 1.2, color: p.color, color2: p.color2 });
    if (p.aoe > 0) {
      w.fx.ring(p.x, p.y, 14, { color: p.color, w: p.aoe * 2.4 * p.size, h: p.aoe * 0.8 * p.size, dur: 0.44 });
      areaDamage(w, p.x, p.y, p.aoe * p.size, p.dmg * 0.6, a);
    }
    w.sfx(spec.hitSfx as never, 0.7, rand(0.9, 1.15));
    this.split(p, w);
    if (p.def === 'thunderSpear') applyShock(a, w);
    if (p.def === 'foxfire' && w.traits.has('onHitBurn')) {
      // 妖火自带灼烧感
      w.ps.emit({ kind: 'ember', x: a.x, y: a.y, z: a.height * 0.5, count: 6, speed: [40, 200], vz: [40, 200], life: [0.3, 0.7], size: [3, 8], color: '#7fd4ff', additive: true });
    }
  }

  private hitGround(p: Projectile, w: IWorld) {
    const spec = SPECS[p.def];
    w.fx.impact(p.x, p.y, 10, { elem: this.elemOf(p.def), scale: p.size * 1.6, color: p.color, color2: p.color2 });
    w.fx.ring(p.x, p.y, 8, { color: p.color, w: spec.aoe * 2.6 * p.size + 80, h: spec.aoe * 0.8 * p.size + 30, dur: 0.5 });
    if (p.aoe > 0) areaDamage(w, p.x, p.y, p.aoe * p.size + 40, p.dmg * 0.85);
    if (p.def === 'rockShard') {
      w.fx.crack(p.x, p.y, { color: p.color2, scale: p.size });
      w.ps.emit({ kind: 'debris', x: p.x, y: p.y, z: 8, count: Math.round(14 * w.quality), speed: [120, 420], vz: [140, 460], life: [0.4, 1], size: [3, 10], color: p.color, grav: 1600 });
    }
    if (p.def === 'starFlame') {
      w.fx.pillar(p.x, p.y, { color: p.color, color2: p.color2, w: 90 * p.size, h: 620, dur: 0.7 });
      w.ps.emit({ kind: 'ember', x: p.x, y: p.y, z: 10, count: Math.round(26 * w.quality), speed: [120, 520], vz: [120, 620], life: [0.4, 1.1], size: [3, 10], color: p.color, color2: p.color2, additive: true, grav: 200 });
    }
    if (p.def === 'enemyBomb') {
      w.screen.shake(18);
      w.screen.flash('#ff8a3a', 0.3, 0.24);
      w.ps.emit({ kind: 'smoke', x: p.x, y: p.y, z: 20, count: Math.round(12 * w.quality), speed: [60, 220], vz: [60, 240], life: [0.5, 1.2], size: [18, 40], color: '#3a2a20', grav: -50 });
    }
    w.sfx(spec.hitSfx as never, 0.8, rand(0.8, 1.1));
    this.split(p, w);
  }

  private expire(p: Projectile, w: IWorld) {
    if (p.def === 'thunderSpear' || p.def === 'bossBeam') return;
    w.ps.emit({
      kind: p.def === 'feather' ? 'feather' : p.def === 'waterCrescent' ? 'drop' : 'ember',
      x: p.x, y: p.y, z: p.z, count: Math.round(6 * w.quality), speed: [20, 120],
      life: [0.2, 0.5], size: [2, 7], color: p.color, additive: true, grav: 200,
    });
  }

  private elemOf(def: ProjId) {
    switch (def) {
      case 'fireball': case 'bossBeam': return 'flame';
      case 'waterCrescent': return 'water';
      case 'feather': return 'wind';
      case 'rockShard': return 'rock';
      case 'foxfire': case 'starFlame': return 'fox';
      case 'thunderSpear': case 'ironWave': return 'iron';
      default: return 'fox';
    }
  }

  private trail(p: Projectile, w: IWorld, dt: number) {
    const n = Math.max(1, Math.round(dt * 60 * 0.35 * w.quality));
    switch (p.def) {
      case 'fireball':
        w.ps.emit({ kind: 'ember', x: p.x, y: p.y, z: p.z, count: n, speed: [10, 60], life: [0.15, 0.4], size: [4, 12], color: '#ff7a1a', color2: '#ffe08a', additive: true, grav: -60, drag: 2 });
        break;
      case 'waterCrescent':
        w.ps.emit({ kind: 'drop', x: p.x, y: p.y, z: p.z, count: n, speed: [10, 70], life: [0.2, 0.45], size: [2, 6], color: '#7fe9ff', additive: true, grav: 300 });
        break;
      case 'feather':
        w.ps.emit({ kind: 'feather', x: p.x, y: p.y, z: p.z, count: n, speed: [5, 40], life: [0.3, 0.7], size: [3, 8], color: '#eaf6ff', grav: 80 });
        break;
      case 'rockShard':
        w.ps.emit({ kind: 'dust', x: p.x, y: p.y, z: p.z, count: n, speed: [5, 40], life: [0.2, 0.5], size: [5, 14], color: '#8a7a62', grav: 100 });
        break;
      case 'foxfire':
        w.ps.emit({ kind: 'star', x: p.x, y: p.y, z: p.z, count: n, speed: [5, 50], life: [0.2, 0.55], size: [2, 7], color: '#7fd4ff', color2: '#a56bff', additive: true, grav: -30 });
        break;
      case 'thunderSpear':
        w.ps.emit({ kind: 'spark', x: p.x + rand(-16, 16), y: p.y, z: p.z + rand(-16, 16), count: n, speed: [40, 220], life: [0.1, 0.25], size: [2, 4], color: '#dff6ff', additive: true });
        break;
      case 'ironWave':
        w.ps.emit({ kind: 'debris', x: p.x, y: p.y, z: 6, count: n, speed: [40, 200], vz: [100, 380], life: [0.3, 0.7], size: [3, 8], color: '#c8b89a', grav: 1400 });
        break;
      case 'enemyArrow':
        w.ps.emit({ kind: 'spark', x: p.x, y: p.y, z: p.z, count: n, speed: [5, 30], life: [0.1, 0.25], size: [1, 3], color: '#c8b48a', additive: false });
        break;
      case 'enemyRune':
        w.ps.emit({ kind: 'rune', x: p.x, y: p.y, z: p.z, count: n, speed: [5, 40], life: [0.25, 0.6], size: [4, 9], color: '#ffd76a', additive: true, grav: -20 });
        break;
      case 'enemyBomb':
        w.ps.emit({ kind: 'ember', x: p.x, y: p.y, z: p.z, count: n, speed: [10, 60], life: [0.2, 0.5], size: [3, 8], color: '#ff6a1a', additive: true, grav: -30 });
        break;
      case 'bossBeam':
        w.ps.emit({ kind: 'ember', x: p.x + rand(-20, 20), y: p.y, z: p.z + rand(-30, 30), count: n * 2, speed: [20, 140], life: [0.2, 0.6], size: [4, 12], color: '#ff3b52', color2: '#ffc93c', additive: true, grav: -40 });
        break;
      case 'starFlame':
        w.ps.emit({ kind: 'ember', x: p.x, y: p.y, z: p.z, count: n, speed: [10, 80], life: [0.25, 0.7], size: [3, 10], color: '#ffc93c', color2: '#ff3b52', additive: true, grav: -20 });
        break;
    }
  }

  clear() { this.pool.releaseAll(); }
  get size() { return this.pool.size; }
}

function applyShock(a: Actor, w: IWorld) {
  a.status.push({ kind: 'stun', t: 0.5, dur: 0.5, power: 0, stacks: 0, tick: 0 });
  w.fx.bolt(a.x, a.y, a.height * 0.5, { color: '#dff6ff', h: 260, dur: 0.24 });
}
