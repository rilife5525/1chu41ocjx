/**
 * 角色繪製（玩家／分身）
 * ------------------------------------------------------------------
 * 以「骨骼＋形狀」程序化繪製：依狀態與招式進度計算姿勢，
 * 分层繪製（後肢 → 軀幹 → 前肢 → 頭 → 武器 → 配件），
 * 加上漫畫風描邊、漸層 shaded、輪廓光與動態拖尾。
 * 六位角色各有獨立 silhouette：焰猿棍、巨鉞、月牙鏟、鶴羽扇、鬼角、九尾符扇。
 */
import type { Actor } from './actors';
import type { HeroDef } from '../core/types';
import { TAU, clamp, lerp } from '../core/util';
import { drawCell, imgReady } from './art';
import { withAlpha } from './render-bg';

export interface Pose {
  lean: number; crouch: number; hipY: number;
  armF: number; armB: number; elbowF: number; elbowB: number;
  legF: number; legB: number; kneeF: number; kneeB: number;
  headTilt: number; weaponAng: number; weaponScale: number; flip: number;
}

export function drawShadow(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, z: number, alpha = 0.4) {
  const k = clamp(1 - z / 520, 0.25, 1);
  ctx.save();
  ctx.globalAlpha = alpha * k;
  ctx.fillStyle = 'rgba(10,4,12,0.85)';
  ctx.beginPath();
  ctx.ellipse(x, y, w * k, w * 0.32 * k, 0, 0, TAU);
  ctx.fill();
  ctx.restore();
}

/** 一段肢體（帶描邊與高光） */
export function limb(
  ctx: CanvasRenderingContext2D,
  x1: number, y1: number, x2: number, y2: number,
  w: number, color: string, ink = '#150a12',
) {
  ctx.lineCap = 'round';
  ctx.strokeStyle = ink;
  ctx.lineWidth = w + 4.5;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.strokeStyle = color;
  ctx.lineWidth = w;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
}

/** 兩段式肢體（上臂＋前臂） */
export function jointLimb(
  ctx: CanvasRenderingContext2D, x: number, y: number,
  a1: number, l1: number, a2: number, l2: number,
  w: number, color: string, ink = '#150a12',
) {
  const mx = x + Math.cos(a1) * l1, my = y + Math.sin(a1) * l1;
  const ex = mx + Math.cos(a1 + a2) * l2, ey = my + Math.sin(a1 + a2) * l2;
  limb(ctx, x, y, mx, my, w, color, ink);
  limb(ctx, mx, my, ex, ey, w * 0.86, color, ink);
  return { mx, my, ex, ey };
}

/* ============================ 姿勢計算 ============================ */
export function heroPose(a: Actor, t: number, _hero: HeroDef): Pose {
  void t;
  const base: Pose = {
    lean: 0, crouch: 0, hipY: 0,
    armF: 1.9, armB: 2.4, elbowF: 0.5, elbowB: 0.5,
    legF: 1.5, legB: 1.7, kneeF: 0.1, kneeB: 0.1,
    headTilt: 0, weaponAng: 0.4, weaponScale: 1, flip: a.facing,
  };
  const st = a.state;
  const at = a.animT;
  if (st === 'idle') {
    const b = Math.sin(at * 2.6) * 0.06;
    base.hipY = Math.sin(at * 2.6) * 2.4;
    base.armF = 1.75 + b; base.armB = 2.1 - b;
    base.legF = 1.52; base.legB = 1.66;
    base.weaponAng = 0.5 + Math.sin(at * 1.6) * 0.08;
    base.lean = 0.03;
  } else if (st === 'run') {
    const c = at * 13;
    const s = Math.sin(c), s2 = Math.sin(c + Math.PI);
    base.legF = 1.55 + s * 0.72; base.legB = 1.55 + s2 * 0.72;
    base.kneeF = Math.max(0, -s) * 0.9; base.kneeB = Math.max(0, -s2) * 0.9;
    base.armF = 1.9 + s2 * 0.6; base.armB = 1.9 + s * 0.6;
    base.elbowF = 0.7; base.elbowB = 0.7;
    base.hipY = Math.abs(Math.sin(c)) * -5;
    base.lean = 0.2;
    base.weaponAng = 0.9 + s * 0.2;
  } else if (st === 'jump') {
    base.legF = 1.1; base.legB = 2.0; base.kneeF = 0.9; base.kneeB = 0.5;
    base.armF = 2.7; base.armB = 0.6; base.elbowF = 0.4;
    base.lean = -0.1;
    base.weaponAng = -0.6;
  } else if (st === 'fall') {
    base.legF = 1.7; base.legB = 1.4; base.kneeF = 0.3; base.kneeB = 0.6;
    base.armF = 2.4; base.armB = 0.9;
    base.lean = 0.08;
    base.weaponAng = 0.2;
  } else if (st === 'dash') {
    base.lean = 0.62; base.legF = 0.9; base.legB = 2.3; base.kneeF = 0.6;
    base.armF = 2.9; base.armB = 2.9;
    base.weaponAng = 1.5;
    base.crouch = 6;
  } else if (st === 'charge') {
    const k = clamp(a.chargeT / 0.5, 0, 1);
    base.crouch = 10 + k * 10;
    base.lean = -0.16 - k * 0.1;
    base.armF = 2.6 - k * 1.2; base.armB = 1.2 + k * 0.6;
    base.legF = 1.2; base.legB = 2.0; base.kneeF = 0.8 + k * 0.3; base.kneeB = 0.5;
    base.weaponAng = -1.3 - k * 0.7;
    base.weaponScale = 1 + k * 0.16;
  } else if (st === 'hurt') {
    const k = clamp(a.stateT / 0.35, 0, 1);
    base.lean = -0.4 * (1 - k);
    base.armF = 2.6 - k; base.armB = 0.7 + k;
    base.legF = 1.3; base.legB = 1.9;
    base.headTilt = -0.3 * (1 - k);
    base.weaponAng = 1.2;
  } else if (st === 'down') {
    base.lean = -1.35; base.crouch = 26;
    base.armF = 2.9; base.armB = 0.3; base.legF = 1.1; base.legB = 2.1;
    base.weaponAng = 1.8;
  } else if (st === 'attack' || st === 'skill') {
    const mv = a.move;
    const p = mv ? clamp(a.moveT / mv.duration, 0, 1) : 0;
    const isHeavy = mv?.kind === 'launcher' || mv?.tag === 'dive' || mv?.kind === 'skill';
    // 三段式：蓄 → 擊 → 收
    const strike = clamp((p - 0.18) / 0.26, 0, 1);
    const recover = clamp((p - 0.5) / 0.5, 0, 1);
    const wind = clamp(p / 0.2, 0, 1);
    if (mv?.tag === 'dive') {
      base.lean = 0.9; base.legF = 0.5; base.legB = 2.4; base.kneeF = 0.2;
      base.armF = 3.0; base.armB = 3.0;
      base.weaponAng = 1.6;
      base.crouch = 4;
    } else if (mv?.kind === 'launcher') {
      base.lean = -0.2 + strike * 0.4;
      base.armF = 2.6 - strike * 2.6 + recover * 1.4;
      base.armB = 1.2 + strike * 0.6;
      base.legF = 1.3 - strike * 0.3; base.legB = 1.9;
      base.kneeF = 0.4;
      base.weaponAng = -1.9 + strike * 3.2 - recover * 0.6;
      base.crouch = 8 - strike * 8;
    } else if (isHeavy) {
      base.lean = -0.22 * wind + strike * 0.5 - recover * 0.28;
      base.armF = 2.4 - wind * 1.2 + strike * 2.8 - recover * 1.2;
      base.armB = 1.6 - wind * 0.5 + strike * 1.1;
      base.legF = 1.4 + strike * 0.4; base.legB = 1.8 - strike * 0.3;
      base.kneeF = 0.2 + strike * 0.3;
      base.weaponAng = -1.2 - wind * 0.9 + strike * 3.6 - recover * 1.6;
      base.weaponScale = 1 + strike * 0.1;
      base.crouch = wind * 8 - strike * 4;
    } else {
      const step = a.comboStep % 3;
      const dirMul = step === 1 ? -1 : 1;
      base.lean = -0.1 * wind + strike * 0.3 * dirMul;
      base.armF = 2.1 - wind * 0.7 * dirMul + strike * 2.0 * dirMul;
      base.armB = 2.0 + strike * 0.5 * dirMul;
      base.elbowF = 0.6 - strike * 0.4;
      base.legF = 1.5 + strike * 0.3 * dirMul; base.legB = 1.7 - strike * 0.2;
      base.weaponAng = (step === 2 ? 1.4 : 0.5) * dirMul - wind * 0.9 * dirMul + strike * 2.6 * dirMul;
      if (step === 1) base.legF = 1.2 + strike * 1.1; // 踢擊
    }
  } else if (st === 'ult') {
    base.lean = -0.1; base.armF = 2.9; base.armB = 0.4;
    base.legF = 1.3; base.legB = 1.9;
    base.weaponAng = -1.6 + Math.sin(t * 6) * 0.2;
  }
  return base;
}

/* ============================ 主繪製 ============================ */
export function drawHeroActor(ctx: CanvasRenderingContext2D, a: Actor, sx: number, sy: number, t: number, quality: number, opts: { ghost?: boolean; alpha?: number } = {}) {
  const hero = a.hero;
  if (!hero) return;
  const P = hero.palette;
  const pose = heroPose(a, t, hero);
  const S = a.scale * (1 + a.y * 0.0016);
  const bulk = hero.id === 'panya' || hero.id === 'xuanjiao' ? 1.28 : hero.id === 'feiyue' || hero.id === 'shuangling' ? 0.92 : 1;
  const H = 96 * S;

  ctx.save();
  ctx.translate(sx, sy);
  ctx.scale(pose.flip * S, S);
  if (opts.alpha !== undefined) ctx.globalAlpha = opts.alpha;
  ctx.rotate(pose.lean * 0.4);
  ctx.translate(0, pose.crouch);

  // 受擊閃白
  const flash = a.flashT > 0;
  const cBody = flash ? '#ffffff' : P.main;
  const cTrim = flash ? '#ffffff' : P.trim;
  const cSkin = flash ? '#ffffff' : P.skin;
  const cHair = flash ? '#ffffff' : P.hair;
  const cDark = flash ? '#dddddd' : P.dark;
  const ink = '#150a12';

  const hipY = -H * 0.46 + pose.hipY;
  const chestY = -H * 0.74 + pose.hipY;
  const headY = -H * 0.92 + pose.hipY;
  const shW = 20 * bulk;

  // 披風／羽翼（後層）
  drawBack(ctx, hero, a, pose, t, hipY, chestY, cDark, quality);

  // 後腿
  jointLimb(ctx, -5 * bulk, hipY, pose.legB, H * 0.26, pose.kneeB, H * 0.25, 11 * bulk, cDark, ink);
  // 後臂
  jointLimb(ctx, -shW * 0.5, chestY, pose.armB, H * 0.2, pose.elbowB, H * 0.19, 9 * bulk, cDark, ink);

  // 軀幹
  ctx.save();
  const g = ctx.createLinearGradient(-16, chestY, 20, hipY);
  g.addColorStop(0, cBody);
  g.addColorStop(0.55, cBody);
  g.addColorStop(1, cDark);
  ctx.fillStyle = ink;
  roundRect(ctx, -15 * bulk, chestY - 6, 30 * bulk, hipY - chestY + 14, 10 * bulk);
  ctx.fill();
  ctx.fillStyle = g;
  roundRect(ctx, -13 * bulk, chestY - 4, 26 * bulk, hipY - chestY + 10, 9 * bulk);
  ctx.fill();
  // 腰帶
  ctx.fillStyle = cTrim;
  ctx.fillRect(-14 * bulk, hipY - 4, 28 * bulk, 8);
  // 胸前紋樣
  ctx.globalAlpha = 0.6;
  ctx.fillStyle = cTrim;
  ctx.beginPath();
  ctx.moveTo(-8 * bulk, chestY + 4); ctx.lineTo(8 * bulk, chestY + 4); ctx.lineTo(0, chestY + 22);
  ctx.closePath(); ctx.fill();
  ctx.globalAlpha = 1;
  ctx.restore();

  // 前腿
  jointLimb(ctx, 5 * bulk, hipY, pose.legF, H * 0.27, pose.kneeF, H * 0.26, 12 * bulk, cBody, ink);
  // 靴
  ctx.fillStyle = ink;
  roundRect(ctx, -2, -4, 20, 10, 4); ctx.fill();

  // 頭
  drawHead(ctx, hero, headY, chestY, pose, t, cSkin, cHair, cTrim, ink, bulk, a);

  // 前臂 + 武器
  const hand = jointLimb(ctx, shW * 0.55, chestY, pose.armF, H * 0.21, pose.elbowF, H * 0.2, 10 * bulk, cBody, ink);
  drawWeapon(ctx, hero, hand.ex, hand.ey, pose, t, P, quality, a);

  // 角色專屬前景配件
  drawFront(ctx, hero, a, pose, t, hipY, chestY, headY, quality);

  // 輪廓光（受光側）
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 0.28;
  ctx.strokeStyle = P.aura;
  ctx.lineWidth = 3;
  roundRect(ctx, -13 * bulk, chestY - 4, 26 * bulk, hipY - chestY + 10, 9 * bulk);
  ctx.stroke();
  ctx.restore();

  ctx.restore();

  // 狀態視覺
  if (a.buffT > 0 || a.buffMul > 1) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.3 + 0.15 * Math.sin(t * 8);
    const g = ctx.createRadialGradient(sx, sy - H * 0.5, 4, sx, sy - H * 0.5, H * 0.9);
    g.addColorStop(0, withAlpha(P.aura, 0.5));
    g.addColorStop(1, withAlpha(P.aura, 0));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(sx, sy - H * 0.5, H * 0.9, 0, TAU); ctx.fill();
    ctx.restore();
  }
  if (a.charging) {
    const k = clamp(a.chargeT / 0.5, 0, 1);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = withAlpha(P.trim, 0.5 + 0.4 * Math.sin(t * 22));
    ctx.lineWidth = 2 + k * 4;
    ctx.beginPath(); ctx.arc(sx, sy - H * 0.5, 40 + k * 46, 0, TAU); ctx.stroke();
    ctx.restore();
  }
}

/* ============================ 頭部 ============================ */
function drawHead(
  ctx: CanvasRenderingContext2D, hero: HeroDef, headY: number, chestY: number, pose: Pose,
  t: number, cSkin: string, cHair: string, cTrim: string, ink: string, bulk: number, a: Actor,
) {
  const r = 15 * (bulk > 1.2 ? 1.06 : 1);
  ctx.save();
  ctx.translate(2, headY);
  ctx.rotate(pose.headTilt);
  // 頸
  limb(ctx, 0, r * 0.7, 0, chestY - headY + 6, 8 * bulk, cSkin, ink);
  // 頭髮（後）
  ctx.fillStyle = ink;
  ctx.beginPath(); ctx.arc(0, 0, r + 3.5, 0, TAU); ctx.fill();
  ctx.fillStyle = cHair;
  ctx.beginPath(); ctx.arc(0, -1, r + 1, 0, TAU); ctx.fill();
  // 臉
  ctx.fillStyle = cSkin;
  ctx.beginPath(); ctx.ellipse(3, 3, r * 0.82, r * 0.9, 0, 0, TAU); ctx.fill();
  // 瀏海
  ctx.fillStyle = cHair;
  ctx.beginPath();
  ctx.moveTo(-r, -2);
  ctx.quadraticCurveTo(-r * 0.2, -r * 1.25, r * 0.95, -r * 0.45);
  ctx.quadraticCurveTo(r * 0.4, -r * 0.15, r * 0.1, -2);
  ctx.quadraticCurveTo(-r * 0.4, -r * 0.5, -r, -2);
  ctx.closePath(); ctx.fill();
  // 眼睛（P5 風格銳利眼）
  ctx.fillStyle = '#1a0a10';
  ctx.beginPath();
  ctx.moveTo(4, 1); ctx.lineTo(12, -1); ctx.lineTo(12, 3.4); ctx.lineTo(4, 4.4);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = withAlpha(hero.palette.aura, 0.95);
  ctx.beginPath(); ctx.arc(9.5, 1.6, 1.7, 0, TAU); ctx.fill();
  // 角色特徵
  if (hero.id === 'lin') {
    // 頭巾與飄帶
    ctx.fillStyle = cTrim;
    ctx.fillRect(-r - 1, -7, r * 2 + 2, 6);
    ctx.save();
    const sw = Math.sin(t * 6 + a.animT) * 8;
    ctx.strokeStyle = cTrim; ctx.lineWidth = 4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(-r, -4);
    ctx.quadraticCurveTo(-r - 16, -2 + sw, -r - 30, 8 + sw * 1.4);
    ctx.stroke();
    ctx.restore();
  } else if (hero.id === 'panya') {
    // 獠牙
    ctx.fillStyle = '#fff8e0';
    ctx.beginPath(); ctx.moveTo(2, 8); ctx.lineTo(6, 16); ctx.lineTo(9, 8); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-6, 7); ctx.lineTo(-3, 14); ctx.lineTo(0, 7); ctx.closePath(); ctx.fill();
    // 耳
    ctx.fillStyle = cSkin;
    ctx.beginPath(); ctx.ellipse(-r + 1, -2, 6, 8, -0.4, 0, TAU); ctx.fill();
  } else if (hero.id === 'lian') {
    // 馬尾
    ctx.save();
    const sw = Math.sin(t * 3 + a.animT) * 6;
    ctx.strokeStyle = cHair; ctx.lineWidth = 9; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(-r + 2, -2);
    ctx.quadraticCurveTo(-r - 20, 6 + sw, -r - 26, 30 + sw * 1.6);
    ctx.stroke();
    ctx.strokeStyle = cTrim; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(-r - 4, 2); ctx.lineTo(-r - 12, 8); ctx.stroke();
    ctx.restore();
  } else if (hero.id === 'shuangling') {
    // 鶴羽頭飾
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(-2, -r - 2); ctx.quadraticCurveTo(10, -r - 26, 22, -r - 16);
    ctx.quadraticCurveTo(10, -r - 10, -2, -r - 2);
    ctx.fill();
    ctx.fillStyle = cTrim;
    ctx.beginPath(); ctx.arc(-1, -r + 1, 3.4, 0, TAU); ctx.fill();
  } else if (hero.id === 'xuanjiao') {
    // 雙角
    ctx.fillStyle = '#f0d6a8';
    ctx.beginPath(); ctx.moveTo(-8, -r + 2); ctx.quadraticCurveTo(-22, -r - 18, -6, -r - 24); ctx.quadraticCurveTo(-8, -r - 8, -2, -r + 2); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(8, -r + 2); ctx.quadraticCurveTo(24, -r - 16, 10, -r - 24); ctx.quadraticCurveTo(10, -r - 8, 4, -r + 2); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = ink; ctx.lineWidth = 2; ctx.stroke();
    // 鼻環
    ctx.strokeStyle = cTrim; ctx.lineWidth = 2.4;
    ctx.beginPath(); ctx.arc(6, 9, 4, 0.2, Math.PI - 0.2); ctx.stroke();
  } else if (hero.id === 'feiyue') {
    // 狐耳
    ctx.fillStyle = cHair;
    ctx.beginPath(); ctx.moveTo(-r + 1, -6); ctx.lineTo(-r - 6, -r - 14); ctx.lineTo(-2, -r - 2); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(r - 3, -6); ctx.lineTo(r + 6, -r - 14); ctx.lineTo(2, -r - 2); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.beginPath(); ctx.moveTo(-r + 2, -7); ctx.lineTo(-r - 2, -r - 9); ctx.lineTo(-3, -r - 3); ctx.closePath(); ctx.fill();
    // 額間朱印
    ctx.fillStyle = '#ff2d40';
    ctx.beginPath(); ctx.arc(2, -5, 2.4, 0, TAU); ctx.fill();
  }
  ctx.restore();
}

/* ============================ 武器 ============================ */
function drawWeapon(
  ctx: CanvasRenderingContext2D, hero: HeroDef, hx: number, hy: number,
  pose: Pose, t: number, P: HeroDef['palette'], quality: number, a: Actor,
) {
  ctx.save();
  ctx.translate(hx, hy);
  ctx.rotate(pose.weaponAng);
  ctx.scale(pose.weaponScale, pose.weaponScale);
  const ink = '#150a12';
  switch (hero.id) {
    case 'lin': { // 靈猿棍（兩端金箍，燃燒）
      ctx.strokeStyle = ink; ctx.lineWidth = 11; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(-46, 0); ctx.lineTo(46, 0); ctx.stroke();
      const g = ctx.createLinearGradient(-46, 0, 46, 0);
      g.addColorStop(0, '#8a5a2a'); g.addColorStop(0.5, '#c8903a'); g.addColorStop(1, '#8a5a2a');
      ctx.strokeStyle = g; ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(-46, 0); ctx.lineTo(46, 0); ctx.stroke();
      ctx.strokeStyle = P.trim; ctx.lineWidth = 8;
      ctx.beginPath(); ctx.moveTo(-46, 0); ctx.lineTo(-36, 0); ctx.moveTo(36, 0); ctx.lineTo(46, 0); ctx.stroke();
      if (quality > 0.4) {
        ctx.globalCompositeOperation = 'lighter';
        for (let i = 0; i < 5; i++) {
          const fx = -40 + i * 20;
          const fl = 6 + Math.sin(t * 14 + i * 2) * 4;
          ctx.fillStyle = withAlpha(i % 2 ? '#ffb03a' : '#ff5a1a', 0.65);
          ctx.beginPath();
          ctx.moveTo(fx - 5, 0); ctx.quadraticCurveTo(fx, -fl * 2.4, fx + 5, 0);
          ctx.closePath(); ctx.fill();
        }
      }
      break;
    }
    case 'panya': { // 碎山鉞
      ctx.strokeStyle = ink; ctx.lineWidth = 12;
      ctx.beginPath(); ctx.moveTo(-10, 26); ctx.lineTo(24, -46); ctx.stroke();
      ctx.strokeStyle = '#6a4a2a'; ctx.lineWidth = 8;
      ctx.beginPath(); ctx.moveTo(-10, 26); ctx.lineTo(24, -46); ctx.stroke();
      const g = ctx.createLinearGradient(0, -70, 40, -20);
      g.addColorStop(0, '#e8eef6'); g.addColorStop(0.5, P.metal); g.addColorStop(1, '#7a8496');
      ctx.fillStyle = ink;
      ctx.beginPath();
      ctx.moveTo(20, -44); ctx.quadraticCurveTo(58, -60, 62, -18);
      ctx.quadraticCurveTo(48, -26, 30, -22); ctx.closePath(); ctx.fill();
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(22, -44); ctx.quadraticCurveTo(55, -58, 58, -20);
      ctx.quadraticCurveTo(46, -27, 30, -24); ctx.closePath(); ctx.fill();
      ctx.fillStyle = P.trim;
      ctx.beginPath(); ctx.arc(24, -40, 5, 0, TAU); ctx.fill();
      break;
    }
    case 'lian': { // 月牙鏟
      ctx.strokeStyle = ink; ctx.lineWidth = 9;
      ctx.beginPath(); ctx.moveTo(-40, 10); ctx.lineTo(40, -30); ctx.stroke();
      ctx.strokeStyle = '#4a6a7a'; ctx.lineWidth = 6;
      ctx.beginPath(); ctx.moveTo(-40, 10); ctx.lineTo(40, -30); ctx.stroke();
      const g = ctx.createLinearGradient(30, -60, 60, -10);
      g.addColorStop(0, '#eafcff'); g.addColorStop(1, '#4fd8ff');
      ctx.fillStyle = ink;
      ctx.beginPath(); ctx.arc(46, -34, 22, Math.PI * 0.15, Math.PI * 1.35); ctx.arc(46, -34, 13, Math.PI * 1.35, Math.PI * 0.15, true); ctx.closePath(); ctx.fill();
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(46, -34, 20, Math.PI * 0.15, Math.PI * 1.35); ctx.arc(46, -34, 12, Math.PI * 1.35, Math.PI * 0.15, true); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = P.trim; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-40, 10); ctx.lineTo(-30, 4); ctx.stroke();
      break;
    }
    case 'shuangling': { // 鶴羽扇
      for (let i = 0; i < 7; i++) {
        const a2 = -1.1 + i * 0.32;
        ctx.fillStyle = ink;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(Math.cos(a2) * 34, Math.sin(a2) * 34 - 6, Math.cos(a2) * 52, Math.sin(a2) * 52);
        ctx.quadraticCurveTo(Math.cos(a2 + 0.16) * 30, Math.sin(a2 + 0.16) * 30, 0, 4);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = i % 2 ? '#ffffff' : '#e6f2ff';
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(Math.cos(a2) * 32, Math.sin(a2) * 32 - 5, Math.cos(a2) * 48, Math.sin(a2) * 48);
        ctx.quadraticCurveTo(Math.cos(a2 + 0.14) * 28, Math.sin(a2 + 0.14) * 28, 0, 3);
        ctx.closePath(); ctx.fill();
      }
      ctx.fillStyle = P.trim;
      ctx.beginPath(); ctx.arc(0, 0, 6, 0, TAU); ctx.fill();
      break;
    }
    case 'xuanjiao': { // 尖刺拳甲
      ctx.fillStyle = ink;
      roundRect(ctx, -14, -14, 30, 28, 8); ctx.fill();
      const g = ctx.createLinearGradient(-14, -14, 16, 14);
      g.addColorStop(0, '#8a1a2a'); g.addColorStop(1, '#3a0a14');
      ctx.fillStyle = g;
      roundRect(ctx, -12, -12, 26, 24, 7); ctx.fill();
      ctx.fillStyle = P.metal;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(2 + i * 5, -8 + i * 6);
        ctx.lineTo(20 + i * 6, -12 + i * 7);
        ctx.lineTo(2 + i * 5, -2 + i * 6);
        ctx.closePath(); ctx.fill();
      }
      break;
    }
    case 'feiyue': { // 九尾符扇＋妖火
      ctx.fillStyle = ink;
      ctx.beginPath(); ctx.moveTo(-6, 12); ctx.lineTo(26, -34); ctx.lineTo(34, -28); ctx.lineTo(2, 16); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#5b2a86';
      ctx.beginPath(); ctx.moveTo(-4, 12); ctx.lineTo(26, -32); ctx.lineTo(32, -28); ctx.lineTo(2, 14); ctx.closePath(); ctx.fill();
      for (let i = 0; i < 5; i++) {
        const a2 = -1.5 + i * 0.42;
        ctx.fillStyle = withAlpha(i % 2 ? '#ffd76a' : '#fff3c0', 0.92);
        ctx.save();
        ctx.rotate(a2);
        ctx.fillRect(20, -7, 15, 14);
        ctx.fillStyle = '#c0392b';
        ctx.fillRect(22, -4, 11, 2);
        ctx.fillRect(22, 1, 8, 2);
        ctx.restore();
      }
      if (quality > 0.4) {
        ctx.globalCompositeOperation = 'lighter';
        for (let i = 0; i < 3; i++) {
          const a3 = t * 2.2 + i * 2.1;
          const ox = Math.cos(a3) * 34, oy = Math.sin(a3) * 26 - 12;
          const g2 = ctx.createRadialGradient(ox, oy, 1, ox, oy, 14);
          g2.addColorStop(0, 'rgba(255,255,255,0.9)');
          g2.addColorStop(0.4, withAlpha('#7fd4ff', 0.6));
          g2.addColorStop(1, withAlpha('#a56bff', 0));
          ctx.fillStyle = g2;
          ctx.beginPath(); ctx.arc(ox, oy, 14, 0, TAU); ctx.fill();
        }
      }
      break;
    }
  }
  ctx.restore();
  void a;
}

/* ============================ 後層配件（披風／翼／尾） ============================ */
function drawBack(ctx: CanvasRenderingContext2D, hero: HeroDef, a: Actor, pose: Pose, t: number, hipY: number, chestY: number, cDark: string, quality: number) {
  const P = hero.palette;
  ctx.save();
  if (hero.id === 'xuanjiao' || hero.id === 'lin') {
    // 披風
    const sw = Math.sin(t * 3 + a.animT) * 10 + (a.state === 'run' ? -18 : 0);
    ctx.fillStyle = cDark;
    ctx.beginPath();
    ctx.moveTo(-12, chestY + 2);
    ctx.quadraticCurveTo(-46 + sw, hipY + 10, -34 + sw * 1.4, hipY + 56);
    ctx.lineTo(6, hipY + 30);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = withAlpha(P.main, 0.7);
    ctx.beginPath();
    ctx.moveTo(-10, chestY + 4);
    ctx.quadraticCurveTo(-38 + sw, hipY + 8, -28 + sw * 1.3, hipY + 48);
    ctx.lineTo(2, hipY + 26);
    ctx.closePath(); ctx.fill();
  }
  if (hero.id === 'shuangling' && quality > 0.3) {
    // 鶴翼
    const flap = Math.sin(t * (a.grounded ? 2 : 9)) * (a.grounded ? 0.12 : 0.5);
    ctx.fillStyle = '#ffffff';
    ctx.globalAlpha = 0.92;
    for (const s of [-1, 1]) {
      ctx.save();
      ctx.scale(s, 1);
      ctx.beginPath();
      ctx.moveTo(-6, chestY + 6);
      ctx.quadraticCurveTo(-52, chestY - 20 - flap * 40, -78, chestY + 26 - flap * 30);
      ctx.quadraticCurveTo(-46, chestY + 20, -8, chestY + 24);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = withAlpha(P.trim, 0.7); ctx.lineWidth = 2;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo(-14 - i * 8, chestY + 8 + i * 3);
        ctx.lineTo(-40 - i * 10, chestY + 4 + i * 6 - flap * 20);
        ctx.stroke();
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }
  if (hero.id === 'feiyue') {
    // 九尾
    const n = 9;
    for (let i = 0; i < n; i++) {
      const base = -Math.PI * 0.85 + (i / (n - 1)) * Math.PI * 0.7;
      const sway = Math.sin(t * 2.4 + i * 0.7) * 16;
      const len = 62 + (i % 3) * 16;
      ctx.strokeStyle = i % 2 ? '#b06bff' : '#8a3ad6';
      ctx.lineWidth = 9 - (i % 3) * 1.5;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(-6, hipY + 6);
      ctx.quadraticCurveTo(
        -6 + Math.cos(base) * len * 0.6 - 20, hipY + Math.sin(base) * len * 0.6 + sway * 0.5,
        -6 + Math.cos(base) * len - 26, hipY + Math.sin(base) * len + sway,
      );
      ctx.stroke();
      if (quality > 0.5) {
        ctx.fillStyle = withAlpha('#ffffff', 0.85);
        ctx.beginPath();
        ctx.arc(-6 + Math.cos(base) * len - 26, hipY + Math.sin(base) * len + sway, 4.4, 0, TAU);
        ctx.fill();
      }
    }
  }
  if (hero.id === 'lian') {
    // 飄逸腰帶
    const sw = Math.sin(t * 3.4 + a.animT) * 14;
    ctx.strokeStyle = P.trim; ctx.lineWidth = 7; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-10, hipY);
    ctx.quadraticCurveTo(-40, hipY + 20 + sw * 0.4, -58 + sw, hipY + 46);
    ctx.stroke();
    ctx.strokeStyle = withAlpha('#ffffff', 0.5); ctx.lineWidth = 2.4;
    ctx.stroke();
  }
  if (hero.id === 'lin') {
    // 猴尾
    const sw = Math.sin(t * 4 + a.animT) * 18;
    ctx.strokeStyle = P.skin; ctx.lineWidth = 7; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-8, hipY + 4);
    ctx.quadraticCurveTo(-40, hipY + 14 + sw * 0.3, -52, hipY - 16 + sw);
    ctx.stroke();
  }
  ctx.restore();
  void pose;
}

/* ============================ 前層配件 ============================ */
function drawFront(ctx: CanvasRenderingContext2D, hero: HeroDef, a: Actor, pose: Pose, t: number, hipY: number, chestY: number, headY: number, quality: number) {
  const P = hero.palette;
  ctx.save();
  // 肩甲
  if (hero.id === 'panya' || hero.id === 'xuanjiao') {
    ctx.fillStyle = '#150a12';
    ctx.beginPath(); ctx.ellipse(-16, chestY + 4, 17, 13, -0.3, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(16, chestY + 4, 17, 13, 0.3, 0, TAU); ctx.fill();
    ctx.fillStyle = hero.id === 'panya' ? '#8a7a62' : '#7a1020';
    ctx.beginPath(); ctx.ellipse(-16, chestY + 3, 14, 10, -0.3, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(16, chestY + 3, 14, 10, 0.3, 0, TAU); ctx.fill();
    ctx.fillStyle = P.trim;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath(); ctx.moveTo(10 + i * 6, chestY - 4); ctx.lineTo(14 + i * 6, chestY - 14); ctx.lineTo(18 + i * 6, chestY - 4); ctx.closePath(); ctx.fill();
    }
  }
  // 護腕
  ctx.fillStyle = P.trim;
  ctx.globalAlpha = 0.9;
  ctx.fillRect(-4, chestY + 34, 9, 8);
  ctx.globalAlpha = 1;
  if (hero.id === 'feiyue' && quality > 0.4) {
    // 巫女袖
    ctx.fillStyle = withAlpha('#ffffff', 0.9);
    ctx.beginPath();
    ctx.moveTo(6, chestY + 10); ctx.quadraticCurveTo(30, chestY + 40, 20, hipY + 30);
    ctx.lineTo(4, hipY + 12); ctx.closePath(); ctx.fill();
  }
  if (hero.id === 'shuangling' && quality > 0.4) {
    // 飄落羽毛
    ctx.fillStyle = withAlpha('#ffffff', 0.6);
    for (let i = 0; i < 3; i++) {
      const yy = ((t * 40 + i * 40) % 120);
      ctx.beginPath();
      ctx.ellipse(-20 + i * 18 + Math.sin(t * 2 + i) * 8, chestY + yy, 4, 2, Math.sin(t + i), 0, TAU);
      ctx.fill();
    }
  }
  ctx.restore();
  void a; void pose; void headY;
}

/** 蓄力／奧義時在角色身後顯示立繪（圖集）作為靈體分身 */
export function drawSpiritAvatar(ctx: CanvasRenderingContext2D, hero: HeroDef, sx: number, sy: number, t: number, alpha: number, scale = 1) {
  if (!imgReady('heroAtlas') || alpha <= 0.01) return;
  const size = 300 * scale;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.globalCompositeOperation = 'lighter';
  ctx.translate(sx, sy - size * 0.55);
  ctx.rotate(Math.sin(t * 1.4) * 0.03);
  const bob = Math.sin(t * 2.2) * 8;
  ctx.translate(0, bob);
  const g = ctx.createRadialGradient(0, 0, 10, 0, 0, size * 0.7);
  g.addColorStop(0, withAlpha(hero.palette.aura, 0.5 * alpha));
  g.addColorStop(1, withAlpha(hero.palette.aura, 0));
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(0, 0, size * 0.7, 0, TAU); ctx.fill();
  drawCell(ctx, 'heroAtlas', hero.atlas, -size / 2, -size / 2, size, size, { alpha: alpha * 0.85, scale: 1.02 });
  ctx.restore();
}

export function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

export const clampN = clamp;
export const lerpN = lerp;
