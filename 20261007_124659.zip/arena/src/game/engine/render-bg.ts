/**
 * 背景與場景渲染
 * ------------------------------------------------------------------
 * 分層結構（由遠至近）：
 *   天空漸層 → 天體/星/神光 → 遠景圖片(視差0.16) → 雲帶 → 中景圖片(視差0.42)
 *   → 遠景程序化物件(0.66) → 霧氣 → 地面透視 → [角色層] → 近景物件(1.0)
 *   → 前景遮蔽(1.28) → 天氣粒子 → 色調疊加
 * 同一生物群系會依 variant 改變取景、色調與物件組合，
 * 因此每個場景都有不同景象，而不是一張固定背景。
 */
import type { ArtKey } from './art';
import { drawBg, getImg, imgReady } from './art';
import type { BiomeId, SceneDef, WeatherId } from '../core/types';
import { DEPTH_MAX, DEPTH_MIN, DESIGN_H, DESIGN_W, GROUND_Y } from '../core/types';
import { Rng, TAU, clamp, lerp, rand } from '../core/util';

export interface Cam { x: number; y: number; zoom: number }

const BIOME_ART: Record<BiomeId, { far: ArtKey; near: ArtKey }> = {
  peak: { far: 'peakFar', near: 'peakNear' },
  flame: { far: 'flameFar', near: 'flameNear' },
  heaven: { far: 'heavenFar', near: 'heavenNear' },
  void: { far: 'heavenFar', near: 'flameNear' },
};

const BIOME_ZOOM: Record<BiomeId, number[]> = {
  peak: [1.05, 1.18, 1.3, 1.1],
  flame: [1.1, 1.25, 1.35, 1.2],
  heaven: [1.05, 1.2, 1.3, 1.15],
  void: [1.3, 1.4, 1.5, 1.35],
};

interface PropInst { id: string; x: number; y: number; s: number; seed: number; layer: number }

export class BackgroundRenderer {
  private props: PropInst[] = [];
  private layoutKey = '';
  private stars: { x: number; y: number; r: number; p: number }[] = [];
  private clouds: { x: number; y: number; s: number; sp: number; a: number }[] = [];
  private weatherP: { x: number; y: number; vx: number; vy: number; r: number; rot: number; vr: number; a: number; ph: number }[] = [];
  private weatherKey = '';
  private skyCache = new Map<string, CanvasGradient>();

  /** 依場景建立物件配置（seeded，確保同一場景每次一致） */
  private buildLayout(scene: SceneDef) {
    const key = `${scene.id}|${scene.variant}|${scene.arenaW}`;
    if (key === this.layoutKey) return;
    this.layoutKey = key;
    const rng = new Rng(hashStr(scene.id) + scene.variant * 7919);
    this.props = [];
    const ids = scene.props.length ? scene.props : ['rock', 'grass'];
    // 遠景層物件（大、稀疏、模糊）
    const farCount = 7;
    for (let i = 0; i < farCount; i++) {
      this.props.push({
        id: ids[(rng.int(0, ids.length - 1))],
        x: rng.range(-200, scene.arenaW + 200),
        y: rng.range(-30, 30),
        s: rng.range(1.5, 2.6),
        seed: rng.next() * 100,
        layer: 0,
      });
    }
    // 近景層物件（沿地面分佈）
    const nearCount = 16;
    for (let i = 0; i < nearCount; i++) {
      this.props.push({
        id: ids[i % ids.length],
        x: (i / nearCount) * (scene.arenaW + 320) - 160 + rng.range(-60, 60),
        y: rng.range(DEPTH_MIN - 30, DEPTH_MAX + 20),
        s: rng.range(0.75, 1.35),
        seed: rng.next() * 100,
        layer: 1,
      });
    }
    // 前景遮蔽物件（大剪影）
    const fgCount = 6;
    for (let i = 0; i < fgCount; i++) {
      this.props.push({
        id: ids[(i * 3) % ids.length],
        x: (i / fgCount) * (scene.arenaW + 500) - 200 + rng.range(-80, 80),
        y: DEPTH_MAX + 90,
        s: rng.range(2.2, 3.4),
        seed: rng.next() * 100,
        layer: 2,
      });
    }
    // 星星
    this.stars = [];
    for (let i = 0; i < 130; i++) {
      this.stars.push({ x: rng.next() * DESIGN_W * 1.6, y: rng.next() * DESIGN_H * 0.55, r: rng.range(0.6, 2.1), p: rng.next() * TAU });
    }
    // 雲
    this.clouds = [];
    for (let i = 0; i < 12; i++) {
      this.clouds.push({ x: rng.next() * DESIGN_W * 2, y: rng.range(30, 250), s: rng.range(0.6, 1.7), sp: rng.range(4, 20), a: rng.range(0.16, 0.5) });
    }
  }

  private ensureWeather(id: WeatherId, arenaW: number) {
    const key = id + arenaW;
    if (key === this.weatherKey && this.weatherP.length) return;
    this.weatherKey = key;
    const n = id === 'none' ? 0 : 190;
    this.weatherP = [];
    for (let i = 0; i < n; i++) {
      this.weatherP.push({
        x: rand(0, DESIGN_W), y: rand(-40, DESIGN_H),
        vx: rand(-30, 30), vy: rand(20, 90),
        r: rand(1.5, 5), rot: rand(0, TAU), vr: rand(-3, 3),
        a: rand(0.3, 1), ph: rand(0, TAU),
      });
    }
  }

  drawSky(ctx: CanvasRenderingContext2D, scene: SceneDef, cam: Cam, t: number) {
    const p = scene.palette;
    const key = `${scene.id}-${scene.variant}`;
    let g = this.skyCache.get(key);
    if (!g) {
      g = ctx.createLinearGradient(0, -40, 0, GROUND_Y + 60);
      g.addColorStop(0, p.skyTop);
      g.addColorStop(0.55, p.skyBottom);
      g.addColorStop(1, p.haze);
      this.skyCache.set(key, g);
    }
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, DESIGN_W, DESIGN_H);

    const night = scene.biome === 'void' || scene.variant === 2 || scene.variant === 3;
    // 星空
    if (night) {
      ctx.save();
      for (const s of this.stars) {
        const sx = ((s.x - cam.x * 0.04) % (DESIGN_W * 1.6) + DESIGN_W * 1.6) % (DESIGN_W * 1.6) - DESIGN_W * 0.3;
        const tw = 0.45 + 0.55 * Math.sin(t * 2.4 + s.p);
        ctx.globalAlpha = tw * 0.85;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(sx, s.y, s.r, 0, TAU); ctx.fill();
      }
      ctx.restore();
    }

    // 天體
    const sunX = DESIGN_W * 0.74 - cam.x * 0.03;
    const sunY = scene.biome === 'heaven' ? 150 : scene.biome === 'void' ? 190 : 175;
    const sunR = scene.biome === 'flame' || scene.biome === 'void' ? 96 : 70;
    const sunCol = scene.biome === 'heaven' ? '#fffbe8' : scene.biome === 'peak' ? '#ffe6a8' : '#ff6a3a';
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const rg = ctx.createRadialGradient(sunX, sunY, 4, sunX, sunY, sunR * 4.4);
    rg.addColorStop(0, sunCol);
    rg.addColorStop(0.12, withAlpha(sunCol, 0.55));
    rg.addColorStop(1, withAlpha(sunCol, 0));
    ctx.fillStyle = rg;
    ctx.beginPath(); ctx.arc(sunX, sunY, sunR * 4.4, 0, TAU); ctx.fill();
    ctx.globalAlpha = 0.95;
    ctx.fillStyle = sunCol;
    ctx.beginPath(); ctx.arc(sunX, sunY, sunR, 0, TAU); ctx.fill();
    ctx.restore();

    // 雲帶
    ctx.save();
    for (const c of this.clouds) {
      const cx = ((c.x + t * c.sp - cam.x * 0.08) % (DESIGN_W * 2) + DESIGN_W * 2) % (DESIGN_W * 2) - DESIGN_W * 0.5;
      ctx.globalAlpha = c.a * (scene.biome === 'void' ? 0.5 : 1);
      ctx.fillStyle = scene.biome === 'flame' || scene.biome === 'void' ? '#2a0a10' : '#ffffff';
      drawCloud(ctx, cx, c.y, 130 * c.s, 34 * c.s);
    }
    ctx.restore();

    // 神光（天宮）
    if (scene.biome === 'heaven' || scene.biome === 'void') {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 7; i++) {
        const bx = ((i * 220 - cam.x * 0.1) % (DESIGN_W + 400)) - 100;
        const a = 0.05 + 0.05 * Math.sin(t * 0.7 + i);
        const g2 = ctx.createLinearGradient(bx, 0, bx + 120, DESIGN_H);
        g2.addColorStop(0, withAlpha(scene.biome === 'void' ? '#ff5a8a' : '#fffbe8', a * 2));
        g2.addColorStop(1, withAlpha(scene.biome === 'void' ? '#ff5a8a' : '#fffbe8', 0));
        ctx.fillStyle = g2;
        ctx.beginPath();
        ctx.moveTo(bx, -20); ctx.lineTo(bx + 90, -20);
        ctx.lineTo(bx + 300, DESIGN_H); ctx.lineTo(bx + 120, DESIGN_H);
        ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    }
  }

  drawFarImages(ctx: CanvasRenderingContext2D, scene: SceneDef, cam: Cam, t: number) {
    const art = BIOME_ART[scene.biome];
    const zoom = BIOME_ZOOM[scene.biome][scene.variant % BIOME_ZOOM[scene.biome].length];
    const p = scene.palette;
    // 遠景
    if (imgReady(art.far)) {
      const flip = scene.variant % 2 === 1;
      drawBg(ctx, art.far, 0, 0, DESIGN_W, DESIGN_H * 0.95, {
        offsetX: cam.x * 0.16 * (flip ? -1 : 1),
        offsetY: 40 + Math.sin(t * 0.1) * 6 - scene.variant * 12,
        zoom: zoom * (flip ? 1.08 : 1),
        alpha: 0.98,
      });
      // 色調統一
      ctx.save();
      ctx.globalCompositeOperation = 'overlay';
      ctx.globalAlpha = 0.5;
      ctx.fillStyle = p.tint;
      ctx.fillRect(0, 0, DESIGN_W, DESIGN_H);
      ctx.restore();
    }
    // 中景
    if (imgReady(art.near)) {
      drawBg(ctx, art.near, 0, DESIGN_H * 0.18, DESIGN_W, DESIGN_H * 0.8, {
        offsetX: cam.x * 0.42,
        offsetY: -20 + scene.variant * 8,
        zoom: zoom * 1.05,
        alpha: 0.92,
      });
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.globalAlpha = scene.biome === 'void' ? 0.55 : 0.3;
      ctx.fillStyle = p.fog;
      ctx.fillRect(0, DESIGN_H * 0.18, DESIGN_W, DESIGN_H * 0.8);
      ctx.restore();
    }
    // 霧氣帶
    ctx.save();
    const fg = ctx.createLinearGradient(0, GROUND_Y - 190, 0, GROUND_Y + 40);
    fg.addColorStop(0, withAlpha(p.fog, 0));
    fg.addColorStop(1, withAlpha(p.fog, 0.42));
    ctx.fillStyle = fg;
    ctx.fillRect(0, GROUND_Y - 190, DESIGN_W, 230);
    ctx.restore();
  }

  drawGround(ctx: CanvasRenderingContext2D, scene: SceneDef, cam: Cam, t: number) {
    const p = scene.palette;
    const top = GROUND_Y + DEPTH_MIN - 6;
    const bottom = DESIGN_H;
    ctx.save();
    const g = ctx.createLinearGradient(0, top, 0, bottom);
    g.addColorStop(0, p.groundDark);
    g.addColorStop(0.35, p.ground);
    g.addColorStop(1, mixDark(p.groundDark, 0.55));
    ctx.fillStyle = g;
    ctx.fillRect(0, top, DESIGN_W, bottom - top);

    const ox = -cam.x;
    // 透視橫紋（深度行）
    ctx.globalAlpha = 0.35;
    for (let y = DEPTH_MIN; y <= DEPTH_MAX + 100; y += 22) {
      const sy = GROUND_Y + y;
      if (sy < top || sy > bottom) continue;
      const k = (y - DEPTH_MIN) / (DEPTH_MAX + 100 - DEPTH_MIN);
      ctx.strokeStyle = withAlpha(p.light, 0.05 + k * 0.07);
      ctx.lineWidth = 1 + k * 2;
      ctx.beginPath(); ctx.moveTo(0, sy); ctx.lineTo(DESIGN_W, sy); ctx.stroke();
    }
    // 縱向接縫（石板）
    ctx.globalAlpha = 0.28;
    const tileW = 132;
    for (let i = -2; i < DESIGN_W / tileW + 3; i++) {
      const sx = i * tileW + (ox % tileW);
      ctx.strokeStyle = withAlpha(p.groundDark, 0.5);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(sx, top);
      ctx.lineTo(sx + 34, bottom);
      ctx.stroke();
    }

    // 生物群系專屬地表細節
    const rng = new Rng(hashStr(scene.id));
    ctx.globalAlpha = 1;
    if (scene.biome === 'flame' || scene.biome === 'void') {
      // 熔岩裂縫（脈動發光）
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 9; i++) {
        const bx = ((rng.range(0, scene.arenaW) + ox) % (DESIGN_W + 400)) - 200;
        const by = GROUND_Y + rng.range(DEPTH_MIN, DEPTH_MAX + 60);
        const pulse = 0.5 + 0.5 * Math.sin(t * 2.2 + i * 1.7);
        ctx.strokeStyle = withAlpha(scene.biome === 'void' ? '#ff2d40' : '#ff6a1a', 0.25 + pulse * 0.5);
        ctx.lineWidth = 3 + pulse * 4;
        ctx.beginPath();
        ctx.moveTo(bx, by);
        ctx.lineTo(bx + 60, by + 12);
        ctx.lineTo(bx + 90, by - 6);
        ctx.lineTo(bx + 170, by + 16);
        ctx.stroke();
      }
      ctx.restore();
    } else if (scene.biome === 'heaven') {
      // 白玉地磚金縫
      ctx.save();
      ctx.globalAlpha = 0.5;
      ctx.strokeStyle = '#ffe6a8';
      ctx.lineWidth = 1.5;
      for (let i = -2; i < DESIGN_W / 96 + 3; i++) {
        const sx = i * 96 + (ox % 96);
        ctx.beginPath(); ctx.moveTo(sx, top); ctx.lineTo(sx + 22, bottom); ctx.stroke();
      }
      ctx.globalAlpha = 0.16;
      ctx.fillStyle = '#fffbe8';
      for (let i = 0; i < 14; i++) {
        const bx = ((rng.range(0, scene.arenaW) + ox) % (DESIGN_W + 200)) - 100;
        const by = GROUND_Y + rng.range(DEPTH_MIN, DEPTH_MAX + 60);
        ctx.beginPath(); ctx.ellipse(bx, by, 34, 12, 0, 0, TAU); ctx.fill();
      }
      ctx.restore();
    } else {
      // 石徑 + 草叢 + 碎石
      ctx.save();
      ctx.globalAlpha = 0.5;
      for (let i = 0; i < 26; i++) {
        const bx = ((rng.range(0, scene.arenaW) + ox) % (DESIGN_W + 200)) - 100;
        const by = GROUND_Y + rng.range(DEPTH_MIN, DEPTH_MAX + 70);
        const s = rng.range(4, 14);
        ctx.fillStyle = withAlpha(i % 3 === 0 ? '#7cb35f' : p.groundDark, 0.5);
        ctx.beginPath(); ctx.ellipse(bx, by, s, s * 0.45, 0, 0, TAU); ctx.fill();
      }
      ctx.restore();
    }

    // 地面頂端高光（與背景交接）
    ctx.save();
    const hg = ctx.createLinearGradient(0, top - 16, 0, top + 26);
    hg.addColorStop(0, withAlpha(p.light, 0));
    hg.addColorStop(0.5, withAlpha(p.light, 0.28));
    hg.addColorStop(1, withAlpha(p.light, 0));
    ctx.fillStyle = hg;
    ctx.fillRect(0, top - 16, DESIGN_W, 42);
    ctx.restore();
    ctx.restore();
  }

  drawProps(ctx: CanvasRenderingContext2D, scene: SceneDef, cam: Cam, t: number, layer: 0 | 1 | 2) {
    this.buildLayout(scene);
    const par = layer === 0 ? 0.66 : layer === 1 ? 1 : 1.3;
    ctx.save();
    if (layer === 0) {
      ctx.globalAlpha = 0.55;
      ctx.filter = 'none';
    }
    if (layer === 2) ctx.globalAlpha = 0.95;
    for (const pr of this.props) {
      if (pr.layer !== layer) continue;
      const sx = pr.x - cam.x * par;
      if (sx < -420 || sx > DESIGN_W + 420) continue;
      const sy = layer === 0 ? GROUND_Y + DEPTH_MIN - 40 + pr.y : GROUND_Y + pr.y;
      drawProp(ctx, pr.id, sx, sy, pr.s * (layer === 2 ? 1.5 : 1), t, pr.seed, scene, layer);
    }
    ctx.restore();
  }

  drawWeather(ctx: CanvasRenderingContext2D, scene: SceneDef, dt: number, t: number, quality: number) {
    const id = scene.weather;
    if (id === 'none' || quality < 0.25) return;
    this.ensureWeather(id, scene.arenaW);
    const n = Math.round(this.weatherP.length * clamp(quality, 0.25, 1));
    ctx.save();
    for (let i = 0; i < n; i++) {
      const p = this.weatherP[i];
      p.ph += dt * 2;
      switch (id) {
        case 'petal':
          p.x += (p.vx + Math.sin(p.ph) * 42) * dt;
          p.y += (p.vy * 0.7 + 22) * dt;
          p.rot += p.vr * dt;
          ctx.globalAlpha = p.a * 0.9;
          ctx.save();
          ctx.translate(p.x, p.y); ctx.rotate(p.rot);
          ctx.fillStyle = i % 4 === 0 ? '#ffffff' : '#ffb7d5';
          ctx.beginPath(); ctx.ellipse(0, 0, p.r * 2.1, p.r, 0, 0, TAU); ctx.fill();
          ctx.restore();
          break;
        case 'ember':
          p.x += (p.vx + Math.sin(p.ph * 1.4) * 26) * dt;
          p.y -= (p.vy * 0.8 + 40) * dt;
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = p.a * (0.5 + 0.5 * Math.sin(p.ph * 5));
          ctx.fillStyle = i % 3 === 0 ? '#ffc93c' : '#ff6a1a';
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 0.85, 0, TAU); ctx.fill();
          ctx.globalCompositeOperation = 'source-over';
          break;
        case 'ash':
          p.x += (p.vx + Math.sin(p.ph) * 20) * dt;
          p.y += (p.vy * 0.45 + 26) * dt;
          p.rot += p.vr * dt * 0.4;
          ctx.globalAlpha = p.a * 0.55;
          ctx.fillStyle = '#9a8a80';
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
          ctx.fillRect(-p.r, -p.r * 0.4, p.r * 2, p.r * 0.8);
          ctx.restore();
          break;
        case 'snow':
          p.x += (p.vx + Math.sin(p.ph) * 30) * dt;
          p.y += (p.vy * 0.5 + 30) * dt;
          ctx.globalAlpha = p.a * 0.85;
          ctx.fillStyle = '#ffffff';
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 0.8, 0, TAU); ctx.fill();
          break;
        case 'light':
          p.x += Math.sin(p.ph * 0.7) * 14 * dt;
          p.y -= (p.vy * 0.28 + 14) * dt;
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = p.a * (0.35 + 0.4 * Math.sin(p.ph * 2.2));
          ctx.fillStyle = i % 5 === 0 ? '#ffe6a8' : '#fffbe8';
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 0.7, 0, TAU); ctx.fill();
          ctx.globalCompositeOperation = 'source-over';
          break;
        case 'rain':
          p.x += (-120 + p.vx) * dt;
          p.y += (p.vy * 6 + 620) * dt;
          ctx.globalAlpha = p.a * 0.34;
          ctx.strokeStyle = '#cfe8ff';
          ctx.lineWidth = 1.4;
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + 9, p.y + 26); ctx.stroke();
          break;
      }
      if (p.y > DESIGN_H + 40) { p.y = -30; p.x = rand(0, DESIGN_W); }
      if (p.y < -60) { p.y = DESIGN_H + 20; p.x = rand(0, DESIGN_W); }
      if (p.x > DESIGN_W + 40) p.x = -30;
      if (p.x < -40) p.x = DESIGN_W + 30;
    }
    ctx.restore();
    void t;
  }

  /** 整體色調與暗角 */
  drawGrade(ctx: CanvasRenderingContext2D, scene: SceneDef, lowHp: number) {
    ctx.save();
    ctx.globalCompositeOperation = 'overlay';
    ctx.globalAlpha = scene.palette.tintAlpha;
    ctx.fillStyle = scene.palette.tint;
    ctx.fillRect(0, 0, DESIGN_W, DESIGN_H);
    ctx.restore();
    // 暗角
    ctx.save();
    const g = ctx.createRadialGradient(DESIGN_W / 2, DESIGN_H / 2, DESIGN_H * 0.34, DESIGN_W / 2, DESIGN_H / 2, DESIGN_H * 0.95);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(1, `rgba(6,3,10,${0.55 + lowHp * 0.2})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, DESIGN_W, DESIGN_H);
    ctx.restore();
    // 低血量紅脈動
    if (lowHp > 0.01) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const rg = ctx.createRadialGradient(DESIGN_W / 2, DESIGN_H / 2, DESIGN_H * 0.25, DESIGN_W / 2, DESIGN_H / 2, DESIGN_H * 0.85);
      rg.addColorStop(0, 'rgba(255,45,64,0)');
      rg.addColorStop(1, `rgba(255,45,64,${0.3 * lowHp})`);
      ctx.fillStyle = rg;
      ctx.fillRect(0, 0, DESIGN_W, DESIGN_H);
      ctx.restore();
    }
  }
}

/* ============================ 程序化物件 ============================ */
function drawProp(
  ctx: CanvasRenderingContext2D, id: string, x: number, y: number, s: number,
  t: number, seed: number, scene: SceneDef, layer: number,
) {
  const p = scene.palette;
  const sway = Math.sin(t * 1.1 + seed) * 0.035;
  const dark = layer === 2 ? 0.86 : layer === 0 ? 0.5 : 0.72;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.rotate(layer === 2 ? sway * 0.5 : 0);
  const C = (c: string) => mixDark(c, dark);
  switch (id) {
    case 'peach': { // 桃樹
      ctx.fillStyle = C('#4a3226');
      ctx.beginPath(); ctx.moveTo(-9, 0); ctx.lineTo(-4, -110); ctx.lineTo(5, -112); ctx.lineTo(11, 0); ctx.closePath(); ctx.fill();
      ctx.save(); ctx.rotate(sway * 2);
      for (let i = 0; i < 5; i++) {
        const a = -Math.PI / 2 + (i - 2) * 0.55;
        ctx.fillStyle = C(i % 2 ? '#ff9dc0' : '#ffc2d9');
        ctx.beginPath(); ctx.ellipse(Math.cos(a) * 52, -118 + Math.sin(a) * 34, 44, 30, a, 0, TAU); ctx.fill();
      }
      ctx.fillStyle = C('#ffd9e6');
      ctx.beginPath(); ctx.ellipse(0, -140, 40, 28, 0, 0, TAU); ctx.fill();
      ctx.restore();
      break;
    }
    case 'pine': { // 松樹
      ctx.fillStyle = C('#3a2c1e');
      ctx.fillRect(-7, -70, 14, 70);
      for (let i = 0; i < 4; i++) {
        const w = 78 - i * 15, yy = -60 - i * 34;
        ctx.fillStyle = C(i % 2 ? '#1f4a2a' : '#2a5c34');
        ctx.beginPath(); ctx.moveTo(-w, yy); ctx.lineTo(0, yy - 44); ctx.lineTo(w, yy); ctx.closePath(); ctx.fill();
      }
      break;
    }
    case 'lantern': { // 石燈籠
      ctx.fillStyle = C('#8a8272');
      ctx.fillRect(-16, -14, 32, 14);
      ctx.fillRect(-6, -74, 12, 60);
      ctx.fillStyle = C('#a09884');
      ctx.beginPath(); ctx.moveTo(-26, -74); ctx.lineTo(26, -74); ctx.lineTo(18, -100); ctx.lineTo(-18, -100); ctx.closePath(); ctx.fill();
      const fl = 0.6 + 0.4 * Math.sin(t * 7 + seed);
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const g = ctx.createRadialGradient(0, -86, 2, 0, -86, 46 * fl);
      g.addColorStop(0, 'rgba(255,220,140,0.95)');
      g.addColorStop(1, 'rgba(255,150,50,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, -86, 46 * fl, 0, TAU); ctx.fill();
      ctx.restore();
      ctx.fillStyle = C('#6a6252');
      ctx.beginPath(); ctx.moveTo(-30, -100); ctx.lineTo(30, -100); ctx.lineTo(0, -124); ctx.closePath(); ctx.fill();
      break;
    }
    case 'rock': { // 岩石
      ctx.fillStyle = C('#6a6252');
      ctx.beginPath();
      ctx.moveTo(-42, 0); ctx.lineTo(-30, -34); ctx.lineTo(-6, -48); ctx.lineTo(24, -36); ctx.lineTo(44, 0);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = C('#8a8272');
      ctx.beginPath(); ctx.moveTo(-30, -34); ctx.lineTo(-6, -48); ctx.lineTo(4, -20); ctx.lineTo(-20, -14); ctx.closePath(); ctx.fill();
      break;
    }
    case 'grass': { // 草叢
      ctx.strokeStyle = C('#5a8f4a'); ctx.lineWidth = 3; ctx.lineCap = 'round';
      for (let i = 0; i < 7; i++) {
        const a = -Math.PI / 2 + (i - 3) * 0.22 + sway * 3;
        ctx.beginPath(); ctx.moveTo(i * 5 - 15, 0);
        ctx.quadraticCurveTo(i * 5 - 15 + Math.cos(a) * 14, -22, i * 5 - 15 + Math.cos(a) * 26, -40);
        ctx.stroke();
      }
      break;
    }
    case 'gate': { // 鳥居／山門
      ctx.fillStyle = C('#b02a2a');
      ctx.fillRect(-90, -190, 16, 190);
      ctx.fillRect(74, -190, 16, 190);
      ctx.fillStyle = C('#d03a3a');
      ctx.beginPath(); ctx.moveTo(-124, -190); ctx.lineTo(124, -190); ctx.lineTo(112, -206); ctx.lineTo(-112, -206); ctx.closePath(); ctx.fill();
      ctx.fillRect(-100, -166, 200, 12);
      ctx.fillStyle = C('#2a1a1a');
      ctx.fillRect(-16, -152, 32, 22);
      break;
    }
    case 'banner': { // 旗幟
      ctx.fillStyle = C('#4a3a2a');
      ctx.fillRect(-3, -170, 6, 170);
      ctx.save();
      const w = Math.sin(t * 2.4 + seed) * 10;
      ctx.fillStyle = C('#c02a3a');
      ctx.beginPath();
      ctx.moveTo(3, -166); ctx.quadraticCurveTo(50 + w, -150, 44 + w, -100);
      ctx.lineTo(3, -96); ctx.closePath(); ctx.fill();
      ctx.fillStyle = C('#ffc93c');
      ctx.beginPath(); ctx.arc(24 + w * 0.6, -132, 9, 0, TAU); ctx.fill();
      ctx.restore();
      break;
    }
    case 'brazier': { // 火盆
      ctx.fillStyle = C('#4a4038');
      ctx.beginPath(); ctx.moveTo(-22, 0); ctx.lineTo(-14, -46); ctx.lineTo(14, -46); ctx.lineTo(22, 0); ctx.closePath(); ctx.fill();
      ctx.fillStyle = C('#6a5a4a');
      ctx.beginPath(); ctx.ellipse(0, -50, 26, 10, 0, 0, TAU); ctx.fill();
      const fl = 0.7 + 0.3 * Math.sin(t * 11 + seed);
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const g = ctx.createRadialGradient(0, -66, 4, 0, -66, 66 * fl);
      g.addColorStop(0, 'rgba(255,240,180,0.95)');
      g.addColorStop(0.4, 'rgba(255,140,40,0.6)');
      g.addColorStop(1, 'rgba(255,60,20,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(-20, -52);
      ctx.quadraticCurveTo(-14, -96 * fl, 0, -110 * fl);
      ctx.quadraticCurveTo(14, -96 * fl, 20, -52);
      ctx.closePath(); ctx.fill();
      ctx.restore();
      break;
    }
    case 'pillar': { // 石柱
      ctx.fillStyle = C('#8a8272');
      ctx.fillRect(-22, -260, 44, 260);
      ctx.fillStyle = C('#a09884');
      ctx.fillRect(-30, -276, 60, 20);
      ctx.fillRect(-30, -14, 60, 14);
      ctx.fillStyle = C('#6a6252');
      for (let i = 0; i < 5; i++) ctx.fillRect(-22, -250 + i * 50, 44, 4);
      break;
    }
    case 'statue': { // 石像
      ctx.fillStyle = C('#7a7262');
      ctx.fillRect(-34, -20, 68, 20);
      ctx.beginPath(); ctx.moveTo(-26, -20); ctx.lineTo(-20, -130); ctx.lineTo(20, -130); ctx.lineTo(26, -20); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.arc(0, -152, 26, 0, TAU); ctx.fill();
      ctx.fillStyle = C('#5a5245');
      ctx.fillRect(-46, -120, 20, 100);
      ctx.fillRect(26, -120, 20, 100);
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = withAlpha('#ff3b52', 0.5 + 0.3 * Math.sin(t * 3 + seed));
      ctx.beginPath(); ctx.arc(-9, -156, 4, 0, TAU); ctx.arc(9, -156, 4, 0, TAU); ctx.fill();
      ctx.restore();
      break;
    }
    case 'crystal': { // 水晶
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const gl = 0.6 + 0.4 * Math.sin(t * 2 + seed);
      const g = ctx.createLinearGradient(0, -120, 0, 0);
      g.addColorStop(0, withAlpha('#9fe8ff', 0.9 * gl));
      g.addColorStop(1, withAlpha('#2a7fd4', 0.25));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(0, -140); ctx.lineTo(24, -60); ctx.lineTo(14, 0); ctx.lineTo(-16, 0); ctx.lineTo(-26, -70);
      ctx.closePath(); ctx.fill();
      ctx.restore();
      break;
    }
    case 'chain': { // 鎖鏈
      ctx.strokeStyle = C('#6a6252'); ctx.lineWidth = 5;
      const sw = Math.sin(t * 1.3 + seed) * 14;
      ctx.beginPath();
      ctx.moveTo(0, -260);
      ctx.quadraticCurveTo(sw, -130, sw * 0.4, 0);
      ctx.stroke();
      break;
    }
    case 'bone': { // 巨骨
      ctx.fillStyle = C('#e0d8c0');
      ctx.beginPath();
      ctx.moveTo(-70, 0); ctx.quadraticCurveTo(-40, -150, 20, -190);
      ctx.quadraticCurveTo(50, -200, 62, -180);
      ctx.quadraticCurveTo(10, -140, -30, 0);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = C('#b8b098');
      for (let i = 0; i < 4; i++) {
        ctx.beginPath(); ctx.ellipse(-40 + i * 24, -20 - i * 40, 12, 8, -0.6, 0, TAU); ctx.fill();
      }
      break;
    }
    case 'skull': { // 頭骨堆
      ctx.fillStyle = C('#ddd5bd');
      for (let i = 0; i < 3; i++) {
        ctx.beginPath(); ctx.arc(-24 + i * 24, -12 - (i === 1 ? 16 : 0), 16, 0, TAU); ctx.fill();
        ctx.fillStyle = C('#2a2418');
        ctx.beginPath(); ctx.arc(-30 + i * 24, -14 - (i === 1 ? 16 : 0), 4, 0, TAU); ctx.arc(-18 + i * 24, -14 - (i === 1 ? 16 : 0), 4, 0, TAU); ctx.fill();
        ctx.fillStyle = C('#ddd5bd');
      }
      break;
    }
    case 'ruin': { // 廢墟牆
      ctx.fillStyle = C('#4a4038');
      ctx.beginPath();
      ctx.moveTo(-90, 0); ctx.lineTo(-90, -90); ctx.lineTo(-50, -110); ctx.lineTo(-20, -70);
      ctx.lineTo(30, -100); ctx.lineTo(70, -60); ctx.lineTo(90, -80); ctx.lineTo(90, 0);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = C('#5a5048');
      for (let i = 0; i < 6; i++) ctx.fillRect(-84 + i * 30, -60 + (i % 2) * 24, 24, 12);
      break;
    }
    case 'bridge': { // 石橋
      ctx.fillStyle = C('#7a7262');
      ctx.beginPath();
      ctx.moveTo(-160, 0); ctx.quadraticCurveTo(0, -70, 160, 0);
      ctx.lineTo(160, 16); ctx.quadraticCurveTo(0, -46, -160, 16);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = C('#9a9282'); ctx.lineWidth = 5;
      for (let i = -3; i <= 3; i++) {
        ctx.beginPath(); ctx.moveTo(i * 46, -34 + Math.abs(i) * 8); ctx.lineTo(i * 46, -62 + Math.abs(i) * 8); ctx.stroke();
      }
      break;
    }
    case 'lotus': { // 蓮花燈
      const fl = 0.7 + 0.3 * Math.sin(t * 2.6 + seed);
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const g = ctx.createRadialGradient(0, -22, 2, 0, -22, 54 * fl);
      g.addColorStop(0, 'rgba(255,240,190,0.9)');
      g.addColorStop(1, 'rgba(255,200,120,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, -22, 54 * fl, 0, TAU); ctx.fill();
      ctx.restore();
      ctx.fillStyle = C('#ffc2d9');
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU;
        ctx.beginPath(); ctx.ellipse(Math.cos(a) * 14, -18 + Math.sin(a) * 6, 14, 8, a, 0, TAU); ctx.fill();
      }
      break;
    }
    case 'bell': { // 巨鐘
      ctx.fillStyle = C('#c8a05a');
      ctx.beginPath();
      ctx.moveTo(-52, 0); ctx.quadraticCurveTo(-46, -120, 0, -140);
      ctx.quadraticCurveTo(46, -120, 52, 0); ctx.closePath(); ctx.fill();
      ctx.fillStyle = C('#e0c07a');
      ctx.fillRect(-56, -12, 112, 12);
      ctx.fillStyle = C('#8a6a3a');
      for (let i = 0; i < 3; i++) ctx.fillRect(-46, -108 + i * 34, 92, 6);
      break;
    }
    case 'arch': { // 天門拱
      ctx.fillStyle = C('#e8e0cc');
      ctx.fillRect(-110, -230, 26, 230);
      ctx.fillRect(84, -230, 26, 230);
      ctx.beginPath(); ctx.moveTo(-124, -230); ctx.quadraticCurveTo(0, -300, 124, -230); ctx.lineTo(124, -206); ctx.quadraticCurveTo(0, -268, -124, -206); ctx.closePath(); ctx.fill();
      ctx.fillStyle = C('#ffc93c');
      ctx.beginPath(); ctx.arc(0, -256, 14, 0, TAU); ctx.fill();
      break;
    }
    case 'throne': { // 王座
      ctx.fillStyle = C('#2a1a2a');
      ctx.beginPath(); ctx.moveTo(-80, 0); ctx.lineTo(-70, -200); ctx.lineTo(0, -250); ctx.lineTo(70, -200); ctx.lineTo(80, 0); ctx.closePath(); ctx.fill();
      ctx.fillStyle = C('#ffc93c');
      ctx.beginPath(); ctx.arc(0, -180, 18, 0, TAU); ctx.fill();
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = withAlpha('#ff2d40', 0.3 + 0.3 * Math.sin(t * 2 + seed));
      ctx.beginPath(); ctx.arc(0, -180, 44, 0, TAU); ctx.fill();
      ctx.restore();
      break;
    }
    case 'lava': { // 熔岩池
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const g = ctx.createRadialGradient(0, 0, 4, 0, 0, 90);
      g.addColorStop(0, 'rgba(255,240,180,0.9)');
      g.addColorStop(0.4, 'rgba(255,120,30,0.6)');
      g.addColorStop(1, 'rgba(255,60,10,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.ellipse(0, 0, 90, 26, 0, 0, TAU); ctx.fill();
      ctx.restore();
      break;
    }
    case 'waterfall': { // 瀑布
      ctx.save();
      ctx.globalAlpha = 0.5;
      const g = ctx.createLinearGradient(0, -320, 0, 0);
      g.addColorStop(0, withAlpha('#eafcff', 0.8));
      g.addColorStop(1, withAlpha('#4fd8ff', 0.15));
      ctx.fillStyle = g;
      for (let i = 0; i < 4; i++) {
        const off = ((t * 260 + i * 90) % 320);
        ctx.fillRect(-34 + i * 18, -320 + off, 12, 90);
      }
      ctx.restore();
      break;
    }
    case 'stone':
    case 'cloud':
    default: { // 石塊／雲平台
      if (id === 'cloud') {
        ctx.globalAlpha = 0.55;
        ctx.fillStyle = C('#ffffff');
        drawCloud(ctx, 0, -30, 120, 34);
      } else {
        ctx.fillStyle = C('#6a6252');
        ctx.beginPath(); ctx.ellipse(0, -10, 34, 18, 0, 0, TAU); ctx.fill();
      }
      break;
    }
  }
  ctx.restore();
  void p;
}

function drawCloud(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  ctx.beginPath();
  ctx.ellipse(x, y, w * 0.5, h, 0, 0, TAU);
  ctx.ellipse(x - w * 0.28, y + h * 0.24, w * 0.3, h * 0.72, 0, 0, TAU);
  ctx.ellipse(x + w * 0.3, y + h * 0.2, w * 0.34, h * 0.8, 0, 0, TAU);
  ctx.fill();
}

/* ============================ 顏色工具 ============================ */
export function withAlpha(hex: string, a: number) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${clamp(a, 0, 1)})`;
}
export function mixDark(hex: string, k: number) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  const r = Math.round(((n >> 16) & 255) * (1 - k * 0.6));
  const g = Math.round(((n >> 8) & 255) * (1 - k * 0.6));
  const b = Math.round((n & 255) * (1 - k * 0.6));
  return `rgb(${r},${g},${b})`;
}
function hashStr(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
export const lerpC = lerp;
export const clampC = clamp;
export const randC = rand;
export const imgOf = getImg;
