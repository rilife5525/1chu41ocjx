/**
 * 特效系統（世界特效 + 畫面效果）
 * ------------------------------------------------------------------
 * 世界特效：斬擊弧、衝擊環、地裂、光束、雷電、氣場、殘影、光柱、地波、
 *           墨漬、煙塵、法陣、十字斬 —— 每一種都有獨立繪製邏輯，絕不共用。
 * 畫面效果：震動、閃白、停頓（hitstop）、子彈時間、色差、暗角、
 *           電影黑邊、轉場拭除、径向模糊。
 */
import type { FxId } from '../core/types';
import { Ease, Pool, TAU, clamp, lerp, rand, swapRemove } from '../core/util';
import type { ParticleSystem } from './particles';

export type FxKind =
  | 'slash' | 'ring' | 'crack' | 'beam' | 'bolt' | 'aura' | 'ghost'
  | 'pillar' | 'wave' | 'splat' | 'dust' | 'rune' | 'cross' | 'impact' | 'streak';

export interface FxObj {
  kind: FxKind;
  x: number; y: number; z: number;
  x2: number; y2: number; z2: number;
  t: number; dur: number;
  dir: number; scale: number; rot: number;
  color: string; color2: string;
  w: number; h: number;
  alpha: number;
  data: number[];
  dead: boolean;
}

const ELEMENT_COLORS: Record<string, [string, string, string]> = {
  flame: ['#ff7a1a', '#ff2d40', '#ffc93c'],
  water: ['#4fd8ff', '#1f6f8b', '#eafcff'],
  wind: ['#eaf6ff', '#9fe8ff', '#ffffff'],
  rock: ['#e0a558', '#8a6a3a', '#ffe6b0'],
  fox: ['#a56bff', '#7fd4ff', '#ff5ad6'],
  iron: ['#c9d3e0', '#7a8496', '#ffffff'],
  holy: ['#ffe6a8', '#ffc93c', '#ffffff'],
  void: ['#ff2d40', '#5b0a20', '#ffa0b0'],
};

export const elemColor = (name: string, i = 0) => (ELEMENT_COLORS[name] ?? ELEMENT_COLORS.flame)[i];
export const elemOf = (fx: FxId): string => {
  const n = fx.replace(/^(slash|impact|beam)/, '');
  const key = n.charAt(0).toLowerCase() + n.slice(1);
  const map: Record<string, string> = {
    flame: 'flame', fire: 'flame', water: 'water', wind: 'wind', rock: 'rock',
    fox: 'fox', iron: 'iron', holy: 'holy',
  };
  return map[key] ?? 'flame';
};

const resetFx = (f: FxObj) => {
  f.kind = 'slash'; f.x = f.y = f.z = f.x2 = f.y2 = f.z2 = 0; f.t = 0; f.dur = 1;
  f.dir = 1; f.scale = 1; f.rot = 0; f.color = '#fff'; f.color2 = '#fff';
  f.w = 0; f.h = 0; f.alpha = 1; f.data.length = 0; f.dead = false;
};

export interface FxOpts {
  x?: number; y?: number; z?: number; x2?: number; y2?: number; z2?: number;
  dir?: number; scale?: number; rot?: number; color?: string; color2?: string;
  dur?: number; w?: number; h?: number; alpha?: number; elem?: string; data?: number[];
}

export class EffectSystem {
  pool = new Pool<FxObj>(() => ({
    kind: 'slash', x: 0, y: 0, z: 0, x2: 0, y2: 0, z2: 0, t: 0, dur: 1, dir: 1, scale: 1, rot: 0,
    color: '#fff', color2: '#fff', w: 0, h: 0, alpha: 1, data: [], dead: false,
  }), resetFx, 64, 600);

  budget = 1;
  private ps: ParticleSystem;
  constructor(ps: ParticleSystem) { this.ps = ps; }
  setBudget(b: number) { this.budget = clamp(b, 0.25, 1); }

  private make(kind: FxKind, o: FxOpts, dur: number): FxObj | null {
    if (this.pool.size > 380 * this.budget) return null;
    const f = this.pool.obtain();
    if (!f) return null;
    f.kind = kind;
    f.x = o.x ?? 0; f.y = o.y ?? 0; f.z = o.z ?? 0;
    f.x2 = o.x2 ?? f.x; f.y2 = o.y2 ?? f.y; f.z2 = o.z2 ?? f.z;
    f.t = 0; f.dur = o.dur ?? dur;
    f.dir = o.dir ?? 1; f.scale = o.scale ?? 1; f.rot = o.rot ?? 0;
    f.color = o.color ?? '#ffffff'; f.color2 = o.color2 ?? o.color ?? '#ffffff';
    f.w = o.w ?? 0; f.h = o.h ?? 0; f.alpha = o.alpha ?? 1;
    f.data = o.data ? [...o.data] : [];
    f.dead = false;
    return f;
  }

  /** 斜向斬擊弧（依元素配色，形狀各異） */
  slash(x: number, y: number, z: number, o: FxOpts = {}) {
    const el = o.elem ?? 'flame';
    const f = this.make('slash', {
      ...o, x, y, z, color: o.color ?? elemColor(el, 0), color2: o.color2 ?? elemColor(el, 2),
      dur: o.dur ?? 0.3, rot: o.rot ?? rand(-0.5, 0.5),
    }, 0.3);
    if (!f) return;
    f.data.push(rand(0.6, 1.4), rand(-1, 1));
    this.ps.emit({
      kind: el === 'water' ? 'drop' : el === 'wind' ? 'feather' : 'spark',
      x, y, z, count: Math.round(7 * this.budget), speed: [120, 420], dir: o.dir ?? 0, spread: 1.5,
      life: [0.2, 0.45], size: [2, 5], color: f.color, color2: f.color2, grav: 500, additive: true, drag: 2.4,
    });
  }

  /** 十字交叉斬（奧義用） */
  cross(x: number, y: number, z: number, o: FxOpts = {}) {
    const f = this.make('cross', { ...o, x, y, z, dur: o.dur ?? 0.45 }, 0.45);
    if (!f) return;
    f.data.push(rand(0, TAU));
    this.ps.emit({ kind: 'spark', x, y, z, count: Math.round(20 * this.budget), speed: [200, 700], life: [0.2, 0.5], size: [2, 6], color: f.color, color2: f.color2, grav: 300, additive: true });
  }

  /** 地面衝擊環（橢圓透視） */
  ring(x: number, y: number, z: number, o: FxOpts = {}) {
    const f = this.make('ring', { ...o, x, y, z, dur: o.dur ?? 0.5 }, 0.5);
    if (!f) return;
    f.w = o.w ?? 240; f.h = o.h ?? 70;
    this.ps.emit({ kind: 'dust', x, y, z: 4, count: Math.round(12 * this.budget), speed: [140, 420], dir: 0, spread: TAU, life: [0.3, 0.7], size: [8, 22], color: f.color2, grav: 60, drag: 3, ySpread: 10 });
  }

  /** 地面裂紋 */
  crack(x: number, y: number, o: FxOpts = {}) {
    const f = this.make('crack', { ...o, x, y, z: 0, dur: o.dur ?? 1.6 }, 1.6);
    if (!f) return;
    const branches = 7 + Math.round(5 * this.budget);
    for (let i = 0; i < branches; i++) {
      const a = (i / branches) * TAU + rand(-0.2, 0.2);
      const len = rand(0.5, 1.4);
      f.data.push(a, len, rand(-0.4, 0.4));
    }
    this.ps.emit({ kind: 'debris', x, y, z: 6, count: Math.round(14 * this.budget), speed: [120, 380], vz: [120, 420], life: [0.4, 0.9], size: [3, 8], color: f.color2, grav: 1200, drag: 0.6 });
  }

  /** 光束（起點→終點） */
  beam(x: number, y: number, z: number, x2: number, y2: number, z2: number, o: FxOpts = {}) {
    const f = this.make('beam', { ...o, x, y, z, x2, y2, z2, dur: o.dur ?? 0.55 }, 0.55);
    if (!f) return;
    f.w = o.w ?? 26;
    this.ps.emit({ kind: 'spark', x: x2, y: y2, z: z2, count: Math.round(16 * this.budget), speed: [100, 500], life: [0.2, 0.6], size: [2, 6], color: f.color, color2: f.color2, grav: 200, additive: true });
  }

  /** 雷電折線 */
  bolt(x: number, y: number, z: number, o: FxOpts = {}) {
    const f = this.make('bolt', { ...o, x, y, z, dur: o.dur ?? 0.32 }, 0.32);
    if (!f) return;
    const segs = 9;
    let px = x, pz = z + (o.h ?? 420);
    f.data.push(px, pz);
    for (let i = 1; i <= segs; i++) {
      px = lerp(x, f.x2 || x, i / segs) + rand(-42, 42);
      pz = lerp(z + (o.h ?? 420), z, i / segs) + rand(-16, 16);
      f.data.push(px, pz);
    }
    this.ps.emit({ kind: 'spark', x, y, z: z + 10, count: Math.round(14 * this.budget), speed: [80, 380], life: [0.15, 0.4], size: [2, 4], color: '#dff6ff', additive: true, grav: 400 });
  }

  /** 蓄力氣場 */
  aura(x: number, y: number, z: number, o: FxOpts = {}) {
    const f = this.make('aura', { ...o, x, y, z, dur: o.dur ?? 0.7 }, 0.7);
    if (!f) return;
    f.w = o.w ?? 90; f.h = o.h ?? 140;
  }

  /** 殘影（衝刺／瞬身） */
  ghost(x: number, y: number, z: number, o: FxOpts = {}) {
    this.make('ghost', { ...o, x, y, z, dur: o.dur ?? 0.4 }, 0.4);
  }

  /** 光柱／焰柱 */
  pillar(x: number, y: number, o: FxOpts = {}) {
    const f = this.make('pillar', { ...o, x, y, z: 0, dur: o.dur ?? 0.9 }, 0.9);
    if (!f) return;
    f.w = o.w ?? 110; f.h = o.h ?? 900;
    this.ps.emit({ kind: 'ember', x, y, z: 10, count: Math.round(30 * this.budget), speed: [40, 260], vz: [300, 900], life: [0.4, 1.1], size: [3, 9], color: f.color, color2: f.color2, grav: -120, additive: true, drag: 1.1 });
  }

  /** 沿地面前進的波（岩浪／水波） */
  wave(x: number, y: number, o: FxOpts = {}) {
    const f = this.make('wave', { ...o, x, y, z: 0, dur: o.dur ?? 0.8 }, 0.8);
    if (!f) return;
    f.w = o.w ?? 620; f.h = o.h ?? 120;
  }

  /** 墨漬（擊殺演出，附著地面） */
  splat(x: number, y: number, o: FxOpts = {}) {
    const f = this.make('splat', { ...o, x, y, z: 0, dur: o.dur ?? 3.2 }, 3.2);
    if (!f) return;
    for (let i = 0; i < 9; i++) f.data.push(rand(0.3, 1.3), rand(0, TAU), rand(0.4, 1));
  }

  /** 煙塵 */
  dust(x: number, y: number, o: FxOpts = {}) {
    const f = this.make('dust', { ...o, x, y, z: 4, dur: o.dur ?? 0.55 }, 0.55);
    if (!f) return;
    f.w = o.w ?? 60;
    this.ps.emit({ kind: 'dust', x, y, z: 6, count: Math.round(10 * this.budget), speed: [60, 240], vz: [30, 160], life: [0.3, 0.8], size: [10, 28], color: f.color, color2: f.color2, grav: -20, drag: 2.6 });
  }

  /** 地面法陣（旋轉符文） */
  rune(x: number, y: number, o: FxOpts = {}) {
    const f = this.make('rune', { ...o, x, y, z: 0, dur: o.dur ?? 1.4 }, 1.4);
    if (!f) return;
    f.w = o.w ?? 260;
    f.data.push(rand(0, TAU));
  }

  /** 命中爆點（元素專屬） */
  impact(x: number, y: number, z: number, o: FxOpts = {}) {
    const el = o.elem ?? 'flame';
    const f = this.make('impact', { ...o, x, y, z, color: o.color ?? elemColor(el, 0), color2: o.color2 ?? elemColor(el, 2), dur: o.dur ?? 0.26 }, 0.26);
    if (!f) return;
    f.data.push(rand(0, TAU), rand(0.8, 1.3));
    const n = Math.round((o.scale && o.scale > 1.4 ? 22 : 12) * this.budget);
    if (el === 'water') {
      this.ps.emit({ kind: 'drop', x, y, z, count: n, speed: [140, 520], life: [0.2, 0.6], size: [3, 8], color: '#7fe9ff', color2: '#eafcff', grav: 900, additive: true });
    } else if (el === 'wind') {
      this.ps.emit({ kind: 'feather', x, y, z, count: n, speed: [100, 420], vz: [40, 220], life: [0.4, 1], size: [4, 10], color: '#eaf6ff', color2: '#9fe8ff', grav: 120, drag: 1.6 });
    } else if (el === 'rock') {
      this.ps.emit({ kind: 'debris', x, y, z, count: n, speed: [120, 460], vz: [120, 460], life: [0.4, 0.9], size: [3, 9], color: '#c8a878', color2: '#8a6a3a', grav: 1400, drag: 0.5 });
    } else if (el === 'fox') {
      this.ps.emit({ kind: 'star', x, y, z, count: n, speed: [80, 360], life: [0.3, 0.8], size: [4, 11], color: '#c9a0ff', color2: '#7fd4ff', grav: -40, additive: true });
    } else if (el === 'iron') {
      this.ps.emit({ kind: 'spark', x, y, z, count: n, speed: [200, 620], life: [0.15, 0.4], size: [2, 5], color: '#ffffff', color2: '#ffc93c', grav: 700, additive: true });
    } else {
      this.ps.emit({ kind: 'ember', x, y, z, count: n, speed: [120, 520], vz: [60, 300], life: [0.25, 0.7], size: [3, 9], color: '#ffb03a', color2: '#ff2d40', grav: 320, additive: true });
    }
  }

  /** 高速拖尾線條 */
  streak(x: number, y: number, z: number, x2: number, y2: number, z2: number, o: FxOpts = {}) {
    this.make('streak', { ...o, x, y, z, x2, y2, z2, dur: o.dur ?? 0.35 }, 0.35);
  }

  /** 依 MoveEvent 的 FxId 派發 */
  spawn(id: FxId, x: number, y: number, z: number, o: FxOpts = {}) {
    const scale = o.scale ?? 1;
    switch (id) {
      case 'slashFlame': return this.slash(x, y, z, { ...o, elem: 'flame' });
      case 'slashWater': return this.slash(x, y, z, { ...o, elem: 'water' });
      case 'slashWind': return this.slash(x, y, z, { ...o, elem: 'wind' });
      case 'slashRock': return this.slash(x, y, z, { ...o, elem: 'rock' });
      case 'slashFox': return this.slash(x, y, z, { ...o, elem: 'fox' });
      case 'slashIron': return this.slash(x, y, z, { ...o, elem: 'iron' });
      case 'impactFlame': return this.impact(x, y, z, { ...o, elem: 'flame' });
      case 'impactWater': return this.impact(x, y, z, { ...o, elem: 'water' });
      case 'impactWind': return this.impact(x, y, z, { ...o, elem: 'wind' });
      case 'impactRock': return this.impact(x, y, z, { ...o, elem: 'rock' });
      case 'impactFox': return this.impact(x, y, z, { ...o, elem: 'fox' });
      case 'impactIron': return this.impact(x, y, z, { ...o, elem: 'iron' });
      case 'shockRing': return this.ring(x, y, z, { ...o, w: 260 * scale, h: 78 * scale });
      case 'groundCrack': return this.crack(x, y, { ...o, scale });
      case 'dustPuff': return this.dust(x, y, { ...o, w: 70 * scale });
      case 'jumpDust': return this.dust(x, y, { ...o, w: 46 * scale, dur: 0.4 });
      case 'dashGhost': return this.ghost(x, y, z, { ...o });
      case 'chargeAura': return this.aura(x, y, z, { ...o, w: 100 * scale, h: 150 * scale });
      case 'beamFire': return this.beam(x, y, z, o.x2 ?? x + 900 * (o.dir ?? 1), y, o.z2 ?? z, { ...o, elem: 'flame', w: 34 * scale });
      case 'beamWater': return this.beam(x, y, z, o.x2 ?? x + 900 * (o.dir ?? 1), y, o.z2 ?? z, { ...o, elem: 'water', w: 30 * scale });
      case 'beamHoly': return this.beam(x, y, z, o.x2 ?? x + 900 * (o.dir ?? 1), y, o.z2 ?? z, { ...o, elem: 'holy', w: 40 * scale });
      case 'lightning': return this.bolt(x, y, z, { ...o, h: 520 * scale });
      case 'inkSplat': return this.splat(x, y, { ...o });
    }
  }

  update(dt: number) {
    const arr = this.pool.active;
    for (let i = arr.length - 1; i >= 0; i--) {
      const f = arr[i];
      f.t += dt;
      if (f.kind === 'aura') {
        const p = f.t / f.dur;
        this.ps.emit({
          kind: 'ember', x: f.x + rand(-f.w * 0.5, f.w * 0.5), y: f.y + rand(-14, 14), z: rand(0, f.h * 0.6),
          count: Math.max(1, Math.round(2 * this.budget)), speed: [10, 50], vz: [180, 420],
          life: [0.25, 0.6], size: [3, 8], color: f.color, color2: f.color2, grav: -60, additive: true, drag: 1.2,
        });
        void p;
      }
      if (f.t >= f.dur) { swapRemove(arr, i); this.pool.release(f); }
    }
  }

  clear() { this.pool.releaseAll(); }
  get size() { return this.pool.size; }
}

/* ============================ 畫面效果 ============================ */
export interface Flash { color: string; a: number; dur: number; t: number }

export class ScreenFx {
  shakeTrauma = 0;
  shakeX = 0; shakeY = 0; shakeRot = 0;
  hitstop = 0;
  timeScale = 1;
  timeScaleTarget = 1;
  timeScaleReturn = 0;
  chromatic = 0;
  vignette = 0;
  zoomPunch = 0;
  bars = 0; // 電影黑邊 0~1
  flashes: Flash[] = [];
  wipe = 0; // 轉場 0~1（>0 表示正在轉場）
  wipeDir: 1 | -1 = 1;
  wipeCb: (() => void) | null = null;
  wipeColor = '#0a0610';
  radial = 0; // 径向模糊強度
  killFlash = 0;
  shakeMul = 1;

  setShakeMul(m: number) { this.shakeMul = clamp(m, 0, 1.5); }

  shake(amount: number) {
    this.shakeTrauma = clamp(this.shakeTrauma + amount / 40, 0, 1.4);
  }
  flash(color = '#ffffff', alpha = 0.5, dur = 0.2) {
    this.flashes.push({ color, a: alpha, dur, t: 0 });
    if (this.flashes.length > 8) this.flashes.shift();
  }
  hitStop(sec: number) { this.hitstop = Math.max(this.hitstop, sec); }
  slowmo(scale: number, dur: number) {
    this.timeScaleTarget = scale;
    this.timeScaleReturn = dur;
  }
  punch(zoom: number) { this.zoomPunch = Math.max(this.zoomPunch, zoom); }
  doWipe(cb: () => void, color = '#0a0610') {
    this.wipe = 0.0001; this.wipeDir = 1; this.wipeCb = cb; this.wipeColor = color;
  }

  update(dt: number) {
    // 震動：trauma 平方衰減，產生自然的抖動曲線
    if (this.shakeTrauma > 0) {
      this.shakeTrauma = Math.max(0, this.shakeTrauma - dt * 1.9);
      const s = this.shakeTrauma * this.shakeTrauma * 34 * this.shakeMul;
      const t = performance.now() / 1000;
      this.shakeX = Math.sin(t * 61) * s + Math.sin(t * 113) * s * 0.5;
      this.shakeY = Math.cos(t * 47) * s * 0.8 + Math.sin(t * 97) * s * 0.3;
      this.shakeRot = Math.sin(t * 39) * this.shakeTrauma * 0.012 * this.shakeMul;
    } else { this.shakeX = this.shakeY = this.shakeRot = 0; }

    if (this.hitstop > 0) this.hitstop = Math.max(0, this.hitstop - dt);

    if (this.timeScaleReturn > 0) {
      this.timeScaleReturn -= dt;
      this.timeScale = lerp(this.timeScale, this.timeScaleTarget, 1 - Math.exp(-24 * dt));
      if (this.timeScaleReturn <= 0) this.timeScaleTarget = 1;
    } else {
      this.timeScale = lerp(this.timeScale, 1, 1 - Math.exp(-6 * dt));
    }

    this.chromatic = Math.max(0, this.chromatic - dt * 3.2);
    this.vignette = Math.max(0, this.vignette - dt * 1.6);
    this.zoomPunch = lerp(this.zoomPunch, 0, 1 - Math.exp(-9 * dt));
    this.radial = Math.max(0, this.radial - dt * 1.4);
    this.killFlash = Math.max(0, this.killFlash - dt * 3);

    for (let i = this.flashes.length - 1; i >= 0; i--) {
      const f = this.flashes[i];
      f.t += dt;
      if (f.t >= f.dur) this.flashes.splice(i, 1);
    }

    if (this.wipe > 0) {
      const speed = 2.6;
      if (this.wipeDir === 1) {
        this.wipe = Math.min(1, this.wipe + dt * speed);
        if (this.wipe >= 1) { this.wipeDir = -1; this.wipeCb?.(); this.wipeCb = null; }
      } else {
        this.wipe = Math.max(0, this.wipe - dt * speed);
      }
    }
    void Ease;
  }

  /** 每幀的時間縮放（hitstop 時為 0） */
  get dtScale() {
    return this.hitstop > 0 ? 0 : this.timeScale;
  }
}
