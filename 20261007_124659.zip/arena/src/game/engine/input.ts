/**
 * 輸入系統：鍵盤 / 滑鼠 / 觸控 / 手把 統一抽象
 * ------------------------------------------------------------------
 * 以「動作」為單位（attack / heavy / jump / dash / skillA / skillB / ult ...），
 * UI 層只需回報 touch 軸與按鈕狀態，引擎不需知道輸入來源。
 * 支援輸入緩衝（buffer），讓連段手感更順。
 */
export type Action =
  | 'up' | 'down' | 'left' | 'right'
  | 'attack' | 'heavy' | 'jump' | 'dash'
  | 'skillA' | 'skillB' | 'ult' | 'pause' | 'confirm' | 'cancel';

const KEYMAP: Record<string, Action> = {
  KeyW: 'up', ArrowUp: 'up',
  KeyS: 'down', ArrowDown: 'down',
  KeyA: 'left', ArrowLeft: 'left',
  KeyD: 'right', ArrowRight: 'right',
  KeyJ: 'attack', Space: 'attack', Numpad1: 'attack',
  KeyK: 'jump', Numpad2: 'jump',
  KeyL: 'heavy', Numpad3: 'heavy',
  ShiftLeft: 'dash', ShiftRight: 'dash', Semicolon: 'dash', Numpad4: 'dash',
  KeyU: 'skillA', Numpad5: 'skillA', Digit1: 'skillA',
  KeyI: 'skillB', Numpad6: 'skillB', Digit2: 'skillB',
  KeyO: 'ult', Numpad7: 'ult', Digit3: 'ult',
  Escape: 'pause', KeyP: 'pause',
  Enter: 'confirm', NumpadEnter: 'confirm',
  Backspace: 'cancel',
};

const PAD_MAP: Record<number, Action> = {
  0: 'attack', 1: 'jump', 2: 'dash', 3: 'heavy',
  4: 'skillA', 5: 'skillB', 6: 'ult', 7: 'ult',
  9: 'pause', 12: 'up', 13: 'down', 14: 'left', 15: 'right',
};

export interface TouchButton { id: Action; down: boolean }

export class Input {
  private held = new Set<Action>();
  private pressedBuf = new Map<Action, number>(); // 動作 → 剩餘緩衝時間
  private released = new Set<Action>();
  private prev = new Set<Action>();
  touchAxis = { x: 0, y: 0 };
  touchActive = false;
  mouseAim: { x: number; y: number } | null = null;
  private bufferTime = 0.22;

  attach(el: HTMLElement) {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    el.addEventListener('mousedown', this.onMouseDown);
    el.addEventListener('mouseup', this.onMouseUp);
    el.addEventListener('contextmenu', this.onCtx);
    el.addEventListener('mousemove', this.onMouseMove);
  }

  detach(el: HTMLElement) {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    el.removeEventListener('mousedown', this.onMouseDown);
    el.removeEventListener('mouseup', this.onMouseUp);
    el.removeEventListener('contextmenu', this.onCtx);
    el.removeEventListener('mousemove', this.onMouseMove);
  }

  private onCtx = (e: Event) => e.preventDefault();
  private onBlur = () => { this.held.clear(); this.touchAxis.x = this.touchAxis.y = 0; };

  private onKeyDown = (e: KeyboardEvent) => {
    const a = KEYMAP[e.code];
    if (!a) return;
    if (a === 'pause' || a === 'confirm' || a === 'cancel' || a.startsWith('up') || a.startsWith('down')) e.preventDefault();
    if (e.repeat) return;
    this.setDown(a);
  };
  private onKeyUp = (e: KeyboardEvent) => {
    const a = KEYMAP[e.code];
    if (!a) return;
    this.setUp(a);
  };
  private onMouseDown = (e: MouseEvent) => {
    if (e.button === 0) this.setDown('attack');
    if (e.button === 2) this.setDown('heavy');
    if (e.button === 1) this.setDown('dash');
  };
  private onMouseUp = (e: MouseEvent) => {
    if (e.button === 0) this.setUp('attack');
    if (e.button === 2) this.setUp('heavy');
    if (e.button === 1) this.setUp('dash');
  };
  private onMouseMove = (e: MouseEvent) => {
    this.mouseAim = { x: e.clientX, y: e.clientY };
  };

  setDown(a: Action) {
    if (!this.held.has(a)) this.pressedBuf.set(a, this.bufferTime);
    this.held.add(a);
  }
  setUp(a: Action) {
    if (this.held.has(a)) this.released.add(a);
    this.held.delete(a);
  }

  /** 觸控 UI 呼叫 */
  setTouch(id: Action, down: boolean) {
    if (down) this.setDown(id); else this.setUp(id);
  }
  setAxis(x: number, y: number) {
    this.touchAxis.x = x;
    this.touchAxis.y = y;
    this.touchActive = Math.hypot(x, y) > 0.08;
  }

  /** 手把輪詢 */
  pollGamepad() {
    if (!navigator.getGamepads) return;
    const pads = navigator.getGamepads();
    for (const p of pads) {
      if (!p) continue;
      const dead = 0.28;
      let ax = p.axes[0] ?? 0, ay = p.axes[1] ?? 0;
      if (Math.abs(ax) < dead) ax = 0;
      if (Math.abs(ay) < dead) ay = 0;
      if (ax || ay) {
        this.touchAxis.x = ax; this.touchAxis.y = ay; this.touchActive = true;
      }
      for (const [idx, act] of Object.entries(PAD_MAP)) {
        const b = p.buttons[Number(idx)];
        if (!b) continue;
        if (b.pressed) this.setDown(act); else this.setUp(act);
      }
      break;
    }
  }

  /** 每幀末呼叫：清除邊緣觸發 */
  endFrame(dt: number) {
    for (const [k, v] of this.pressedBuf) {
      const nv = v - dt;
      if (nv <= 0) this.pressedBuf.delete(k);
      else this.pressedBuf.set(k, nv);
    }
    this.prev = new Set(this.held);
    this.released.clear();
  }

  down(a: Action) { return this.held.has(a); }
  /** 有緩衝的按下判定（消耗掉） */
  press(a: Action) {
    if (this.pressedBuf.has(a)) { this.pressedBuf.delete(a); return true; }
    return false;
  }
  wasReleased(a: Action) { return this.released.has(a); }
  axis() {
    let x = (this.down('right') ? 1 : 0) - (this.down('left') ? 1 : 0);
    let y = (this.down('down') ? 1 : 0) - (this.down('up') ? 1 : 0);
    if (this.touchActive) { x = this.touchAxis.x; y = this.touchAxis.y; }
    const m = Math.hypot(x, y);
    if (m > 1) { x /= m; y /= m; }
    return { x, y, mag: Math.min(1, m) };
  }
  clearAll() { this.held.clear(); this.pressedBuf.clear(); this.released.clear(); this.touchAxis.x = this.touchAxis.y = 0; this.touchActive = false; void this.prev; }
}
