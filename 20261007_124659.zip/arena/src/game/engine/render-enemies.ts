/**
 * 敵兵繪製
 * ------------------------------------------------------------------
 * 每一種部隊都有完全獨立的外型、動作與死亡表現，不共用任何造型：
 *   青皮嘍囉／紅纓骷槍／狼影忍／黃袍術士／爆焰甲蟲／石甲巨鬼／
 *   妖弓手／獄炎犬／咒旗巫者，以及四位首領（石魈／赤角焰侯／玄霄元帥／燼天）。
 * 攻擊前搖會顯示「殺氣預警」，兼顧華麗與可讀性。
 */
import type { Actor } from './actors';
import type { EnemyDef } from '../core/types';
import { TAU, clamp } from '../core/util';
import { jointLimb, limb, roundRect } from './render-actors';
import { withAlpha } from './render-bg';

interface EPose {
  walk: number; atk: number; wind: number; lean: number; crouch: number; hurt: number; down: number;
}

function enemyPose(a: Actor): EPose {
  const p: EPose = { walk: 0, atk: 0, wind: 0, lean: 0, crouch: 0, hurt: 0, down: 0 };
  const sp = (a.def?.speed ?? 150) / 150;
  switch (a.state) {
    case 'run': p.walk = Math.sin(a.animT * 11 * sp); p.lean = 0.16; break;
    case 'idle': p.walk = Math.sin(a.animT * 2.4) * 0.16; break;
    case 'cast': p.wind = clamp(a.aiT > 0 ? 1 - a.aiT / 0.6 : 1, 0, 1); p.crouch = 5; p.lean = -0.14; break;
    case 'attack': p.atk = a.move ? clamp(a.moveT / a.move.duration, 0, 1) : 0; p.lean = 0.2; break;
    case 'hurt': p.hurt = clamp(1 - a.stateT / 0.4, 0, 1); p.lean = -0.34 * p.hurt; break;
    case 'down': p.down = clamp(1 - a.stateT / 0.3, 0, 1); break;
    case 'dead': p.down = 1; break;
    case 'spawn': p.crouch = 10; break;
    case 'fall': case 'jump': p.lean = 0.1; p.walk = 0.4; break;
    default: break;
  }
  return p;
}

const INK = '#100810';

export function drawEnemy(ctx: CanvasRenderingContext2D, a: Actor, sx: number, sy: number, t: number, quality: number) {
  const def = a.def;
  if (!def) return;
  const p = enemyPose(a);
  const S = a.scale * (1 + a.y * 0.0016);
  const flash = a.flashT > 0;
  const C = {
    body: flash ? '#ffffff' : def.colors.body,
    trim: flash ? '#ffffff' : def.colors.trim,
    skin: flash ? '#ffffff' : def.colors.skin,
    aura: def.colors.aura,
    metal: flash ? '#ffffff' : def.colors.metal,
  };
  const deadFade = a.dead ? clamp(1 - a.deadT / 0.5, 0, 1) : 1;

  ctx.save();
  ctx.globalAlpha = deadFade;
  ctx.translate(sx, sy);
  if (a.dead || p.down > 0.5) {
    ctx.rotate(-1.4 * (a.facing > 0 ? 1 : -1) * (a.dead ? 1 : p.down));
    ctx.translate(0, a.dead ? 6 : 0);
  }
  ctx.scale(a.facing * S, S);
  ctx.rotate(p.lean * 0.5);
  ctx.translate(0, p.crouch);

  const H = def.height;
  const hipY = -H * 0.44 + p.walk * 2;
  const chestY = -H * 0.72 + p.walk * 2;
  const headY = -H * 0.9;

  switch (def.id) {
    case 'imp': drawImp(ctx, p, C, t, hipY, chestY, headY, H, quality); break;
    case 'spear': drawSpear(ctx, p, C, t, hipY, chestY, headY, H, quality, a); break;
    case 'ninja': drawNinja(ctx, p, C, t, hipY, chestY, headY, H, quality); break;
    case 'caster': drawCaster(ctx, p, C, t, hipY, chestY, headY, H, quality); break;
    case 'bomber': drawBomber(ctx, p, C, t, H, quality, a); break;
    case 'brute': drawBrute(ctx, p, C, t, hipY, chestY, headY, H, quality); break;
    case 'archer': drawArcher(ctx, p, C, t, hipY, chestY, headY, H, quality); break;
    case 'hound': drawHound(ctx, p, C, t, H, quality); break;
    case 'shaman': drawShaman(ctx, p, C, t, hipY, chestY, headY, H, quality); break;
    case 'boss_shixiao': drawBossShixiao(ctx, p, C, t, hipY, chestY, headY, H, quality); break;
    case 'boss_chijiao': drawBossChijiao(ctx, p, C, t, hipY, chestY, headY, H, quality); break;
    case 'boss_xuanxiao': drawBossXuanxiao(ctx, p, C, t, hipY, chestY, headY, H, quality); break;
    case 'boss_jintian': drawBossJintian(ctx, p, C, t, hipY, chestY, headY, H, quality); break;
    default:
      if (def.id.endsWith('_elite')) drawElite(ctx, def, p, C, t, hipY, chestY, headY, H, quality);
      else drawImp(ctx, p, C, t, hipY, chestY, headY, H, quality);
      break;
  }
  ctx.restore();

  // 菁英／首領氣場
  if ((a.elite || def.rank === '首領') && !a.dead && quality > 0.3) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const pulse = 0.35 + 0.2 * Math.sin(t * 3 + a.uid);
    const g = ctx.createRadialGradient(sx, sy - H * S * 0.5, 6, sx, sy - H * S * 0.5, H * S * 1.1);
    g.addColorStop(0, withAlpha(def.colors.aura, pulse * 0.5));
    g.addColorStop(1, withAlpha(def.colors.aura, 0));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.ellipse(sx, sy - H * S * 0.5, H * S * 1.1, H * S * 0.8, 0, 0, TAU); ctx.fill();
    ctx.restore();
  }
  // 異常狀態視覺
  const st = a.status;
  if (st.length && !a.dead) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    if (st.some((s) => s.kind === 'burn')) {
      ctx.globalAlpha = 0.4 + 0.2 * Math.sin(t * 14);
      ctx.fillStyle = '#ff6a1a';
      ctx.beginPath(); ctx.ellipse(sx, sy - H * S * 0.5, def.radius * S * 1.2, H * S * 0.6, 0, 0, TAU); ctx.fill();
    }
    if (st.some((s) => s.kind === 'freeze')) {
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = '#9fe8ff';
      ctx.beginPath(); ctx.ellipse(sx, sy - H * S * 0.5, def.radius * S * 1.3, H * S * 0.66, 0, 0, TAU); ctx.fill();
    }
    if (st.some((s) => s.kind === 'stun')) {
      ctx.globalAlpha = 0.9;
      for (let i = 0; i < 3; i++) {
        const ang = t * 5 + (i / 3) * TAU;
        ctx.fillStyle = '#ffe6a8';
        ctx.beginPath();
        ctx.arc(sx + Math.cos(ang) * 26, sy - H * S - 14 + Math.sin(ang) * 8, 4, 0, TAU);
        ctx.fill();
      }
    }
    ctx.restore();
  }
}

type Cols = { body: string; trim: string; skin: string; aura: string; metal: string };

/* ============================ 青皮嘍囉 ============================ */
function drawImp(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const swing = p.atk > 0 ? Math.sin(clamp((p.atk - 0.3) / 0.3, 0, 1) * Math.PI) : 0;
  jointLimb(ctx, -6, hipY, 1.55 + p.walk * 0.6, H * 0.22, Math.max(0, -p.walk) * 0.7, H * 0.2, 9, C.skin, INK);
  jointLimb(ctx, 6, hipY, 1.55 - p.walk * 0.6, H * 0.22, Math.max(0, p.walk) * 0.7, H * 0.2, 9, C.skin, INK);
  // 腰布
  ctx.fillStyle = C.trim;
  ctx.beginPath(); ctx.moveTo(-13, hipY - 4); ctx.lineTo(13, hipY - 4); ctx.lineTo(10, hipY + 20); ctx.lineTo(-10, hipY + 20); ctx.closePath(); ctx.fill();
  // 軀幹
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(0, (hipY + chestY) / 2, 17, 24, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath(); ctx.ellipse(0, (hipY + chestY) / 2, 14.5, 21, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = withAlpha(C.skin, 0.6);
  ctx.beginPath(); ctx.ellipse(4, (hipY + chestY) / 2 - 4, 7, 11, 0, 0, TAU); ctx.fill();
  // 手臂＋木棒
  const hand = jointLimb(ctx, 12, chestY + 4, 1.9 - swing * 2.2 - p.wind * 1.2, H * 0.2, 0.5 + swing, H * 0.18, 8, C.skin, INK);
  ctx.save();
  ctx.translate(hand.ex, hand.ey);
  ctx.rotate(-0.5 + swing * 2.4 + p.wind * 1.4);
  ctx.strokeStyle = INK; ctx.lineWidth = 11; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(-6, 12); ctx.lineTo(10, -38); ctx.stroke();
  ctx.strokeStyle = '#8a6a3a'; ctx.lineWidth = 7;
  ctx.beginPath(); ctx.moveTo(-6, 12); ctx.lineTo(10, -38); ctx.stroke();
  ctx.fillStyle = '#6a4a2a';
  ctx.beginPath(); ctx.ellipse(11, -40, 9, 12, 0.3, 0, TAU); ctx.fill();
  ctx.restore();
  jointLimb(ctx, -12, chestY + 4, 1.4 + p.walk * 0.4, H * 0.18, 0.5, H * 0.16, 8, C.skin, INK);
  // 頭（大耳）
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(2, headY, 17, 0, TAU); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.arc(2, headY, 14.5, 0, TAU); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath(); ctx.moveTo(-12, headY - 6); ctx.lineTo(-30, headY - 20); ctx.lineTo(-10, headY + 4); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(14, headY - 6); ctx.lineTo(30, headY - 18); ctx.lineTo(12, headY + 4); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#ffe08a';
  ctx.beginPath(); ctx.ellipse(8, headY - 1, 4.2, 3, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(9, headY - 1, 1.8, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.moveTo(2, headY + 7); ctx.lineTo(12, headY + 5); ctx.lineTo(11, headY + 9); ctx.closePath(); ctx.fill();
  if (q > 0.5 && p.wind > 0.2) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = withAlpha(C.aura, p.wind * 0.5);
    ctx.beginPath(); ctx.arc(2, headY, 26 * p.wind, 0, TAU); ctx.fill();
    ctx.restore();
  }
  void t;
}

/* ============================ 紅纓骷槍 ============================ */
function drawSpear(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number, a: Actor) {
  const thrust = p.atk > 0 ? Math.sin(clamp((p.atk - 0.32) / 0.26, 0, 1) * Math.PI) : 0;
  // 骨腿
  jointLimb(ctx, -6, hipY, 1.55 + p.walk * 0.5, H * 0.24, 0.1, H * 0.22, 7, '#e8e2d0', INK);
  jointLimb(ctx, 6, hipY, 1.55 - p.walk * 0.5, H * 0.24, 0.1, H * 0.22, 7, '#d8d2c0', INK);
  // 骨盆＋肋骨
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(0, hipY - 2, 15, 12, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#e8e2d0';
  ctx.beginPath(); ctx.ellipse(0, hipY - 2, 12.5, 9.5, 0, 0, TAU); ctx.fill();
  ctx.strokeStyle = INK; ctx.lineWidth = 9;
  ctx.beginPath(); ctx.moveTo(0, hipY - 6); ctx.lineTo(0, chestY + 4); ctx.stroke();
  ctx.strokeStyle = '#efe9d8'; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.moveTo(0, hipY - 6); ctx.lineTo(0, chestY + 4); ctx.stroke();
  for (let i = 0; i < 4; i++) {
    const yy = chestY + 8 + i * 8;
    ctx.strokeStyle = INK; ctx.lineWidth = 6;
    ctx.beginPath(); ctx.moveTo(-14, yy); ctx.quadraticCurveTo(0, yy + 6, 14, yy); ctx.stroke();
    ctx.strokeStyle = '#efe9d8'; ctx.lineWidth = 3.4;
    ctx.beginPath(); ctx.moveTo(-13, yy); ctx.quadraticCurveTo(0, yy + 5, 13, yy); ctx.stroke();
  }
  // 肩甲
  ctx.fillStyle = '#9fb0c0';
  ctx.beginPath(); ctx.ellipse(-15, chestY + 4, 10, 7, -0.3, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(15, chestY + 4, 10, 7, 0.3, 0, TAU); ctx.fill();
  // 槍
  ctx.save();
  ctx.translate(14, chestY + 12);
  ctx.rotate(-0.16 - p.wind * 0.4 + thrust * 0.2);
  ctx.translate(thrust * 34, 0);
  ctx.strokeStyle = INK; ctx.lineWidth = 8;
  ctx.beginPath(); ctx.moveTo(-52, 22); ctx.lineTo(62, -14); ctx.stroke();
  ctx.strokeStyle = '#7a5a3a'; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.moveTo(-52, 22); ctx.lineTo(62, -14); ctx.stroke();
  // 紅纓
  ctx.fillStyle = C.trim;
  for (let i = 0; i < 6; i++) {
    const sw = Math.sin(t * 6 + i) * 5;
    ctx.beginPath();
    ctx.moveTo(44, -8);
    ctx.quadraticCurveTo(38 + sw, 2 + i * 2, 30 + sw, 12 + i * 3);
    ctx.lineTo(36 + sw, 12 + i * 3);
    ctx.quadraticCurveTo(42, 2, 47, -7);
    ctx.closePath(); ctx.fill();
  }
  // 槍頭
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.moveTo(60, -14); ctx.lineTo(88, -22); ctx.lineTo(64, -4); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#dfe8f0';
  ctx.beginPath(); ctx.moveTo(62, -14); ctx.lineTo(85, -21); ctx.lineTo(65, -6); ctx.closePath(); ctx.fill();
  ctx.restore();
  jointLimb(ctx, -14, chestY + 6, 1.7 + p.walk * 0.3, H * 0.19, 0.5, H * 0.17, 6, '#d8d2c0', INK);
  // 頭骨＋盔
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(2, headY, 15, 0, TAU); ctx.fill();
  ctx.fillStyle = '#f2ecdc';
  ctx.beginPath(); ctx.arc(2, headY, 12.5, 0, TAU); ctx.fill();
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(7, headY - 1, 4, 4.6, 0, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(-2, headY - 1, 3.4, 4.2, 0, 0, TAU); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = withAlpha(C.aura, 0.75 + 0.25 * Math.sin(t * 5));
  ctx.beginPath(); ctx.ellipse(7, headY - 1, 2, 2.4, 0, 0, TAU); ctx.fill();
  ctx.restore();
  ctx.fillStyle = '#9fb0c0';
  ctx.beginPath(); ctx.moveTo(-14, headY - 6); ctx.quadraticCurveTo(2, headY - 26, 18, headY - 6); ctx.lineTo(18, headY - 2); ctx.lineTo(-14, headY - 2); ctx.closePath(); ctx.fill();
  ctx.fillStyle = C.trim;
  ctx.beginPath(); ctx.moveTo(0, headY - 24); ctx.quadraticCurveTo(10 + Math.sin(t * 4) * 6, headY - 40, 4, headY - 48); ctx.lineTo(-2, headY - 34); ctx.closePath(); ctx.fill();
  if (q > 0.5 && p.wind > 0.2) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = withAlpha(C.aura, p.wind * 0.7); ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(30, chestY); ctx.lineTo(110, chestY - 12); ctx.stroke();
    ctx.restore();
  }
  void a;
}

/* ============================ 狼影忍 ============================ */
function drawNinja(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const slash = p.atk > 0 ? Math.sin(clamp((p.atk - 0.22) / 0.3, 0, 1) * Math.PI) : 0;
  jointLimb(ctx, -6, hipY, 1.5 + p.walk * 0.85, H * 0.2, Math.max(0, -p.walk) * 0.9, H * 0.19, 8, C.body, INK);
  jointLimb(ctx, 6, hipY, 1.5 - p.walk * 0.85, H * 0.2, Math.max(0, p.walk) * 0.9, H * 0.19, 8, C.body, INK);
  //  scarf
  ctx.save();
  const sw = Math.sin(t * 7) * 10 - (p.walk * 16);
  ctx.fillStyle = C.trim;
  ctx.beginPath();
  ctx.moveTo(-8, chestY + 2);
  ctx.quadraticCurveTo(-40 + sw, chestY + 6, -56 + sw * 1.4, chestY + 30);
  ctx.lineTo(-46 + sw * 1.3, chestY + 36);
  ctx.quadraticCurveTo(-30 + sw, chestY + 16, -6, chestY + 12);
  ctx.closePath(); ctx.fill();
  ctx.restore();
  // 軀幹（精瘦）
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(0, (hipY + chestY) / 2, 14, 22, 0.06, 0, TAU); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath(); ctx.ellipse(0, (hipY + chestY) / 2, 11.5, 19, 0.06, 0, TAU); ctx.fill();
  ctx.strokeStyle = withAlpha(C.trim, 0.8); ctx.lineWidth = 2.4;
  ctx.beginPath(); ctx.moveTo(-9, chestY + 6); ctx.lineTo(9, hipY - 6); ctx.stroke();
  // 雙刀
  for (const s of [1, -1]) {
    ctx.save();
    ctx.translate(s > 0 ? 12 : -12, chestY + 10);
    ctx.rotate((s > 0 ? -0.5 - slash * 2.4 - p.wind * 1.2 : 0.7 + slash * 1.2));
    ctx.strokeStyle = INK; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(s > 0 ? 34 : -30, s > 0 ? -18 : 20); ctx.stroke();
    ctx.strokeStyle = '#dfe8f8'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(s > 0 ? 34 : -30, s > 0 ? -18 : 20); ctx.stroke();
    ctx.restore();
  }
  jointLimb(ctx, 12, chestY + 4, 1.8 - slash * 2.2, H * 0.17, 0.5 + slash, H * 0.16, 7, C.skin, INK);
  jointLimb(ctx, -12, chestY + 4, 1.5 + slash * 1.4, H * 0.17, 0.5, H * 0.16, 7, C.skin, INK);
  // 狼頭
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(2, headY, 15, 13, 0.1, 0, TAU); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.ellipse(2, headY, 12.5, 11, 0.1, 0, TAU); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath(); ctx.moveTo(8, headY); ctx.lineTo(30, headY + 5); ctx.lineTo(8, headY + 9); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.moveTo(20, headY + 4); ctx.lineTo(24, headY + 8); ctx.lineTo(18, headY + 7); ctx.closePath(); ctx.fill();
  // 耳
  ctx.fillStyle = C.body;
  ctx.beginPath(); ctx.moveTo(-6, headY - 8); ctx.lineTo(-12, headY - 26); ctx.lineTo(2, headY - 12); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(6, headY - 9); ctx.lineTo(10, headY - 27); ctx.lineTo(14, headY - 10); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = withAlpha(C.aura, 0.9);
  ctx.beginPath(); ctx.ellipse(8, headY - 3, 4, 2.4, -0.2, 0, TAU); ctx.fill();
  ctx.restore();
  if (q > 0.5 && (p.wind > 0.2 || slash > 0.1)) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = withAlpha(C.aura, 0.55); ctx.lineWidth = 3;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(16, chestY - 8 + i * 9);
      ctx.lineTo(70, chestY - 20 + i * 12);
      ctx.stroke();
    }
    ctx.restore();
  }
}

/* ============================ 黃袍術士 ============================ */
function drawCaster(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const float = Math.sin(t * 2.2) * 6;
  ctx.save();
  ctx.translate(0, float);
  // 長袍（無腿，下擺飄動）
  ctx.fillStyle = INK;
  ctx.beginPath();
  ctx.moveTo(-20, chestY);
  ctx.quadraticCurveTo(-30, hipY + 20, -18 + Math.sin(t * 3) * 8, hipY + 46);
  ctx.quadraticCurveTo(0, hipY + 34, 18 + Math.sin(t * 3 + 1) * 8, hipY + 46);
  ctx.quadraticCurveTo(30, hipY + 20, 20, chestY);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath();
  ctx.moveTo(-17, chestY + 2);
  ctx.quadraticCurveTo(-26, hipY + 18, -15 + Math.sin(t * 3) * 7, hipY + 42);
  ctx.quadraticCurveTo(0, hipY + 31, 15 + Math.sin(t * 3 + 1) * 7, hipY + 42);
  ctx.quadraticCurveTo(26, hipY + 18, 17, chestY + 2);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = C.trim;
  ctx.fillRect(-17, chestY + 22, 34, 7);
  // 袖
  const cast = p.wind * 0.8 + (p.atk > 0 ? Math.sin(clamp((p.atk - 0.3) / 0.3, 0, 1) * Math.PI) : 0);
  jointLimb(ctx, 14, chestY + 6, 1.5 - cast * 1.6, H * 0.18, 0.4 + cast, H * 0.16, 10, C.body, INK);
  jointLimb(ctx, -14, chestY + 6, 1.7 - cast * 0.6, H * 0.18, 0.5, H * 0.16, 10, C.body, INK);
  // 杖
  ctx.save();
  ctx.translate(24, chestY + 20);
  ctx.rotate(-0.2 - cast * 0.5);
  ctx.strokeStyle = INK; ctx.lineWidth = 8;
  ctx.beginPath(); ctx.moveTo(0, 34); ctx.lineTo(0, -48); ctx.stroke();
  ctx.strokeStyle = '#8a5a1a'; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.moveTo(0, 34); ctx.lineTo(0, -48); ctx.stroke();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  const gg = ctx.createRadialGradient(0, -54, 2, 0, -54, 22 + cast * 16);
  gg.addColorStop(0, 'rgba(255,255,240,0.95)');
  gg.addColorStop(0.4, withAlpha(C.aura, 0.7));
  gg.addColorStop(1, withAlpha(C.aura, 0));
  ctx.fillStyle = gg;
  ctx.beginPath(); ctx.arc(0, -54, 22 + cast * 16, 0, TAU); ctx.fill();
  ctx.restore();
  ctx.restore();
  // 頭（蒼白＋高帽）
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(2, headY, 14, 0, TAU); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.arc(2, headY, 11.5, 0, TAU); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath(); ctx.moveTo(-12, headY - 4); ctx.quadraticCurveTo(2, headY - 34, 16, headY - 4); ctx.closePath(); ctx.fill();
  ctx.fillStyle = C.trim;
  ctx.fillRect(-13, headY - 8, 30, 5);
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(7, headY + 1, 3, 4, 0, 0, TAU); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = withAlpha(C.aura, 0.8);
  ctx.beginPath(); ctx.arc(7, headY + 1, 1.6, 0, TAU); ctx.fill();
  ctx.restore();
  // 環繞符文
  if (q > 0.4) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 3; i++) {
      const a2 = t * 1.8 + (i / 3) * TAU;
      const rx = Math.cos(a2) * 34, ry = chestY + 8 + Math.sin(a2) * 14;
      ctx.globalAlpha = 0.55 + 0.35 * Math.sin(t * 4 + i);
      ctx.fillStyle = C.aura;
      ctx.save(); ctx.translate(rx, ry); ctx.rotate(a2);
      ctx.fillRect(-5, -7, 10, 14);
      ctx.fillStyle = '#8a1a1a';
      ctx.fillRect(-3, -4, 6, 1.6);
      ctx.fillRect(-3, 0, 6, 1.6);
      ctx.restore();
    }
    ctx.restore();
  }
  ctx.restore();
  void hipY;
}

/* ============================ 爆焰甲蟲 ============================ */
function drawBomber(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, H: number, q: number, a: Actor) {
  const pulse = 0.5 + 0.5 * Math.sin(t * (6 + p.wind * 22));
  const charge = clamp((a.aiState === 'windup' ? 1 - a.aiT / 0.42 : 0), 0, 1);
  const bob = Math.sin(t * 9) * 3;
  ctx.save();
  ctx.translate(0, -H * 0.42 + bob);
  // 腿
  ctx.strokeStyle = INK; ctx.lineWidth = 5;
  for (let i = 0; i < 3; i++) {
    const ph = p.walk * 0.8 + i * 0.8;
    ctx.beginPath();
    ctx.moveTo(-14 + i * 12, 12);
    ctx.lineTo(-22 + i * 14 + Math.sin(ph) * 6, 30);
    ctx.stroke();
  }
  // 甲殼
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(0, 0, 32, 25, 0, 0, TAU); ctx.fill();
  const g = ctx.createLinearGradient(-30, -22, 26, 22);
  g.addColorStop(0, '#5a3a24'); g.addColorStop(0.5, C.body); g.addColorStop(1, '#241a12');
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.ellipse(0, 0, 29, 22, 0, 0, TAU); ctx.fill();
  // 熔核裂縫
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = withAlpha('#ff8a3a', 0.4 + pulse * 0.6 + charge * 0.4);
  ctx.lineWidth = 3 + charge * 5;
  ctx.beginPath();
  ctx.moveTo(-22, -6); ctx.lineTo(-6, 2); ctx.lineTo(4, -8); ctx.lineTo(20, 4);
  ctx.stroke();
  const gg = ctx.createRadialGradient(0, 0, 2, 0, 0, 40 + charge * 30);
  gg.addColorStop(0, withAlpha('#ffe08a', 0.35 + charge * 0.5));
  gg.addColorStop(1, withAlpha('#ff3a0a', 0));
  ctx.fillStyle = gg;
  ctx.beginPath(); ctx.arc(0, 0, 40 + charge * 30, 0, TAU); ctx.fill();
  ctx.restore();
  // 小翅膀
  if (q > 0.4) {
    ctx.save();
    ctx.globalAlpha = 0.4;
    ctx.fillStyle = '#d8e8f0';
    const wf = Math.sin(t * 40) * 0.5;
    ctx.beginPath(); ctx.ellipse(-10, -20, 18, 7, -0.5 + wf, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(12, -20, 18, 7, 0.5 - wf, 0, TAU); ctx.fill();
    ctx.restore();
  }
  // 頭＋眼
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(24, -4, 12, 10, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.ellipse(24, -4, 9.5, 8, 0, 0, TAU); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = withAlpha('#ff3a0a', 0.7 + pulse * 0.3);
  ctx.beginPath(); ctx.arc(28, -6, 3, 0, TAU); ctx.fill();
  ctx.restore();
  ctx.restore();
  void C.trim; void p.crouch;
}

/* ============================ 石甲巨鬼 ============================ */
function drawBrute(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const slam = p.atk > 0 ? Math.sin(clamp((p.atk - 0.42) / 0.22, 0, 1) * Math.PI) : 0;
  const charge = p.wind;
  // 粗腿
  jointLimb(ctx, -14, hipY, 1.5 + p.walk * 0.4, H * 0.24, 0.12, H * 0.22, 20, C.body, INK);
  jointLimb(ctx, 14, hipY, 1.5 - p.walk * 0.4, H * 0.24, 0.12, H * 0.22, 20, C.body, INK);
  // 岩板裙
  ctx.fillStyle = INK;
  for (let i = -2; i <= 2; i++) {
    ctx.beginPath();
    ctx.moveTo(i * 16 - 8, hipY - 6); ctx.lineTo(i * 16 + 8, hipY - 6);
    ctx.lineTo(i * 16 + 5, hipY + 28); ctx.lineTo(i * 16 - 5, hipY + 28);
    ctx.closePath(); ctx.fill();
  }
  ctx.fillStyle = C.skin;
  for (let i = -2; i <= 2; i++) {
    ctx.beginPath();
    ctx.moveTo(i * 16 - 6, hipY - 4); ctx.lineTo(i * 16 + 6, hipY - 4);
    ctx.lineTo(i * 16 + 3, hipY + 25); ctx.lineTo(i * 16 - 3, hipY + 25);
    ctx.closePath(); ctx.fill();
  }
  // 巨大軀幹
  ctx.fillStyle = INK;
  roundRect(ctx, -32, chestY - 10, 64, hipY - chestY + 20, 16); ctx.fill();
  const g = ctx.createLinearGradient(-30, chestY, 30, hipY);
  g.addColorStop(0, C.skin); g.addColorStop(0.6, C.body); g.addColorStop(1, '#3a2f24');
  ctx.fillStyle = g;
  roundRect(ctx, -29, chestY - 7, 58, hipY - chestY + 15, 14); ctx.fill();
  // 岩漿裂紋
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = withAlpha(C.aura, 0.5 + 0.3 * Math.sin(t * 2.4));
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-20, chestY + 6); ctx.lineTo(-6, chestY + 22); ctx.lineTo(-14, hipY - 8);
  ctx.moveTo(14, chestY + 4); ctx.lineTo(6, chestY + 26); ctx.lineTo(20, hipY - 6);
  ctx.stroke();
  ctx.restore();
  // 肩岩
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(-34, chestY, 20, 16, -0.3, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(34, chestY, 20, 16, 0.3, 0, TAU); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath(); ctx.ellipse(-34, chestY - 2, 17, 13, -0.3, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(34, chestY - 2, 17, 13, 0.3, 0, TAU); ctx.fill();
  // 巨鎚
  ctx.save();
  ctx.translate(34, chestY + 12);
  ctx.rotate(-1.1 - charge * 1.1 + slam * 2.6);
  ctx.strokeStyle = INK; ctx.lineWidth = 13;
  ctx.beginPath(); ctx.moveTo(0, 10); ctx.lineTo(0, -62); ctx.stroke();
  ctx.strokeStyle = '#6a4a2a'; ctx.lineWidth = 9;
  ctx.beginPath(); ctx.moveTo(0, 10); ctx.lineTo(0, -62); ctx.stroke();
  ctx.fillStyle = INK;
  roundRect(ctx, -26, -92, 52, 40, 8); ctx.fill();
  const hg = ctx.createLinearGradient(-24, -90, 24, -54);
  hg.addColorStop(0, '#8a7a62'); hg.addColorStop(1, '#4a3f30');
  ctx.fillStyle = hg;
  roundRect(ctx, -23, -89, 46, 34, 7); ctx.fill();
  ctx.fillStyle = C.metal;
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(-26 + i * 14, -92); ctx.lineTo(-20 + i * 14, -104); ctx.lineTo(-14 + i * 14, -92);
    ctx.closePath(); ctx.fill();
  }
  ctx.restore();
  jointLimb(ctx, -30, chestY + 6, 1.6 + p.walk * 0.3, H * 0.2, 0.4, H * 0.18, 15, C.body, INK);
  // 頭（小、埋在肩中）
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(2, headY + 8, 16, 0, TAU); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.arc(2, headY + 8, 13, 0, TAU); ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.moveTo(-4, headY + 14); ctx.lineTo(0, headY + 22); ctx.lineTo(4, headY + 14); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(6, headY + 14); ctx.lineTo(10, headY + 21); ctx.lineTo(13, headY + 13); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = withAlpha(C.aura, 0.85 + 0.15 * Math.sin(t * 6));
  ctx.beginPath(); ctx.ellipse(8, headY + 5, 4, 2.6, 0, 0, TAU); ctx.fill();
  ctx.restore();
  if (q > 0.5 && charge > 0.15) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = withAlpha(C.aura, charge * 0.35);
    ctx.beginPath(); ctx.ellipse(0, chestY + 10, 70 * charge, 60 * charge, 0, 0, TAU); ctx.fill();
    ctx.restore();
  }
}

/* ============================ 妖弓手 ============================ */
function drawArcher(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const draw = p.wind * 0.9 + (p.atk > 0 ? clamp(1 - (p.atk - 0.2) / 0.2, 0, 1) : 0);
  jointLimb(ctx, -6, hipY, 1.55 + p.walk * 0.5, H * 0.24, 0.1, H * 0.22, 8, C.body, INK);
  jointLimb(ctx, 6, hipY, 1.55 - p.walk * 0.5, H * 0.24, 0.1, H * 0.22, 8, C.body, INK);
  // 斗篷
  ctx.fillStyle = INK;
  ctx.beginPath();
  ctx.moveTo(-16, chestY - 2);
  ctx.quadraticCurveTo(-26 + Math.sin(t * 3) * 5, hipY + 16, -14, hipY + 34);
  ctx.lineTo(16, hipY + 30);
  ctx.quadraticCurveTo(24, hipY + 10, 16, chestY - 2);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath();
  ctx.moveTo(-13, chestY);
  ctx.quadraticCurveTo(-22 + Math.sin(t * 3) * 4, hipY + 14, -11, hipY + 30);
  ctx.lineTo(13, hipY + 26);
  ctx.quadraticCurveTo(20, hipY + 8, 13, chestY);
  ctx.closePath(); ctx.fill();
  // 弓
  ctx.save();
  ctx.translate(16, chestY + 8);
  ctx.rotate(-0.06);
  ctx.strokeStyle = INK; ctx.lineWidth = 8;
  ctx.beginPath(); ctx.arc(0, 0, 34, -1.25, 1.25); ctx.stroke();
  ctx.strokeStyle = '#e8e2d0'; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.arc(0, 0, 34, -1.25, 1.25); ctx.stroke();
  ctx.strokeStyle = withAlpha('#ffffff', 0.85); ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(Math.cos(-1.25) * 34, Math.sin(-1.25) * 34);
  ctx.lineTo(-12 - draw * 14, 0);
  ctx.lineTo(Math.cos(1.25) * 34, Math.sin(1.25) * 34);
  ctx.stroke();
  if (draw > 0.1) {
    ctx.strokeStyle = '#c8b48a'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(-12 - draw * 14, 0); ctx.lineTo(38, 0); ctx.stroke();
    ctx.fillStyle = C.trim;
    ctx.beginPath(); ctx.moveTo(-14 - draw * 14, 0); ctx.lineTo(-24 - draw * 14, -5); ctx.lineTo(-24 - draw * 14, 5); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
  jointLimb(ctx, 12, chestY + 4, 1.5 - draw * 0.5, H * 0.18, 0.3 + draw * 0.6, H * 0.16, 7, C.skin, INK);
  jointLimb(ctx, -12, chestY + 4, 1.6 + draw * 0.7, H * 0.18, -0.4 - draw * 0.8, H * 0.16, 7, C.skin, INK);
  // 兜帽頭
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(2, headY, 15, 0, TAU); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath();
  ctx.moveTo(-14, headY + 6); ctx.quadraticCurveTo(0, headY - 24, 16, headY + 4);
  ctx.lineTo(14, headY + 10); ctx.quadraticCurveTo(0, headY - 8, -12, headY + 10);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#1a1a12';
  ctx.beginPath(); ctx.ellipse(6, headY + 2, 8, 6, 0, 0, TAU); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = withAlpha(C.aura, 0.9);
  ctx.beginPath(); ctx.arc(8, headY + 1, 2.4, 0, TAU); ctx.fill();
  ctx.restore();
  // 箭袋
  ctx.fillStyle = '#6a5a3a';
  ctx.save(); ctx.rotate(-0.3);
  roundRect(ctx, -34, chestY + 4, 12, 30, 4); ctx.fill();
  ctx.strokeStyle = '#c8b48a'; ctx.lineWidth = 2;
  for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(-30 + i * 4, chestY + 4); ctx.lineTo(-32 + i * 4, chestY - 12); ctx.stroke(); }
  ctx.restore();
  if (q > 0.5 && draw > 0.2) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = withAlpha(C.aura, draw * 0.5); ctx.lineWidth = 2;
    ctx.setLineDash([8, 8]);
    ctx.beginPath(); ctx.moveTo(40, chestY + 8); ctx.lineTo(160, chestY + 8); ctx.stroke();
    ctx.restore();
  }
}

/* ============================ 獄炎犬 ============================ */
function drawHound(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, H: number, q: number) {
  const run = p.walk;
  ctx.save();
  ctx.translate(0, -H * 0.44);
  // 四腿
  for (let i = 0; i < 4; i++) {
    const bx = -18 + i * 12;
    const ph = run * (i % 2 ? 1 : -1) * 0.7;
    ctx.strokeStyle = INK; ctx.lineWidth = 8;
    ctx.beginPath(); ctx.moveTo(bx, 8); ctx.lineTo(bx + Math.sin(ph) * 12, 30); ctx.stroke();
    ctx.strokeStyle = C.body; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.moveTo(bx, 8); ctx.lineTo(bx + Math.sin(ph) * 12, 30); ctx.stroke();
  }
  // 身軀
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(0, 0, 30, 15, 0, 0, TAU); ctx.fill();
  const g = ctx.createLinearGradient(0, -14, 0, 14);
  g.addColorStop(0, C.skin); g.addColorStop(1, C.body);
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.ellipse(0, 0, 27, 12.5, 0, 0, TAU); ctx.fill();
  // 焰鬃
  if (q > 0.35) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 6; i++) {
      const fx = -20 + i * 8;
      const fl = 10 + Math.sin(t * 12 + i * 1.7) * 6;
      ctx.fillStyle = withAlpha(i % 2 ? '#ff4a6a' : '#ffa060', 0.7);
      ctx.beginPath();
      ctx.moveTo(fx - 5, -8); ctx.quadraticCurveTo(fx, -8 - fl * 2, fx + 5, -8);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }
  // 頭
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(28, -4, 15, 12, 0.1, 0, TAU); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.ellipse(28, -4, 12.5, 10, 0.1, 0, TAU); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath(); ctx.moveTo(34, -2); ctx.lineTo(50, 3); ctx.lineTo(34, 7); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 4; i++) {
    ctx.beginPath(); ctx.moveTo(38 + i * 3, 2); ctx.lineTo(40 + i * 3, 7); ctx.lineTo(42 + i * 3, 2); ctx.closePath(); ctx.fill();
  }
  ctx.beginPath(); ctx.moveTo(20, -12); ctx.lineTo(16, -26); ctx.lineTo(28, -14); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(30, -13); ctx.lineTo(34, -27); ctx.lineTo(38, -12); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = withAlpha(C.aura, 0.95);
  ctx.beginPath(); ctx.ellipse(30, -7, 4, 2.6, -0.2, 0, TAU); ctx.fill();
  ctx.restore();
  // 尾
  ctx.strokeStyle = C.body; ctx.lineWidth = 6; ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-28, -2);
  ctx.quadraticCurveTo(-44, -10 + Math.sin(t * 8) * 8, -52, -22 + Math.sin(t * 8) * 10);
  ctx.stroke();
  ctx.restore();
  void p.atk;
}

/* ============================ 咒旗巫者 ============================ */
function drawShaman(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const cast = p.wind + (p.atk > 0 ? Math.sin(clamp((p.atk - 0.3) / 0.3, 0, 1) * Math.PI) : 0);
  jointLimb(ctx, -7, hipY, 1.55 + p.walk * 0.4, H * 0.24, 0.1, H * 0.22, 8, C.body, INK);
  jointLimb(ctx, 7, hipY, 1.55 - p.walk * 0.4, H * 0.24, 0.1, H * 0.22, 8, C.body, INK);
  // 長袍
  ctx.fillStyle = INK;
  ctx.beginPath();
  ctx.moveTo(-19, chestY); ctx.quadraticCurveTo(-28, hipY + 14, -20, hipY + 34);
  ctx.lineTo(20, hipY + 34); ctx.quadraticCurveTo(28, hipY + 14, 19, chestY);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = C.body;
  ctx.beginPath();
  ctx.moveTo(-16, chestY + 2); ctx.quadraticCurveTo(-24, hipY + 12, -17, hipY + 30);
  ctx.lineTo(17, hipY + 30); ctx.quadraticCurveTo(24, hipY + 12, 16, chestY + 2);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = C.trim;
  for (let i = 0; i < 3; i++) ctx.fillRect(-16, chestY + 12 + i * 12, 32, 3);
  // 咒骨旗
  ctx.save();
  ctx.translate(-20, chestY + 6);
  ctx.rotate(-0.16 + Math.sin(t * 2) * 0.06 - cast * 0.3);
  ctx.strokeStyle = INK; ctx.lineWidth = 7;
  ctx.beginPath(); ctx.moveTo(0, 40); ctx.lineTo(0, -86); ctx.stroke();
  ctx.strokeStyle = '#e8e2d0'; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.moveTo(0, 40); ctx.lineTo(0, -86); ctx.stroke();
  ctx.fillStyle = '#efe9d8';
  ctx.beginPath(); ctx.arc(0, -92, 9, 0, TAU); ctx.fill();
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(-3, -93, 2.2, 0, TAU); ctx.arc(3, -93, 2.2, 0, TAU); ctx.fill();
  const sw = Math.sin(t * 4) * 8;
  ctx.fillStyle = C.trim;
  ctx.beginPath();
  ctx.moveTo(2, -80); ctx.quadraticCurveTo(34 + sw, -70, 30 + sw, -30);
  ctx.lineTo(2, -34); ctx.closePath(); ctx.fill();
  ctx.fillStyle = withAlpha('#ffffff', 0.7);
  ctx.beginPath(); ctx.arc(18 + sw * 0.6, -56, 6, 0, TAU); ctx.fill();
  ctx.restore();
  jointLimb(ctx, 14, chestY + 4, 1.6 - cast * 1.4, H * 0.18, 0.4 + cast, H * 0.16, 8, C.skin, INK);
  // 面具頭
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(2, headY, 14, 0, TAU); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.arc(2, headY, 11.5, 0, TAU); ctx.fill();
  ctx.fillStyle = '#efe9d8';
  ctx.beginPath();
  ctx.moveTo(-8, headY - 8); ctx.lineTo(12, headY - 8); ctx.lineTo(10, headY + 10); ctx.lineTo(-6, headY + 10);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.moveTo(-3, headY - 3); ctx.lineTo(2, headY - 5); ctx.lineTo(1, headY); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(5, headY - 3); ctx.lineTo(10, headY - 5); ctx.lineTo(9, headY); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = withAlpha(C.aura, 0.6 + 0.4 * Math.sin(t * 5));
  ctx.beginPath(); ctx.moveTo(-3, headY - 3); ctx.lineTo(2, headY - 5); ctx.lineTo(1, headY); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(5, headY - 3); ctx.lineTo(10, headY - 5); ctx.lineTo(9, headY); ctx.closePath(); ctx.fill();
  ctx.restore();
  // 頭羽
  ctx.fillStyle = C.trim;
  for (let i = 0; i < 4; i++) {
    const a2 = -1.9 + i * 0.4;
    ctx.beginPath();
    ctx.moveTo(2, headY - 10);
    ctx.quadraticCurveTo(2 + Math.cos(a2) * 20, headY - 22 + Math.sin(a2) * 14, 2 + Math.cos(a2) * 30, headY - 30 + Math.sin(a2) * 20);
    ctx.lineTo(4 + Math.cos(a2) * 28, headY - 26 + Math.sin(a2) * 18);
    ctx.closePath(); ctx.fill();
  }
  if (q > 0.5 && cast > 0.1) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = withAlpha(C.aura, cast * 0.6); ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(0, chestY + 10, 40 + cast * 40, 0, TAU); ctx.stroke();
    ctx.restore();
  }
}

/* ============================ 菁英變體 ============================ */
function drawElite(ctx: CanvasRenderingContext2D, def: EnemyDef, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const base = def.id.replace('_elite', '');
  const fake = { ...def, id: base } as EnemyDef;
  void fake;
  // 以原造型繪製，外加菁英裝甲與紅色氣場
  switch (base) {
    case 'imp': drawImp(ctx, p, C, t, hipY, chestY, headY, H, q); break;
    case 'spear': drawSpear(ctx, p, C, t, hipY, chestY, headY, H, q, { uid: 0 } as Actor); break;
    case 'ninja': drawNinja(ctx, p, C, t, hipY, chestY, headY, H, q); break;
    case 'caster': drawCaster(ctx, p, C, t, hipY, chestY, headY, H, q); break;
    case 'bomber': drawBomber(ctx, p, C, t, H, q, { aiState: p.wind > 0.5 ? 'windup' : 'approach', aiT: 0.2 } as Actor); break;
    case 'brute': drawBrute(ctx, p, C, t, hipY, chestY, headY, H, q); break;
    case 'archer': drawArcher(ctx, p, C, t, hipY, chestY, headY, H, q); break;
    case 'hound': drawHound(ctx, p, C, t, H, q); break;
    case 'shaman': drawShaman(ctx, p, C, t, hipY, chestY, headY, H, q); break;
    default: drawImp(ctx, p, C, t, hipY, chestY, headY, H, q);
  }
  // 菁英骨甲
  ctx.save();
  ctx.fillStyle = '#2a0a14';
  roundRect(ctx, -20, chestY - 4, 40, 26, 8); ctx.fill();
  ctx.fillStyle = '#ff3b52';
  ctx.beginPath(); ctx.moveTo(-16, chestY); ctx.lineTo(0, chestY + 18); ctx.lineTo(16, chestY); ctx.closePath(); ctx.fill();
  ctx.restore();
}

/* ============================ 首領：石魈 ============================ */
function drawBossShixiao(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const slam = p.atk > 0 ? Math.sin(clamp((p.atk - 0.45) / 0.2, 0, 1) * Math.PI) : 0;
  jointLimb(ctx, -18, hipY, 1.5 + p.walk * 0.32, H * 0.26, 0.1, H * 0.24, 26, C.body, INK);
  jointLimb(ctx, 18, hipY, 1.5 - p.walk * 0.32, H * 0.26, 0.1, H * 0.24, 26, C.body, INK);
  ctx.fillStyle = INK;
  roundRect(ctx, -42, chestY - 14, 84, hipY - chestY + 26, 20); ctx.fill();
  const g = ctx.createLinearGradient(-40, chestY, 40, hipY);
  g.addColorStop(0, C.skin); g.addColorStop(0.55, C.body); g.addColorStop(1, '#2e2620');
  ctx.fillStyle = g;
  roundRect(ctx, -38, chestY - 10, 76, hipY - chestY + 20, 18); ctx.fill();
  // 山肩
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.moveTo(-38, chestY - 6); ctx.lineTo(-62, chestY - 34); ctx.lineTo(-30, chestY - 40); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(38, chestY - 6); ctx.lineTo(64, chestY - 32); ctx.lineTo(30, chestY - 40); ctx.closePath(); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.moveTo(-38, chestY - 8); ctx.lineTo(-58, chestY - 32); ctx.lineTo(-32, chestY - 36); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(38, chestY - 8); ctx.lineTo(60, chestY - 30); ctx.lineTo(32, chestY - 36); ctx.closePath(); ctx.fill();
  // 岩漿紋
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = withAlpha(C.aura, 0.45 + 0.35 * Math.sin(t * 1.8));
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(-26, chestY + 4); ctx.lineTo(-8, chestY + 30); ctx.lineTo(-20, hipY);
  ctx.moveTo(22, chestY); ctx.lineTo(8, chestY + 28); ctx.lineTo(26, hipY - 4);
  ctx.stroke();
  ctx.restore();
  // 石柱拳
  for (const s of [1, -1]) {
    ctx.save();
    ctx.translate(s * 40, chestY + 8);
    ctx.rotate(s > 0 ? -0.9 - p.wind * 1.4 + slam * 2.6 : 0.5 + p.walk * 0.2);
    ctx.fillStyle = INK;
    roundRect(ctx, -16, 0, 32, H * 0.3, 12); ctx.fill();
    ctx.fillStyle = C.body;
    roundRect(ctx, -13, 3, 26, H * 0.3 - 6, 10); ctx.fill();
    ctx.fillStyle = INK;
    ctx.beginPath(); ctx.arc(0, H * 0.32, 22, 0, TAU); ctx.fill();
    ctx.fillStyle = C.skin;
    ctx.beginPath(); ctx.arc(0, H * 0.32, 19, 0, TAU); ctx.fill();
    ctx.fillStyle = C.trim;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath(); ctx.arc(-10 + i * 10, H * 0.32 - 6, 4, 0, TAU); ctx.fill();
    }
    ctx.restore();
  }
  // 頭
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(0, headY + 10, 22, 0, TAU); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.arc(0, headY + 10, 19, 0, TAU); ctx.fill();
  ctx.fillStyle = '#2e2620';
  ctx.beginPath(); ctx.moveTo(-10, headY + 18); ctx.lineTo(10, headY + 18); ctx.lineTo(6, headY + 26); ctx.lineTo(-6, headY + 26); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = withAlpha(C.aura, 0.9 + 0.1 * Math.sin(t * 4));
  ctx.beginPath(); ctx.ellipse(-7, headY + 6, 5, 3.4, -0.2, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(7, headY + 6, 5, 3.4, 0.2, 0, TAU); ctx.fill();
  ctx.restore();
  // 頭頂岩冠
  ctx.fillStyle = C.body;
  for (let i = -2; i <= 2; i++) {
    ctx.beginPath();
    ctx.moveTo(i * 10 - 5, headY - 4); ctx.lineTo(i * 10, headY - 24 - Math.abs(i) * -6); ctx.lineTo(i * 10 + 5, headY - 4);
    ctx.closePath(); ctx.fill();
  }
  if (q > 0.4 && p.wind > 0.1) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = withAlpha(C.aura, p.wind * 0.3);
    ctx.beginPath(); ctx.arc(40, chestY + 40, 90 * p.wind, 0, TAU); ctx.fill();
    ctx.restore();
  }
}

/* ============================ 首領：赤角焰侯 ============================ */
function drawBossChijiao(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const strike = p.atk > 0 ? Math.sin(clamp((p.atk - 0.4) / 0.22, 0, 1) * Math.PI) : 0;
  jointLimb(ctx, -18, hipY, 1.5 + p.walk * 0.36, H * 0.26, 0.12, H * 0.24, 24, C.body, INK);
  jointLimb(ctx, 18, hipY, 1.5 - p.walk * 0.36, H * 0.26, 0.12, H * 0.24, 24, C.body, INK);
  // 熔岩下半身
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 8; i++) {
    const yy = hipY + i * 8;
    ctx.fillStyle = withAlpha(i % 2 ? '#ff6a1a' : '#ffc93c', 0.25 + 0.15 * Math.sin(t * 4 + i));
    ctx.beginPath(); ctx.ellipse(Math.sin(t * 2 + i) * 6, yy, 34 - i * 2, 6, 0, 0, TAU); ctx.fill();
  }
  ctx.restore();
  ctx.fillStyle = INK;
  roundRect(ctx, -40, chestY - 12, 80, hipY - chestY + 24, 18); ctx.fill();
  const g = ctx.createLinearGradient(0, chestY - 10, 0, hipY + 10);
  g.addColorStop(0, '#c04a2a'); g.addColorStop(0.6, C.body); g.addColorStop(1, '#2a0a08');
  ctx.fillStyle = g;
  roundRect(ctx, -36, chestY - 8, 72, hipY - chestY + 18, 16); ctx.fill();
  // 胸裂焰心
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const cg = ctx.createRadialGradient(0, chestY + 22, 2, 0, chestY + 22, 34);
  cg.addColorStop(0, 'rgba(255,250,220,0.95)');
  cg.addColorStop(0.4, withAlpha('#ff8a3a', 0.7));
  cg.addColorStop(1, withAlpha('#ff2d10', 0));
  ctx.fillStyle = cg;
  ctx.beginPath(); ctx.arc(0, chestY + 22, 34, 0, TAU); ctx.fill();
  ctx.restore();
  // 雙戟
  for (const s of [1, -1]) {
    ctx.save();
    ctx.translate(s * 40, chestY + 6);
    ctx.rotate(s > 0 ? -1 - p.wind * 1.2 + strike * 2.8 : 0.6 - strike * 0.8);
    ctx.strokeStyle = INK; ctx.lineWidth = 10;
    ctx.beginPath(); ctx.moveTo(0, 30); ctx.lineTo(0, -76); ctx.stroke();
    ctx.strokeStyle = '#3a1a10'; ctx.lineWidth = 6;
    ctx.beginPath(); ctx.moveTo(0, 30); ctx.lineTo(0, -76); ctx.stroke();
    ctx.fillStyle = INK;
    ctx.beginPath(); ctx.moveTo(0, -76); ctx.lineTo(-20, -50); ctx.lineTo(0, -56); ctx.lineTo(20, -50); ctx.closePath(); ctx.fill();
    ctx.fillStyle = C.metal;
    ctx.beginPath(); ctx.moveTo(0, -74); ctx.lineTo(-16, -52); ctx.lineTo(0, -58); ctx.lineTo(16, -52); ctx.closePath(); ctx.fill();
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = withAlpha('#ff6a1a', 0.5 + 0.3 * Math.sin(t * 6 + s));
    ctx.beginPath(); ctx.moveTo(0, -74); ctx.lineTo(-16, -52); ctx.lineTo(0, -58); ctx.lineTo(16, -52); ctx.closePath(); ctx.fill();
    ctx.restore();
    ctx.restore();
  }
  // 頭＋巨角＋焰鬃
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(0, headY + 8, 21, 0, TAU); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.arc(0, headY + 8, 18, 0, TAU); ctx.fill();
  ctx.fillStyle = C.metal;
  for (const s of [1, -1]) {
    ctx.beginPath();
    ctx.moveTo(s * 12, headY - 2);
    ctx.quadraticCurveTo(s * 40, headY - 20, s * 34, headY - 52);
    ctx.quadraticCurveTo(s * 26, headY - 22, s * 8, headY - 8);
    ctx.closePath(); ctx.fill();
  }
  if (q > 0.35) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 10; i++) {
      const fx = -22 + i * 5;
      const fl = 14 + Math.sin(t * 13 + i * 1.3) * 10;
      ctx.fillStyle = withAlpha(i % 2 ? '#ff6a1a' : '#ffc93c', 0.6);
      ctx.beginPath();
      ctx.moveTo(fx - 5, headY - 6); ctx.quadraticCurveTo(fx, headY - 6 - fl * 2, fx + 5, headY - 6);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = '#ffe08a';
  ctx.beginPath(); ctx.ellipse(-7, headY + 6, 5, 3.2, -0.2, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(7, headY + 6, 5, 3.2, 0.2, 0, TAU); ctx.fill();
  ctx.restore();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.moveTo(-8, headY + 18); ctx.lineTo(-4, headY + 26); ctx.lineTo(0, headY + 18); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(4, headY + 18); ctx.lineTo(8, headY + 26); ctx.lineTo(12, headY + 18); ctx.closePath(); ctx.fill();
}

/* ============================ 首領：玄霄元帥 ============================ */
function drawBossXuanxiao(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const thrust = p.atk > 0 ? Math.sin(clamp((p.atk - 0.3) / 0.24, 0, 1) * Math.PI) : 0;
  jointLimb(ctx, -16, hipY, 1.5 + p.walk * 0.42, H * 0.26, 0.1, H * 0.24, 22, '#1b2a6b', INK);
  jointLimb(ctx, 16, hipY, 1.5 - p.walk * 0.42, H * 0.26, 0.1, H * 0.24, 22, '#1b2a6b', INK);
  // 戰裙
  ctx.fillStyle = C.metal;
  for (let i = -2; i <= 2; i++) {
    ctx.beginPath();
    ctx.moveTo(i * 16 - 9, hipY - 4); ctx.lineTo(i * 16 + 9, hipY - 4);
    ctx.lineTo(i * 16 + 6, hipY + 40); ctx.lineTo(i * 16 - 6, hipY + 40);
    ctx.closePath(); ctx.fill();
  }
  // 鎧甲軀幹
  ctx.fillStyle = INK;
  roundRect(ctx, -40, chestY - 14, 80, hipY - chestY + 22, 16); ctx.fill();
  const g = ctx.createLinearGradient(-40, chestY, 40, hipY);
  g.addColorStop(0, '#2a3f8f'); g.addColorStop(0.5, '#1b2a6b'); g.addColorStop(1, '#0d1436');
  ctx.fillStyle = g;
  roundRect(ctx, -36, chestY - 10, 72, hipY - chestY + 16, 14); ctx.fill();
  ctx.fillStyle = C.metal;
  ctx.beginPath(); ctx.moveTo(-20, chestY - 6); ctx.lineTo(20, chestY - 6); ctx.lineTo(0, chestY + 30); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = C.trim; ctx.lineWidth = 2.5;
  for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(-30, chestY + 4 + i * 10); ctx.lineTo(30, chestY + 4 + i * 10); ctx.stroke(); }
  // 披風
  ctx.save();
  const sw = Math.sin(t * 2.2) * 12;
  ctx.fillStyle = '#7a1020';
  ctx.beginPath();
  ctx.moveTo(-30, chestY - 6);
  ctx.quadraticCurveTo(-70 + sw, hipY + 20, -48 + sw * 1.4, hipY + 74);
  ctx.lineTo(30, hipY + 40);
  ctx.quadraticCurveTo(48, hipY, 30, chestY - 6);
  ctx.closePath(); ctx.fill();
  ctx.restore();
  // 肩甲
  ctx.fillStyle = C.metal;
  ctx.beginPath(); ctx.ellipse(-42, chestY - 2, 20, 14, -0.3, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(42, chestY - 2, 20, 14, 0.3, 0, TAU); ctx.fill();
  ctx.fillStyle = C.trim;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath(); ctx.moveTo(34 + i * 6, chestY - 12); ctx.lineTo(38 + i * 6, chestY - 26); ctx.lineTo(42 + i * 6, chestY - 12); ctx.closePath(); ctx.fill();
  }
  // 天罡雷槍
  ctx.save();
  ctx.translate(38, chestY + 10);
  ctx.rotate(-0.2 - p.wind * 0.5 + thrust * 0.26);
  ctx.translate(thrust * 46, 0);
  ctx.strokeStyle = INK; ctx.lineWidth = 9;
  ctx.beginPath(); ctx.moveTo(-64, 34); ctx.lineTo(72, -30); ctx.stroke();
  ctx.strokeStyle = '#c9d3e8'; ctx.lineWidth = 5.5;
  ctx.beginPath(); ctx.moveTo(-64, 34); ctx.lineTo(72, -30); ctx.stroke();
  ctx.fillStyle = C.metal;
  ctx.beginPath(); ctx.moveTo(70, -30); ctx.lineTo(104, -44); ctx.lineTo(76, -18); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#7a1020';
  for (let i = 0; i < 5; i++) {
    const s2 = Math.sin(t * 7 + i) * 6;
    ctx.beginPath(); ctx.moveTo(58, -24); ctx.quadraticCurveTo(48 + s2, -12 + i * 3, 38 + s2, 2 + i * 5); ctx.lineTo(44 + s2, 4 + i * 5); ctx.quadraticCurveTo(52, -10, 62, -22); ctx.closePath(); ctx.fill();
  }
  if (q > 0.4) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = withAlpha('#9fe8ff', 0.6 + 0.4 * Math.sin(t * 18));
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(72, -30);
    for (let i = 1; i <= 5; i++) ctx.lineTo(72 + i * 8, -30 + Math.sin(t * 24 + i * 2) * 12);
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();
  jointLimb(ctx, -36, chestY + 4, 1.7 + p.walk * 0.3, H * 0.2, 0.4, H * 0.18, 14, '#2a3f8f', INK);
  // 頭＋頭盔＋光環
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(0, headY + 8, 19, 0, TAU); ctx.fill();
  ctx.fillStyle = '#e8dcc0';
  ctx.beginPath(); ctx.arc(0, headY + 8, 16, 0, TAU); ctx.fill();
  ctx.fillStyle = C.metal;
  ctx.beginPath(); ctx.moveTo(-18, headY + 4); ctx.quadraticCurveTo(0, headY - 22, 18, headY + 4); ctx.lineTo(18, headY + 8); ctx.lineTo(-18, headY + 8); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#7a1020';
  ctx.beginPath(); ctx.moveTo(0, headY - 20); ctx.quadraticCurveTo(14 + Math.sin(t * 3) * 6, headY - 46, 4, headY - 60); ctx.lineTo(-4, headY - 40); ctx.closePath(); ctx.fill();
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.ellipse(-6, headY + 8, 3.4, 4.4, 0, 0, TAU); ctx.ellipse(6, headY + 8, 3.4, 4.4, 0, 0, TAU); ctx.fill();
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = withAlpha(C.trim, 0.95);
  ctx.beginPath(); ctx.arc(-6, headY + 8, 1.8, 0, TAU); ctx.arc(6, headY + 8, 1.8, 0, TAU); ctx.fill();
  // 背後光環
  ctx.strokeStyle = withAlpha('#ffe6a8', 0.5 + 0.25 * Math.sin(t * 2));
  ctx.lineWidth = 5;
  ctx.beginPath(); ctx.arc(0, headY + 6, 44, 0, TAU); ctx.stroke();
  ctx.strokeStyle = withAlpha('#9fe8ff', 0.4);
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(0, headY + 6, 54, t * 0.6, t * 0.6 + 4.6); ctx.stroke();
  ctx.restore();
}

/* ============================ 首領：九瞳魔皇 燼天 ============================ */
function drawBossJintian(ctx: CanvasRenderingContext2D, p: EPose, C: Cols, t: number, hipY: number, chestY: number, headY: number, H: number, q: number) {
  const sweep = p.atk > 0 ? Math.sin(clamp((p.atk - 0.28) / 0.3, 0, 1) * Math.PI) : 0;
  // 六臂
  for (let i = 0; i < 6; i++) {
    const s = i < 3 ? 1 : -1;
    const idx = i % 3;
    const baseA = s > 0 ? 1.9 - idx * 0.35 : 1.3 + idx * 0.35;
    const extra = s > 0 ? -sweep * (idx === 0 ? 2.2 : 0.6) : sweep * 0.5;
    const hand = jointLimb(ctx, s * (30 + idx * 4), chestY - 6 + idx * 16, baseA + extra + Math.sin(t * 1.4 + i) * 0.08, H * 0.2, 0.5, H * 0.19, 13 - idx, '#2a1220', INK);
    // 手持物：戟／劍／經卷
    ctx.save();
    ctx.translate(hand.ex, hand.ey);
    ctx.rotate(baseA + extra - 1.2);
    if (idx === 0) {
      ctx.strokeStyle = INK; ctx.lineWidth = 8;
      ctx.beginPath(); ctx.moveTo(0, 20); ctx.lineTo(0, -60); ctx.stroke();
      ctx.fillStyle = C.metal;
      ctx.beginPath(); ctx.moveTo(0, -60); ctx.lineTo(-16, -38); ctx.lineTo(0, -44); ctx.lineTo(16, -38); ctx.closePath(); ctx.fill();
    } else if (idx === 1) {
      ctx.fillStyle = INK;
      ctx.beginPath(); ctx.moveTo(-6, 10); ctx.lineTo(6, 10); ctx.lineTo(3, -56); ctx.lineTo(-3, -56); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#c9d3e8';
      ctx.beginPath(); ctx.moveTo(-4, 8); ctx.lineTo(4, 8); ctx.lineTo(2, -54); ctx.lineTo(-2, -54); ctx.closePath(); ctx.fill();
    } else {
      ctx.fillStyle = '#e8dcc0';
      roundRect(ctx, -12, -22, 24, 34, 3); ctx.fill();
      ctx.fillStyle = '#7a1020';
      for (let k = 0; k < 4; k++) ctx.fillRect(-9, -18 + k * 7, 18, 2.4);
    }
    ctx.restore();
  }
  jointLimb(ctx, -22, hipY, 1.5 + p.walk * 0.3, H * 0.28, 0.1, H * 0.26, 30, '#1a0a14', INK);
  jointLimb(ctx, 22, hipY, 1.5 - p.walk * 0.3, H * 0.28, 0.1, H * 0.26, 30, '#1a0a14', INK);
  // 巨大軀幹
  ctx.fillStyle = INK;
  roundRect(ctx, -52, chestY - 20, 104, hipY - chestY + 34, 22); ctx.fill();
  const g = ctx.createLinearGradient(0, chestY - 20, 0, hipY + 14);
  g.addColorStop(0, '#4a1a2a'); g.addColorStop(0.5, C.body); g.addColorStop(1, '#0d0409');
  ctx.fillStyle = g;
  roundRect(ctx, -47, chestY - 16, 94, hipY - chestY + 28, 20); ctx.fill();
  // 熔岩裂縫
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.strokeStyle = withAlpha('#ff3b52', 0.5 + 0.4 * Math.sin(t * 2.2));
  ctx.lineWidth = 4;
  for (let i = 0; i < 6; i++) {
    ctx.beginPath();
    ctx.moveTo(-40 + i * 16, chestY - 10);
    ctx.lineTo(-30 + i * 14 + Math.sin(i * 2.3) * 8, chestY + 20);
    ctx.lineTo(-38 + i * 16, hipY + 6);
    ctx.stroke();
  }
  ctx.restore();
  // 九瞳（胸腹）
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 5; i++) {
    const a2 = (i / 5) * TAU + t * 0.5;
    const ex = Math.cos(a2) * 26, ey = chestY + 26 + Math.sin(a2) * 18;
    const open = 0.5 + 0.5 * Math.sin(t * 1.6 + i);
    ctx.fillStyle = withAlpha('#ffc93c', 0.35 + open * 0.5);
    ctx.beginPath(); ctx.ellipse(ex, ey, 9, 5 * open + 1, a2 * 0.2, 0, TAU); ctx.fill();
    ctx.fillStyle = '#1a0a14';
    ctx.beginPath(); ctx.ellipse(ex, ey, 3.4, 4.4 * open + 0.6, 0, 0, TAU); ctx.fill();
  }
  ctx.restore();
  // 頭＋巨角＋黑日光環
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const bg = ctx.createRadialGradient(0, headY + 6, 10, 0, headY + 6, 110);
  bg.addColorStop(0, 'rgba(10,2,6,0.9)');
  bg.addColorStop(0.55, withAlpha('#ff2d40', 0.35 + 0.15 * Math.sin(t * 2)));
  bg.addColorStop(1, 'rgba(255,45,64,0)');
  ctx.fillStyle = bg;
  ctx.beginPath(); ctx.arc(0, headY + 6, 110, 0, TAU); ctx.fill();
  ctx.restore();
  ctx.fillStyle = INK;
  ctx.beginPath(); ctx.arc(0, headY + 8, 25, 0, TAU); ctx.fill();
  ctx.fillStyle = C.skin;
  ctx.beginPath(); ctx.arc(0, headY + 8, 21, 0, TAU); ctx.fill();
  ctx.fillStyle = C.metal;
  for (const s of [1, -1]) {
    ctx.beginPath();
    ctx.moveTo(s * 14, headY - 4);
    ctx.quadraticCurveTo(s * 58, headY - 26, s * 46, headY - 78);
    ctx.quadraticCurveTo(s * 34, headY - 30, s * 8, headY - 10);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = INK; ctx.lineWidth = 2.5; ctx.stroke();
  }
  // 九瞳（面部三排）
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (let r = 0; r < 3; r++) {
    for (let i = 0; i < 3 - r; i++) {
      const ex = (i - (2 - r) / 2) * 12;
      const ey = headY + r * 8;
      const open = clamp(0.4 + 0.6 * Math.sin(t * 2.4 + r + i), 0, 1);
      ctx.fillStyle = withAlpha(r === 0 ? '#ff2d40' : '#ffc93c', 0.6 + open * 0.4);
      ctx.beginPath(); ctx.ellipse(ex, ey, 4.6, 3 * open + 0.8, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#0a0206';
      ctx.beginPath(); ctx.ellipse(ex, ey, 1.8, 2.4 * open + 0.4, 0, 0, TAU); ctx.fill();
    }
  }
  ctx.restore();
  // 焰披風
  if (q > 0.3) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 16; i++) {
      const fx = -56 + i * 7.4;
      const fl = 24 + Math.sin(t * 9 + i * 1.1) * 16;
      ctx.fillStyle = withAlpha(i % 3 === 0 ? '#ffc93c' : '#ff2d40', 0.4);
      ctx.beginPath();
      ctx.moveTo(fx - 5, chestY - 14);
      ctx.quadraticCurveTo(fx, chestY - 14 - fl * 2.4, fx + 5, chestY - 14);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }
  void C.trim;
}

/* ============================ 殺氣預警 ============================ */
export function drawTelegraph(ctx: CanvasRenderingContext2D, a: Actor, sx: number, sy: number, t: number) {
  if (a.dead || a.aiState !== 'windup' || !a.pendingAttack) return;
  const atk = a.pendingAttack;
  const k = clamp(1 - a.aiT / Math.max(0.05, atk.windup), 0, 1);
  const range = Math.min(240, atk.range * 0.8);
  ctx.save();
  // 地面危險區
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 0.16 + k * 0.4;
  const g = ctx.createLinearGradient(sx, 0, sx + a.facing * range, 0);
  g.addColorStop(0, withAlpha('#ff2d40', 0.1));
  g.addColorStop(1, withAlpha('#ff2d40', 0.75));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(sx + (a.facing * range) / 2, sy + 6, range / 2, 26, 0, 0, TAU);
  ctx.fill();
  // 驚嘆號
  ctx.globalAlpha = 0.5 + 0.5 * Math.sin(t * 22);
  ctx.fillStyle = '#ff2d40';
  ctx.font = `900 ${26 + k * 10}px "Noto Sans TC", sans-serif`;
  ctx.textAlign = 'center';
  ctx.fillText('!', sx, sy - a.height * a.scale - 34);
  ctx.restore();
}
