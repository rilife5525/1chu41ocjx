/**
 * 音效與音樂系統（WebAudio 全程序化合成）
 * ------------------------------------------------------------------
 * 不使用任何外部音檔：打擊、爆炸、風、雷、UI、BGM 全部即時合成。
 * BGM 採用 16 步序列器 + 前瞻排程，依章節切換不同調式／節奏／配器，
 * 兼顧「有音樂感」與「零載入成本」。
 */
import type { SfxId } from '../core/types';
import { clamp } from '../core/util';

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let musicGain: GainNode | null = null;
let sfxGain: GainNode | null = null;
let noiseBuf: AudioBuffer | null = null;
let started = false;

export const Audio = {
  musicVol: 0.55,
  sfxVol: 0.8,
  enabled: true,
};

export function initAudio() {
  if (ctx) return ctx;
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AC) return null;
  ctx = new AC();
  master = ctx.createGain();
  master.gain.value = 0.9;
  master.connect(ctx.destination);
  musicGain = ctx.createGain();
  musicGain.gain.value = Audio.musicVol;
  musicGain.connect(master);
  sfxGain = ctx.createGain();
  sfxGain.gain.value = Audio.sfxVol;
  sfxGain.connect(master);
  // 白噪音緩衝（鼓、爆炸、風聲共用）
  const len = ctx.sampleRate * 2;
  noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
  const d = noiseBuf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  return ctx;
}

export function resumeAudio() {
  const c = initAudio();
  if (c && c.state === 'suspended') void c.resume();
  if (c) started = true;
}

export function setVolumes(music: number, sfx: number) {
  Audio.musicVol = clamp(music, 0, 1);
  Audio.sfxVol = clamp(sfx, 0, 1);
  if (musicGain) musicGain.gain.value = Audio.musicVol;
  if (sfxGain) sfxGain.gain.value = Audio.sfxVol;
}

/* ============================ 合成工具 ============================ */
interface ToneOpts {
  type?: OscillatorType;
  freq: number;
  to?: number;
  dur: number;
  gain?: number;
  attack?: number;
  delay?: number;
  detune?: number;
  curve?: 'exp' | 'lin';
  dest?: AudioNode;
}
function tone(o: ToneOpts) {
  if (!ctx || !sfxGain || !Audio.enabled) return;
  const t0 = ctx.currentTime + (o.delay ?? 0);
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = o.type ?? 'sine';
  osc.frequency.setValueAtTime(Math.max(20, o.freq), t0);
  if (o.to !== undefined) {
    if (o.curve === 'lin') osc.frequency.linearRampToValueAtTime(Math.max(20, o.to), t0 + o.dur);
    else osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.to), t0 + o.dur);
  }
  if (o.detune) osc.detune.value = o.detune;
  const peak = o.gain ?? 0.3;
  const atk = o.attack ?? 0.005;
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.linearRampToValueAtTime(peak, t0 + atk);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
  osc.connect(g);
  g.connect(o.dest ?? sfxGain);
  osc.start(t0);
  osc.stop(t0 + o.dur + 0.05);
}

function noise(o: { dur: number; gain?: number; freq?: number; q?: number; type?: BiquadFilterType; to?: number; delay?: number; dest?: AudioNode }) {
  if (!ctx || !sfxGain || !noiseBuf || !Audio.enabled) return;
  const t0 = ctx.currentTime + (o.delay ?? 0);
  const src = ctx.createBufferSource();
  src.buffer = noiseBuf;
  src.loop = true;
  const f = ctx.createBiquadFilter();
  f.type = o.type ?? 'bandpass';
  f.frequency.setValueAtTime(o.freq ?? 800, t0);
  if (o.to) f.frequency.exponentialRampToValueAtTime(Math.max(40, o.to), t0 + o.dur);
  f.Q.value = o.q ?? 1;
  const g = ctx.createGain();
  g.gain.setValueAtTime(o.gain ?? 0.25, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
  src.connect(f); f.connect(g); g.connect(o.dest ?? sfxGain);
  src.start(t0);
  src.stop(t0 + o.dur + 0.05);
}

/* ============================ 音效表 ============================ */
export function playSfx(id: SfxId, vol = 1, rate = 1) {
  if (!ctx || !Audio.enabled) return;
  const v = clamp(vol, 0, 1.4);
  switch (id) {
    case 'swing':
      noise({ dur: 0.16, gain: 0.16 * v, freq: 1800 * rate, to: 500, q: 0.8 });
      break;
    case 'swingHeavy':
      noise({ dur: 0.28, gain: 0.26 * v, freq: 900 * rate, to: 180, q: 0.7 });
      tone({ type: 'triangle', freq: 180 * rate, to: 60, dur: 0.24, gain: 0.16 * v });
      break;
    case 'hit':
      noise({ dur: 0.09, gain: 0.3 * v, freq: 2400 * rate, to: 700, q: 1.4, type: 'bandpass' });
      tone({ type: 'square', freq: 320 * rate, to: 110, dur: 0.08, gain: 0.16 * v });
      break;
    case 'hitHeavy':
      noise({ dur: 0.22, gain: 0.4 * v, freq: 1200 * rate, to: 120, q: 0.6 });
      tone({ type: 'sawtooth', freq: 160 * rate, to: 42, dur: 0.26, gain: 0.3 * v });
      tone({ type: 'square', freq: 90, to: 40, dur: 0.2, gain: 0.22 * v, delay: 0.01 });
      break;
    case 'hitCrit':
      noise({ dur: 0.3, gain: 0.42 * v, freq: 3000 * rate, to: 200, q: 0.8 });
      tone({ type: 'sawtooth', freq: 420 * rate, to: 60, dur: 0.3, gain: 0.3 * v });
      tone({ type: 'sine', freq: 1200 * rate, to: 300, dur: 0.24, gain: 0.2 * v, delay: 0.02 });
      break;
    case 'block':
      tone({ type: 'square', freq: 900, to: 400, dur: 0.1, gain: 0.16 * v });
      noise({ dur: 0.1, gain: 0.16 * v, freq: 3000, q: 2 });
      break;
    case 'jump':
      tone({ type: 'sine', freq: 300 * rate, to: 720, dur: 0.16, gain: 0.16 * v });
      break;
    case 'dash':
      noise({ dur: 0.26, gain: 0.24 * v, freq: 600, to: 2600, q: 0.6 });
      tone({ type: 'triangle', freq: 220, to: 640, dur: 0.2, gain: 0.12 * v });
      break;
    case 'land':
      noise({ dur: 0.16, gain: 0.24 * v, freq: 400, to: 90, q: 0.7 });
      tone({ type: 'sine', freq: 120, to: 50, dur: 0.16, gain: 0.18 * v });
      break;
    case 'hurt':
      tone({ type: 'sawtooth', freq: 260, to: 90, dur: 0.26, gain: 0.24 * v });
      noise({ dur: 0.18, gain: 0.18 * v, freq: 900, to: 200 });
      break;
    case 'die':
      tone({ type: 'sawtooth', freq: 400, to: 60, dur: 0.7, gain: 0.22 * v });
      tone({ type: 'triangle', freq: 200, to: 40, dur: 0.9, gain: 0.2 * v, delay: 0.05 });
      break;
    case 'explode':
      noise({ dur: 0.6, gain: 0.5 * v, freq: 1400, to: 60, q: 0.4 });
      tone({ type: 'sawtooth', freq: 140, to: 30, dur: 0.5, gain: 0.34 * v });
      tone({ type: 'sine', freq: 70, to: 28, dur: 0.7, gain: 0.3 * v, delay: 0.02 });
      break;
    case 'fire':
      noise({ dur: 0.42, gain: 0.3 * v, freq: 900, to: 240, q: 0.5 });
      tone({ type: 'sawtooth', freq: 300 * rate, to: 120, dur: 0.34, gain: 0.16 * v });
      break;
    case 'water':
      tone({ type: 'sine', freq: 900 * rate, to: 300, dur: 0.36, gain: 0.2 * v });
      noise({ dur: 0.34, gain: 0.16 * v, freq: 2200, to: 600, q: 1.2, type: 'bandpass' });
      break;
    case 'wind':
      noise({ dur: 0.4, gain: 0.22 * v, freq: 2600, to: 400, q: 0.5, type: 'highpass' });
      break;
    case 'thunder':
      noise({ dur: 0.7, gain: 0.42 * v, freq: 4000, to: 100, q: 0.3 });
      tone({ type: 'sawtooth', freq: 1200, to: 60, dur: 0.5, gain: 0.2 * v });
      tone({ type: 'square', freq: 80, to: 30, dur: 0.8, gain: 0.26 * v, delay: 0.05 });
      break;
    case 'charge':
      tone({ type: 'sawtooth', freq: 120, to: 900, dur: 0.5, gain: 0.16 * v });
      tone({ type: 'sine', freq: 240, to: 1800, dur: 0.5, gain: 0.1 * v, delay: 0.02 });
      break;
    case 'ult':
      tone({ type: 'sawtooth', freq: 80, to: 420, dur: 0.9, gain: 0.3 * v });
      tone({ type: 'square', freq: 160, to: 840, dur: 0.9, gain: 0.18 * v, delay: 0.04 });
      noise({ dur: 1.1, gain: 0.28 * v, freq: 300, to: 5000, q: 0.4 });
      tone({ type: 'sine', freq: 1200, to: 60, dur: 1.2, gain: 0.22 * v, delay: 0.7 });
      break;
    case 'pickup':
      tone({ type: 'sine', freq: 900 * rate, to: 1500, dur: 0.1, gain: 0.12 * v });
      tone({ type: 'triangle', freq: 1400 * rate, to: 2100, dur: 0.09, gain: 0.08 * v, delay: 0.04 });
      break;
    case 'levelup':
      [523, 659, 784, 1046].forEach((f, i) => tone({ type: 'triangle', freq: f, dur: 0.3, gain: 0.16 * v, delay: i * 0.07 }));
      break;
    case 'ui':
      tone({ type: 'square', freq: 660, to: 880, dur: 0.06, gain: 0.08 * v });
      break;
    case 'uiBig':
      tone({ type: 'sawtooth', freq: 220, to: 440, dur: 0.18, gain: 0.14 * v });
      noise({ dur: 0.16, gain: 0.1 * v, freq: 2000, to: 800 });
      break;
    case 'waveStart':
      tone({ type: 'sawtooth', freq: 160, to: 320, dur: 0.5, gain: 0.2 * v });
      tone({ type: 'square', freq: 320, to: 640, dur: 0.4, gain: 0.12 * v, delay: 0.08 });
      break;
    case 'bossRoar':
      tone({ type: 'sawtooth', freq: 90, to: 45, dur: 1.4, gain: 0.36 * v });
      tone({ type: 'square', freq: 140, to: 60, dur: 1.2, gain: 0.2 * v, delay: 0.05 });
      noise({ dur: 1.3, gain: 0.3 * v, freq: 700, to: 90, q: 0.4 });
      break;
  }
}

/* ============================ BGM 序列器 ============================ */
export type TrackId = 'title' | 'hub' | 'peak' | 'flame' | 'heaven' | 'void' | 'boss' | 'victory' | 'none';

interface TrackDef {
  bpm: number;
  root: number; // Hz
  scale: number[]; // 半音階偏移
  bass: number[]; // 16 步（-1 = 休止）
  lead: number[];
  stab: number[];
  drum: 'rock' | 'funk' | 'epic' | 'calm';
  wave: OscillatorType;
  leadWave: OscillatorType;
  swing?: number;
}

const TRACKS: Record<Exclude<TrackId, 'none'>, TrackDef> = {
  title: {
    bpm: 132, root: 110, scale: [0, 3, 5, 7, 10], bass: [0, -1, 0, 4, -1, 3, -1, 2, 0, -1, 0, 4, 5, -1, 3, -1],
    lead: [12, -1, 15, -1, 19, -1, 15, 12, -1, 10, -1, 12, 15, -1, -1, -1],
    stab: [-1, -1, 7, -1, -1, -1, 7, -1, -1, -1, 10, -1, -1, 7, -1, -1],
    drum: 'funk', wave: 'sawtooth', leadWave: 'square', swing: 0.12,
  },
  hub: {
    bpm: 96, root: 130.8, scale: [0, 2, 4, 7, 9], bass: [0, -1, -1, 2, -1, 4, -1, -1, 0, -1, -1, 5, -1, 4, -1, 2],
    lead: [12, -1, 14, -1, -1, 16, -1, 14, 12, -1, 9, -1, -1, 12, -1, -1],
    stab: [-1, -1, -1, -1, 7, -1, -1, -1, -1, -1, -1, -1, 9, -1, -1, -1],
    drum: 'calm', wave: 'triangle', leadWave: 'sine',
  },
  peak: {
    bpm: 152, root: 123.5, scale: [0, 2, 3, 7, 8], bass: [0, 0, -1, 3, 0, -1, 5, -1, 0, 0, -1, 3, 7, -1, 5, 3],
    lead: [12, -1, 15, 14, -1, 12, -1, 10, 12, -1, 15, -1, 17, 15, 12, -1],
    stab: [-1, 7, -1, -1, 10, -1, -1, 7, -1, 7, -1, -1, 12, -1, -1, 10],
    drum: 'rock', wave: 'sawtooth', leadWave: 'square', swing: 0.08,
  },
  flame: {
    bpm: 164, root: 98, scale: [0, 1, 5, 7, 8], bass: [0, -1, 0, 0, 5, -1, 3, -1, 0, -1, 0, 0, 7, 5, 3, 1],
    lead: [12, 13, -1, 12, 15, -1, 13, 12, -1, 10, 12, -1, 15, 17, -1, 13],
    stab: [7, -1, -1, 8, -1, -1, 7, -1, 10, -1, -1, 8, -1, 7, -1, -1],
    drum: 'rock', wave: 'sawtooth', leadWave: 'sawtooth',
  },
  heaven: {
    bpm: 144, root: 146.8, scale: [0, 2, 4, 5, 7, 9, 11], bass: [0, -1, 4, -1, 0, -1, 5, -1, 7, -1, 4, -1, 2, -1, 5, -1],
    lead: [16, -1, 19, 21, -1, 19, 16, -1, 14, -1, 16, -1, 19, 21, 23, -1],
    stab: [-1, 7, -1, 12, -1, 7, -1, 11, -1, 7, -1, 12, -1, 9, -1, 7],
    drum: 'epic', wave: 'triangle', leadWave: 'square',
  },
  void: {
    bpm: 172, root: 87.3, scale: [0, 1, 4, 6, 8, 10], bass: [0, 0, -1, 1, 0, -1, 6, 4, 0, 0, -1, 8, 6, 4, 1, -1],
    lead: [12, -1, 13, 16, -1, 18, -1, 16, 13, -1, 12, -1, 10, 13, 16, -1],
    stab: [7, -1, 8, -1, 10, -1, 7, -1, 12, -1, 10, -1, 8, -1, 6, -1],
    drum: 'epic', wave: 'sawtooth', leadWave: 'sawtooth',
  },
  boss: {
    bpm: 178, root: 92.5, scale: [0, 1, 3, 5, 6, 8, 10], bass: [0, 0, 0, -1, 3, 3, -1, 0, 5, 5, -1, 3, 1, 1, 6, -1],
    lead: [12, 13, 15, -1, 16, 15, 13, 12, -1, 13, 16, 18, 16, 13, 12, -1],
    stab: [7, 7, -1, 8, -1, 7, 10, -1, 7, 7, -1, 8, 11, -1, 10, 7],
    drum: 'epic', wave: 'sawtooth', leadWave: 'square',
  },
  victory: {
    bpm: 120, root: 130.8, scale: [0, 2, 4, 5, 7, 9, 11], bass: [0, -1, 4, -1, 5, -1, 4, -1, 0, -1, 4, -1, 7, -1, 5, -1],
    lead: [12, 16, 19, 24, -1, 19, 16, 19, 21, 24, -1, 21, 19, 16, 12, -1],
    stab: [-1, -1, 7, -1, -1, -1, 9, -1, -1, -1, 12, -1, -1, -1, 7, -1],
    drum: 'epic', wave: 'triangle', leadWave: 'triangle',
  },
};

let currentTrack: TrackId = 'none';
let step = 0;
let nextNoteTime = 0;
let schedulerId: number | null = null;
let trackDef: TrackDef | null = null;

function semitone(root: number, n: number) {
  return root * Math.pow(2, n / 12);
}

function scheduleStep(s: number, time: number) {
  if (!ctx || !trackDef || !musicGain) return;
  const d = trackDef;
  const scale = d.scale;
  const deg = (i: number) => {
    if (i < 0) return 0;
    const oct = Math.floor(i / scale.length);
    return scale[((i % scale.length) + scale.length) % scale.length] + oct * 12;
  };
  // 低音
  const b = d.bass[s];
  if (b >= 0) {
    const t = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
    t.type = d.wave;
    t.frequency.setValueAtTime(semitone(d.root, deg(b)), time);
    f.type = 'lowpass'; f.frequency.setValueAtTime(900, time); f.Q.value = 6;
    g.gain.setValueAtTime(0.0001, time);
    g.gain.linearRampToValueAtTime(0.28, time + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, time + 0.24);
    t.connect(f); f.connect(g); g.connect(musicGain);
    t.start(time); t.stop(time + 0.3);
  }
  // 主奏
  const l = d.lead[s];
  if (l >= 0) {
    const t = ctx.createOscillator(), g = ctx.createGain();
    t.type = d.leadWave;
    t.frequency.setValueAtTime(semitone(d.root * 2, deg(l)), time);
    g.gain.setValueAtTime(0.0001, time);
    g.gain.linearRampToValueAtTime(0.1, time + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, time + 0.22);
    t.connect(g); g.connect(musicGain);
    t.start(time); t.stop(time + 0.28);
  }
  // 和聲短刺
  const st = d.stab[s];
  if (st >= 0) {
    [0, 4, 7].forEach((iv, i) => {
      const t = ctx!.createOscillator(), g = ctx!.createGain();
      t.type = 'sawtooth';
      t.frequency.setValueAtTime(semitone(d.root * 2, deg(st) + iv), time);
      g.gain.setValueAtTime(0.0001, time);
      g.gain.linearRampToValueAtTime(0.055 - i * 0.012, time + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, time + 0.16);
      t.connect(g); g.connect(musicGain!);
      t.start(time); t.stop(time + 0.2);
    });
  }
  // 鼓組
  const kick = d.drum === 'calm' ? [0, 8] : [0, 4, 8, 12];
  const snare = d.drum === 'calm' ? [4, 12] : [4, 12, s % 16 === 14 ? 14 : -1];
  const hat = d.drum === 'epic' ? [0, 2, 4, 6, 8, 10, 12, 14] : [2, 6, 10, 14];
  if (kick.includes(s)) {
    const t = ctx.createOscillator(), g = ctx.createGain();
    t.type = 'sine';
    t.frequency.setValueAtTime(150, time);
    t.frequency.exponentialRampToValueAtTime(42, time + 0.12);
    g.gain.setValueAtTime(0.5, time);
    g.gain.exponentialRampToValueAtTime(0.0001, time + 0.2);
    t.connect(g); g.connect(musicGain);
    t.start(time); t.stop(time + 0.24);
  }
  if (snare.includes(s) && noiseBuf) {
    const src = ctx.createBufferSource(); src.buffer = noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 1400;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.22, time);
    g.gain.exponentialRampToValueAtTime(0.0001, time + 0.14);
    src.connect(f); f.connect(g); g.connect(musicGain);
    src.start(time); src.stop(time + 0.18);
  }
  if (hat.includes(s) && noiseBuf) {
    const src = ctx.createBufferSource(); src.buffer = noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 7000;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.07, time);
    g.gain.exponentialRampToValueAtTime(0.0001, time + 0.05);
    src.connect(f); f.connect(g); g.connect(musicGain);
    src.start(time); src.stop(time + 0.08);
  }
}

function scheduler() {
  if (!ctx || !trackDef) return;
  const spb = 60 / trackDef.bpm / 4; // 16 分音符
  while (nextNoteTime < ctx.currentTime + 0.14) {
    const swing = trackDef.swing && step % 2 === 1 ? spb * trackDef.swing : 0;
    scheduleStep(step, nextNoteTime + swing);
    nextNoteTime += spb;
    step = (step + 1) % 16;
  }
}

export function playMusic(track: TrackId) {
  if (currentTrack === track) return;
  currentTrack = track;
  if (track === 'none') {
    if (schedulerId !== null) { clearInterval(schedulerId); schedulerId = null; }
    trackDef = null;
    return;
  }
  const c = initAudio();
  if (!c) return;
  trackDef = TRACKS[track];
  step = 0;
  nextNoteTime = c.currentTime + 0.08;
  if (schedulerId !== null) clearInterval(schedulerId);
  schedulerId = window.setInterval(scheduler, 25);
}

export function musicDuck(amount = 0.35, dur = 1.2) {
  if (!ctx || !musicGain) return;
  const t = ctx.currentTime;
  musicGain.gain.cancelScheduledValues(t);
  musicGain.gain.setValueAtTime(Audio.musicVol, t);
  musicGain.gain.linearRampToValueAtTime(Audio.musicVol * amount, t + 0.08);
  musicGain.gain.linearRampToValueAtTime(Audio.musicVol, t + dur);
}

export const isAudioStarted = () => started;
