/**
 * 奧義演出系統（Ultimate Director）
 * ------------------------------------------------------------------
 * 每位角色的奧義都是「一段完整的動畫演出」而非單純的傷害判定：
 *   第一幕：P5 風格 Cut-in（斜切面板、半色調、立繪滑入、漢字連打、速度線）
 *   第二幕：世界時間減速，角色執行獨有的多段华丽演出（各有專屬特效）
 *   第三幕：終結爆擊 —— 全屏衝擊、慢動作、白光、鏡頭震動、傷害結算
 * 六位角色六套完全不同的腳本，絕不共用特效。
 */
import type { Actor } from './actors';
import type { IWorld } from './combat';
import { areaDamage, damage } from './combat';
import type { HeroDef } from '../core/types';
import { DESIGN_H, DESIGN_W, worldToScreenY } from '../core/types';
import { Ease, TAU, clamp, lerp, rand } from '../core/util';
import { drawCell, getHalftone, imgReady } from './art';

interface Step { at: number; fn: () => void; done: boolean }

export abstract class UltScript {
  t = 0;
  dur = 6;
  steps: Step[] = [];
  cutinDur = 1.55;
  protected w: IWorld;
  protected p: Actor;
  protected hero: HeroDef;
  protected shakeAmt = 0;

  constructor(w: IWorld, p: Actor, hero: HeroDef) {
    this.w = w; this.p = p; this.hero = hero;
    this.build();
  }
  protected abstract build(): void;
  onUpdate(_dt: number) {}
  onRender(_ctx: CanvasRenderingContext2D) {}

  at(time: number, fn: () => void) { this.steps.push({ at: time, fn, done: false }); }

  start() {
    this.w.screen.bars = 1;
    this.w.screen.timeScale = 0.05;
    this.w.screen.timeScaleTarget = 0.05;
    this.w.screen.timeScaleReturn = 999;
    this.p.invuln = 99;
    this.w.sfx('ult', 1);
    this.w.screen.flash(this.hero.palette.aura, 0.6, 0.5);
  }

  update(dt: number) {
    this.t += dt;
    for (const s of this.steps) {
      if (!s.done && this.t >= s.at) { s.fn(); s.done = true; }
    }
    // Cut-in 結束後回到慢動作
    if (this.t > this.cutinDur && this.w.screen.timeScaleTarget < 0.3) {
      this.w.screen.timeScaleTarget = 0.42;
      this.w.screen.timeScaleReturn = 999;
    }
    this.onUpdate(dt);
    return this.t >= this.dur;
  }

  finish() {
    this.w.screen.timeScaleTarget = 1;
    this.w.screen.timeScaleReturn = 0.8;
    this.w.screen.bars = 0;
    this.p.invuln = Math.min(this.p.invuln, 0.6);
  }

  /** 對全場敵人造成傷害（可指定半徑與浮空） */
  protected hitAll(base: number, opts: { lift?: number; kb?: number; radius?: number; silent?: boolean } = {}) {
    const w = this.w;
    const r = opts.radius ?? 9999;
    for (const e of w.actors) {
      if (e.dead) continue;
      const d = Math.hypot(e.x - this.p.x, (e.y - this.p.y) * 1.8);
      if (d > r) continue;
      damage(e, base, w, {
        attacker: this.p,
        kb: { x: (e.x > this.p.x ? 1 : -1) * (opts.kb ?? 120), y: rand(-40, 40), z: opts.lift ?? 180 },
        launch: (opts.lift ?? 0) > 100,
        hitstop: 0, shake: 0, noFx: opts.silent, silent: opts.silent,
      });
      e.hitstun = Math.max(e.hitstun, 0.2);
      if ((opts.lift ?? 0) > 60) { e.grounded = false; e.vz = Math.max(e.vz, opts.lift!); }
    }
  }

  /** 把全場敵人吊在空中（演出用） */
  protected liftAll(z = 220) {
    for (const e of this.w.actors) {
      if (e.dead || e.def?.rank === '首領') continue;
      e.grounded = false;
      e.launched = true;
      e.vz = Math.max(e.vz, 180);
      e.z = Math.max(e.z, z * rand(0.6, 1.2));
      e.hitstun = Math.max(e.hitstun, 0.8);
    }
  }

  /* ------------------------- Cut-in 繪製 ------------------------- */
  protected renderCutin(ctx: CanvasRenderingContext2D) {
    const t = this.t;
    if (t > this.cutinDur + 0.7) return;
    const hero = this.hero;
    const P = this.cutinDur;
    const k = clamp(t / P, 0, 1);
    const out = clamp((t - P) / 0.7, 0, 1);
    const alpha = out > 0 ? 1 - Ease.inQuad(out) : 1;
    const c1 = hero.palette.main, c2 = hero.palette.trim, aura = hero.palette.aura;

    ctx.save();
    ctx.globalAlpha = alpha;

    // 背景壓暗 + 斜向色塊
    ctx.fillStyle = 'rgba(6,3,10,0.72)';
    ctx.fillRect(0, 0, DESIGN_W, DESIGN_H);

    // 放射速度線
    ctx.save();
    ctx.translate(DESIGN_W * 0.5, DESIGN_H * 0.52);
    ctx.globalCompositeOperation = 'lighter';
    const rays = 46;
    for (let i = 0; i < rays; i++) {
      const a = (i / rays) * TAU + t * 0.35;
      const len = 900 * Ease.outExpo(k);
      ctx.strokeStyle = i % 3 === 0 ? aura : 'rgba(255,255,255,0.16)';
      ctx.globalAlpha = (i % 3 === 0 ? 0.3 : 0.12) * alpha * k;
      ctx.lineWidth = i % 3 === 0 ? 7 : 2;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 120, Math.sin(a) * 120);
      ctx.lineTo(Math.cos(a) * len, Math.sin(a) * len);
      ctx.stroke();
    }
    ctx.restore();

    // 斜切面板（左下→右上）
    const slide = Ease.outExpo(k);
    ctx.save();
    ctx.translate(DESIGN_W * 0.5, DESIGN_H * 0.5);
    ctx.rotate(-0.16);
    const pw = DESIGN_W * 1.5;
    const ph = 300;
    const off = (1 - slide) * DESIGN_W * 1.2;
    ctx.globalAlpha = 0.95 * alpha;
    ctx.fillStyle = c1;
    ctx.fillRect(-pw / 2 + off, -ph / 2, pw, ph);
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.fillRect(-pw / 2 + off, ph / 2 - 26, pw, 26);
    // 半色調
    const ht = getHalftone();
    if (ht) {
      ctx.globalAlpha = 0.4 * alpha;
      ctx.fillStyle = ht;
      ctx.fillRect(-pw / 2 + off, -ph / 2, pw, ph);
    }
    ctx.globalAlpha = alpha;
    ctx.fillStyle = c2;
    ctx.fillRect(-pw / 2 + off, -ph / 2 - 12, pw, 12);
    ctx.restore();

    // 立繪（圖集裁切，滑入 + 微縮放）
    if (imgReady('heroAtlas')) {
      const ph2 = 460;
      const px = DESIGN_W * 0.62 - Ease.outBack(clamp(k * 1.25, 0, 1)) * 0 + lerp(560, 0, Ease.outBack(clamp(k * 1.2, 0, 1)));
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(px, DESIGN_H * 0.5);
      ctx.rotate(-0.05);
      const bob = Math.sin(t * 7) * 4;
      // 立繪背板
      ctx.fillStyle = 'rgba(8,4,12,0.9)';
      ctx.beginPath();
      ctx.moveTo(-210, -ph2 / 2 + bob); ctx.lineTo(210, -ph2 / 2 - 40 + bob);
      ctx.lineTo(250, ph2 / 2 - 40 + bob); ctx.lineTo(-170, ph2 / 2 + bob);
      ctx.closePath(); ctx.fill();
      ctx.clip();
      drawCell(ctx, 'heroAtlas', hero.atlas, -215, -ph2 / 2 - 20 + bob, 470, ph2 + 20, { scale: 1.06 });
      ctx.restore();
      // 立繪邊緣描光
      ctx.save();
      ctx.globalAlpha = alpha * 0.8;
      ctx.strokeStyle = c2;
      ctx.lineWidth = 5;
      ctx.translate(px, DESIGN_H * 0.5);
      ctx.rotate(-0.05);
      ctx.beginPath();
      ctx.moveTo(-210, -ph2 / 2 + bob); ctx.lineTo(210, -ph2 / 2 - 40 + bob);
      ctx.lineTo(250, ph2 / 2 - 40 + bob); ctx.lineTo(-170, ph2 / 2 + bob);
      ctx.closePath(); ctx.stroke();
      ctx.restore();
    }

    // 漢字連打
    const kanji = hero.ultKanji;
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (let i = 0; i < kanji.length; i++) {
      const st = 0.16 + i * 0.13;
      if (t < st) continue;
      const kt = clamp((t - st) / 0.42, 0, 1);
      const sc = lerp(2.6, 1, Ease.outBack(kt));
      const x = 150 + i * 118;
      const y = 168 + (i % 2 === 0 ? 0 : 34);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(-0.1 + Math.sin(i * 2.1) * 0.05);
      ctx.scale(sc, sc);
      ctx.globalAlpha = alpha * Ease.outQuad(kt);
      ctx.font = `900 78px "Noto Sans TC", "PingFang TC", sans-serif`;
      ctx.lineWidth = 12;
      ctx.strokeStyle = '#0b0710';
      ctx.strokeText(kanji[i], 0, 0);
      const g = ctx.createLinearGradient(0, -44, 0, 44);
      g.addColorStop(0, '#fff8e0');
      g.addColorStop(0.45, c2);
      g.addColorStop(1, c1);
      ctx.fillStyle = g;
      ctx.fillText(kanji[i], 0, 0);
      ctx.restore();
    }
    ctx.restore();

    // 奧義名稱列
    if (t > 0.5) {
      const nk = clamp((t - 0.5) / 0.5, 0, 1);
      ctx.save();
      ctx.globalAlpha = alpha * Ease.outQuad(nk);
      ctx.translate(0, lerp(40, 0, Ease.outExpo(nk)));
      ctx.fillStyle = 'rgba(8,4,12,0.85)';
      ctx.beginPath();
      ctx.moveTo(60, DESIGN_H - 150); ctx.lineTo(700, DESIGN_H - 150);
      ctx.lineTo(660, DESIGN_H - 92); ctx.lineTo(20, DESIGN_H - 92);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = c2;
      ctx.fillRect(20, DESIGN_H - 152, 680, 4);
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.font = `900 34px "Noto Sans TC", sans-serif`;
      ctx.fillStyle = '#fff8e8';
      ctx.fillText(hero.ultName, 78, DESIGN_H - 120);
      ctx.font = `700 15px "Noto Sans TC", sans-serif`;
      ctx.fillStyle = aura;
      ctx.fillText(`${hero.name} · ${hero.title}`, 80, DESIGN_H - 140 + 44);
      ctx.restore();
    }

    // 掃描線閃光
    if (k < 1) {
      ctx.globalCompositeOperation = 'lighter';
      const sy = (1 - k) * DESIGN_H * 1.4 - DESIGN_H * 0.2;
      const g = ctx.createLinearGradient(0, sy - 60, 0, sy + 60);
      g.addColorStop(0, 'rgba(255,255,255,0)');
      g.addColorStop(0.5, 'rgba(255,255,255,0.5)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, sy - 60, DESIGN_W, 120);
    }
    ctx.restore();
  }

  render(ctx: CanvasRenderingContext2D) {
    this.onRender(ctx);
    this.renderCutin(ctx);
  }
}

/* ================================================================== */
/* 一號・燐 —— 焚天百裂蹴                                              */
/* ================================================================== */
export class UltLin extends UltScript {
  private kicks: { x: number; y: number; t: number }[] = [];
  protected build() {
    this.dur = 6.6;
    this.at(1.5, () => {
      const w = this.w;
      w.screen.flash('#ff2d40', 0.7, 0.4);
      w.sfx('bossRoar', 0.8, 1.3);
      this.liftAll(260);
      this.p.vz = 1500; this.p.grounded = false;
      // 規劃 24 次墜踢位置
      const list = w.actors.filter((e) => !e.dead);
      for (let i = 0; i < 24; i++) {
        const tgt = list.length ? list[i % list.length] : null;
        this.kicks.push({
          x: tgt ? tgt.x + rand(-40, 40) : this.p.x + rand(-520, 520),
          y: tgt ? tgt.y + rand(-24, 24) : rand(-20, 90),
          t: 1.75 + i * 0.1,
        });
      }
    });
    for (let i = 0; i < 24; i++) {
      this.at(1.75 + i * 0.1, () => {
        const k = this.kicks[i];
        if (!k) return;
        const w = this.w;
        this.p.x = k.x; this.p.y = k.y; this.p.z = 210;
        this.p.facing = i % 2 === 0 ? 1 : -1;
        w.fx.impact(k.x, k.y, 150, { elem: 'flame', scale: 2.4 });
        w.fx.pillar(k.x, k.y, { color: '#ff6a1a', color2: '#ffe08a', w: 130, h: 900, dur: 0.6 });
        w.fx.ring(k.x, k.y, 20, { color: '#ffc93c', w: 340, h: 110, dur: 0.5 });
        w.ps.emit({ kind: 'ember', x: k.x, y: k.y, z: 120, count: Math.round(26 * w.quality), speed: [140, 620], vz: [-100, 500], life: [0.3, 0.9], size: [3, 12], color: '#ffb03a', color2: '#ff2d40', additive: true, grav: 500 });
        this.hitAll(20, { lift: 240, kb: 60, silent: true });
        w.shake(14);
        w.sfx('hitHeavy', 0.5, rand(0.9, 1.5));
        if (i % 6 === 5) w.sfx('explode', 0.6, 1.3);
      });
    }
    // 巨猿焰相
    this.at(4.3, () => {
      const w = this.w;
      w.screen.slowmo(0.25, 1.6);
      w.sfx('charge', 1, 0.55);
      this.p.z = 300;
    });
    this.at(5.2, () => {
      const w = this.w;
      this.p.z = 60;
      w.screen.flash('#fff0c0', 0.95, 0.8);
      w.shake(64);
      w.sfx('explode', 1.2, 0.55);
      w.sfx('bossRoar', 1, 0.7);
      w.fx.ring(this.p.x, this.p.y, 20, { color: '#ff2d40', w: 1500, h: 480, dur: 1.2 });
      w.fx.ring(this.p.x, this.p.y, 20, { color: '#ffc93c', w: 1100, h: 360, dur: 1 });
      w.fx.crack(this.p.x, this.p.y, { color: '#ff6a1a', scale: 4 });
      for (let i = 0; i < 12; i++) {
        w.fx.pillar(this.p.x + Math.cos((i / 12) * TAU) * (180 + i * 40), this.p.y + Math.sin((i / 12) * TAU) * 60, { color: '#ff6a1a', color2: '#ffe08a', w: 110, h: 1200, dur: 1.4 });
      }
      w.ps.emit({ kind: 'ember', x: this.p.x, y: this.p.y, z: 40, count: Math.round(220 * w.quality), speed: [200, 1200], vz: [100, 1100], life: [0.6, 2], size: [4, 18], color: '#ffb03a', color2: '#ff2d40', additive: true, grav: 260 });
      this.hitAll(150, { lift: 700, kb: 700 });
      areaDamage(w, this.p.x, this.p.y, 900, 90);
    });
  }
  private apePhase = 0;
  onUpdate(dt: number) {
    if (this.t > 4.3 && this.t < 5.3) this.apePhase = clamp((this.t - 4.3) / 1, 0, 1);
    else if (this.t >= 5.3) this.apePhase = Math.max(0, this.apePhase - dt * 2);
    if (this.t > 1.7 && this.t < 4.3) {
      this.p.vx = 0; this.p.vy = 0; this.p.vz = 0;
      this.p.grounded = false;
    }
  }
  onRender(ctx: CanvasRenderingContext2D) {
    if (this.apePhase <= 0.01) return;
    const w = this.w;
    const cam = w.camera;
    const k = this.apePhase;
    const cx = this.p.x - cam.x + DESIGN_W / 2;
    const cy = 300;
    ctx.save();
    ctx.globalAlpha = clamp(k, 0, 1) * 0.92;
    ctx.globalCompositeOperation = 'lighter';
    // 巨猿焰相：程序化剪影
    const S = 1 + k * 0.6;
    ctx.translate(cx, cy);
    ctx.scale(S * 1.0, S);
    const g = ctx.createRadialGradient(0, 0, 20, 0, 0, 460);
    g.addColorStop(0, 'rgba(255,220,140,0.85)');
    g.addColorStop(0.4, 'rgba(255,90,26,0.5)');
    g.addColorStop(1, 'rgba(255,45,64,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, 0, 460, 0, TAU); ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = 'rgba(30,6,10,0.9)';
    // 頭
    ctx.beginPath(); ctx.ellipse(0, -120, 130, 118, 0, 0, TAU); ctx.fill();
    // 身
    ctx.beginPath(); ctx.ellipse(0, 90, 210, 190, 0, 0, TAU); ctx.fill();
    // 双臂
    ctx.beginPath(); ctx.ellipse(-230, 20, 70, 160, 0.4, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(230, -30 - k * 120, 74, 170, -0.5 - k * 0.5, 0, TAU); ctx.fill();
    // 眼
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = '#ffe08a';
    ctx.beginPath(); ctx.ellipse(-48, -132, 26, 14, -0.2, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(48, -132, 26, 14, 0.2, 0, TAU); ctx.fill();
    // 焰毛
    ctx.strokeStyle = 'rgba(255,120,26,0.7)';
    ctx.lineWidth = 10;
    for (let i = 0; i < 18; i++) {
      const a = -Math.PI * 0.85 + (i / 17) * Math.PI * 0.7;
      const r1 = 132, r2 = 190 + Math.sin(this.t * 12 + i) * 34;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * r1, -120 + Math.sin(a) * r1);
      ctx.lineTo(Math.cos(a) * r2, -120 + Math.sin(a) * r2);
      ctx.stroke();
    }
    ctx.restore();
  }
}

/* ================================================================== */
/* 二號・磐牙 —— 嶽崩千鈞墜                                            */
/* ================================================================== */
export class UltPanya extends UltScript {
  private mtnY = -1400;
  private impact = 0;
  protected build() {
    this.dur = 6.2;
    this.at(1.5, () => {
      const w = this.w;
      this.p.vz = 1900; this.p.grounded = false;
      w.sfx('jump', 1, 0.5);
      w.screen.flash('#e0a558', 0.5, 0.4);
    });
    this.at(2.6, () => { this.w.sfx('charge', 1, 0.5); });
    this.at(3.5, () => {
      const w = this.w;
      this.impact = 1;
      this.p.z = 0; this.p.vz = 0; this.p.grounded = true;
      w.screen.flash('#ffe6b0', 0.95, 0.7);
      w.shake(70);
      w.sfx('explode', 1.3, 0.5);
      w.screen.radial = 1;
      // 大地網格碎裂
      for (let i = 0; i < 16; i++) {
        w.fx.crack(this.p.x + rand(-700, 700), rand(-40, 120), { color: '#e0a558', scale: rand(1.6, 3.2), dur: 3 });
      }
      for (let i = 0; i < 10; i++) {
        w.fx.pillar(this.p.x + (i - 5) * 130 + rand(-30, 30), rand(-30, 110), { color: '#c8a05a', color2: '#ffe6b0', w: 90, h: 700, dur: 1.6 });
      }
      w.fx.ring(this.p.x, this.p.y, 10, { color: '#e0a558', w: 1800, h: 560, dur: 1.3 });
      w.fx.wave(this.p.x, this.p.y, { color: '#c8a05a', color2: '#8a6a3a', dir: 1, w: 1400, h: 190, dur: 1.2 });
      w.fx.wave(this.p.x, this.p.y, { color: '#c8a05a', color2: '#8a6a3a', dir: -1, w: 1400, h: 190, dur: 1.2 });
      w.ps.emit({ kind: 'debris', x: this.p.x, y: this.p.y, z: 10, count: Math.round(180 * w.quality), speed: [200, 1000], vz: [300, 1400], life: [0.8, 2.2], size: [5, 26], color: '#8a7a62', color2: '#3a2f24', grav: 1500 });
      w.ps.emit({ kind: 'smoke', x: this.p.x, y: this.p.y, z: 10, count: Math.round(70 * w.quality), speed: [80, 420], vz: [40, 320], life: [1, 2.4], size: [40, 110], color: '#6a5a48', grav: -30 });
      this.hitAll(190, { lift: 900, kb: 620 });
      areaDamage(w, this.p.x, this.p.y, 1000, 120);
    });
    for (let i = 0; i < 5; i++) {
      this.at(3.8 + i * 0.22, () => {
        const w = this.w;
        const x = this.p.x + rand(-800, 800);
        w.fx.pillar(x, rand(-30, 110), { color: '#ff8a3a', color2: '#ffc93c', w: 120, h: 900, dur: 1.2 });
        w.fx.ring(x, 40, 10, { color: '#e0a558', w: 420, h: 140, dur: 0.8 });
        w.shake(30);
        w.sfx('explode', 0.8, rand(0.6, 0.9));
        areaDamage(w, x, 40, 260, 60);
      });
    }
  }
  onUpdate(dt: number) {
    if (this.t > 1.5 && this.t < 3.5) {
      this.p.vx = 0; this.p.vy = 0;
      this.p.z = lerp(this.p.z, 900, 1 - Math.exp(-2.4 * dt));
      this.p.vz = 0;
      this.mtnY = lerp(this.mtnY, -260, 1 - Math.exp(-1.5 * dt));
    } else if (this.t >= 3.5) {
      this.mtnY = lerp(this.mtnY, 2000, 1 - Math.exp(-3 * dt));
      this.impact = Math.max(0, this.impact - dt * 0.6);
    }
  }
  onRender(ctx: CanvasRenderingContext2D) {
    if (this.t < 1.4) return;
    const w = this.w, cam = w.camera;
    const cx = this.p.x - cam.x + DESIGN_W / 2;
    ctx.save();
    const k = clamp((this.t - 1.4) / 1.2, 0, 1);
    ctx.globalAlpha = 0.95 * (this.impact > 0 ? clamp(this.impact * 2, 0, 1) : k);
    ctx.translate(cx, this.mtnY);
    // 巨嶽之影
    const g = ctx.createLinearGradient(0, -620, 0, 260);
    g.addColorStop(0, '#3a2f24'); g.addColorStop(0.6, '#6a5a44'); g.addColorStop(1, '#e0a558');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(-520, 260);
    ctx.lineTo(-360, -120); ctx.lineTo(-220, 40); ctx.lineTo(-60, -420);
    ctx.lineTo(120, -160); ctx.lineTo(300, -520); ctx.lineTo(430, -60);
    ctx.lineTo(560, 260);
    ctx.closePath(); ctx.fill();
    // 岩漿裂縫
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = '#ff6a1a'; ctx.lineWidth = 7;
    for (let i = 0; i < 9; i++) {
      ctx.beginPath();
      const x0 = -420 + i * 100;
      ctx.moveTo(x0, 240);
      ctx.lineTo(x0 + Math.sin(i * 3.1) * 60, -60 - i * 22);
      ctx.lineTo(x0 + Math.cos(i * 2.3) * 90, -260 - i * 18);
      ctx.stroke();
    }
    ctx.globalCompositeOperation = 'source-over';
    ctx.strokeStyle = '#ffe6b0'; ctx.lineWidth = 5;
    ctx.stroke();
    ctx.restore();
  }
}

/* ================================================================== */
/* 三號・漣 —— 滄瀾萬刃雨                                              */
/* ================================================================== */
export class UltLian extends UltScript {
  private blades: { x: number; y: number; z: number; vy: number; r: number; hit: boolean }[] = [];
  private waveX = -1600;
  protected build() {
    this.dur = 6.8;
    this.at(1.5, () => {
      const w = this.w;
      w.sfx('water', 1, 0.6);
      w.screen.flash('#4fd8ff', 0.5, 0.6);
      this.liftAll(200);
      for (let i = 0; i < 90; i++) {
        this.blades.push({
          x: this.p.x + rand(-1000, 1000), y: rand(-60, 130), z: rand(600, 1600),
          vy: -rand(700, 1200), r: rand(0, TAU), hit: false,
        });
      }
    });
    for (let i = 0; i < 8; i++) {
      this.at(1.9 + i * 0.3, () => {
        const w = this.w;
        w.sfx('water', 0.5, rand(0.8, 1.4));
        this.hitAll(16, { lift: 160, kb: 40, silent: true });
      });
    }
    this.at(4.6, () => {
      const w = this.w;
      this.waveX = this.p.x - 1400;
      w.sfx('bossRoar', 0.9, 1.5);
      w.screen.slowmo(0.3, 1.4);
    });
    this.at(5.4, () => {
      const w = this.w;
      w.screen.flash('#eafcff', 0.9, 0.7);
      w.shake(56);
      w.sfx('explode', 1.1, 1.4);
      this.hitAll(170, { lift: 800, kb: 900 });
      areaDamage(w, this.p.x, this.p.y, 1200, 100);
      w.fx.ring(this.p.x, this.p.y, 20, { color: '#7fe9ff', w: 1700, h: 520, dur: 1.2 });
      for (let i = 0; i < 10; i++) {
        w.fx.pillar(this.p.x + rand(-700, 700), rand(-30, 110), { color: '#4fd8ff', color2: '#eafcff', w: 100, h: 1000, dur: 1.3 });
      }
    });
  }
  onUpdate(dt: number) {
    const w = this.w;
    for (const b of this.blades) {
      if (b.hit) continue;
      b.z += b.vy * dt;
      b.r += dt * 9;
      if (b.z <= 20) {
        b.hit = true;
        w.fx.impact(b.x, b.y, 20, { elem: 'water', scale: 1.4 });
        w.ps.emit({ kind: 'drop', x: b.x, y: b.y, z: 16, count: Math.round(10 * w.quality), speed: [80, 360], vz: [120, 500], life: [0.3, 0.8], size: [3, 9], color: '#7fe9ff', additive: true, grav: 900 });
        areaDamage(w, b.x, b.y, 110, 22);
        w.sfx('hit', 0.24, rand(1.1, 1.7));
      }
    }
    if (this.t > 4.6) {
      this.waveX += dt * 1500;
      if (this.t < 5.4 && w.quality > 0.3) {
        w.ps.emit({ kind: 'drop', x: this.waveX + rand(-60, 60), y: rand(-40, 120), z: rand(20, 320), count: 4, speed: [40, 200], vz: [40, 260], life: [0.4, 1], size: [4, 12], color: '#7fe9ff', additive: true, grav: 500 });
      }
      for (const e of w.actors) {
        if (e.dead) continue;
        if (Math.abs(e.x - this.waveX) < 120 && e.hitstun <= 0.1) {
          e.hitstun = 0.4; e.vz = Math.max(e.vz, 420); e.vx += 480; e.grounded = false;
        }
      }
    }
    if (this.t > 1.5 && this.t < 4.6) { this.p.vz = 0; this.p.z = lerp(this.p.z, 140, 1 - Math.exp(-3 * dt)); }
  }
  onRender(ctx: CanvasRenderingContext2D) {
    if (this.t < 1.4) return;
    const w = this.w, cam = w.camera;
    const k = clamp((this.t - 1.4) / 0.8, 0, 1);
    ctx.save();
    // 倒懸之海
    ctx.globalAlpha = 0.8 * k * (this.t < 5 ? 1 : clamp((6 - this.t) / 1, 0, 1));
    const g = ctx.createLinearGradient(0, -60, 0, 300);
    g.addColorStop(0, 'rgba(31,111,139,0.95)');
    g.addColorStop(0.6, 'rgba(79,216,255,0.55)');
    g.addColorStop(1, 'rgba(234,252,255,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    for (let x = 0; x <= DESIGN_W; x += 40) {
      ctx.lineTo(x, 120 + Math.sin(x * 0.012 + this.t * 2.2) * 26 + Math.sin(x * 0.03 - this.t * 3) * 12);
    }
    ctx.lineTo(DESIGN_W, 0); ctx.closePath(); ctx.fill();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = 'rgba(234,252,255,0.6)'; ctx.lineWidth = 3;
    ctx.beginPath();
    for (let x = 0; x <= DESIGN_W; x += 24) {
      const y = 120 + Math.sin(x * 0.012 + this.t * 2.2) * 26 + Math.sin(x * 0.03 - this.t * 3) * 12;
      x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.restore();

    // 水刃
    ctx.save();
    for (const b of this.blades) {
      if (b.hit) continue;
      const sx = b.x - cam.x + DESIGN_W / 2;
      const sy = worldToScreenY(b.y, b.z);
      if (sx < -60 || sx > DESIGN_W + 60) continue;
      ctx.save();
      ctx.translate(sx, sy);
      ctx.rotate(b.r);
      ctx.globalCompositeOperation = 'lighter';
      const gg = ctx.createLinearGradient(-26, 0, 26, 0);
      gg.addColorStop(0, 'rgba(127,233,255,0)');
      gg.addColorStop(0.5, 'rgba(234,252,255,0.95)');
      gg.addColorStop(1, 'rgba(79,216,255,0)');
      ctx.fillStyle = gg;
      ctx.beginPath();
      ctx.moveTo(-30, 0); ctx.quadraticCurveTo(0, -16, 30, 0);
      ctx.quadraticCurveTo(0, 16, -30, 0);
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();

    // 海嘯
    if (this.t > 4.6) {
      const sx = this.waveX - cam.x + DESIGN_W / 2;
      ctx.save();
      ctx.globalAlpha = clamp((6.4 - this.t) / 0.8, 0, 1);
      const h = 460;
      const g2 = ctx.createLinearGradient(sx - 400, 0, sx + 200, 0);
      g2.addColorStop(0, 'rgba(31,111,139,0.1)');
      g2.addColorStop(0.7, 'rgba(79,216,255,0.85)');
      g2.addColorStop(1, 'rgba(234,252,255,0.95)');
      ctx.fillStyle = g2;
      ctx.beginPath();
      ctx.moveTo(sx - 620, DESIGN_H);
      for (let i = 0; i <= 20; i++) {
        const px = sx - 620 + i * 40;
        const py = 200 - Math.sin(i * 0.5 + this.t * 6) * 40 * (i / 20) + (1 - i / 20) * 200;
        ctx.lineTo(px, py);
      }
      ctx.lineTo(sx + 200, DESIGN_H);
      ctx.closePath(); ctx.fill();
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = 'rgba(234,252,255,0.5)';
      for (let i = 0; i < 24; i++) {
        const px = sx - 500 + i * 30 + Math.sin(this.t * 8 + i) * 12;
        const py = 220 + Math.sin(i * 1.3 + this.t * 5) * 90;
        ctx.beginPath(); ctx.arc(px, py, 12 + Math.sin(i + this.t * 6) * 6, 0, TAU); ctx.fill();
      }
      ctx.restore();
      void h;
    }
  }
}

/* ================================================================== */
/* 四號・霜翎 —— 九霄鶴舞斬                                            */
/* ================================================================== */
export class UltShuang extends UltScript {
  private slashes: { x: number; y: number; a: number; len: number; born: number }[] = [];
  private bloom = 0;
  protected build() {
    this.dur = 6;
    this.at(1.5, () => {
      const w = this.w;
      w.screen.flash('#ffffff', 0.85, 0.6);
      w.sfx('wind', 1, 0.7);
      this.liftAll(240);
      w.ps.emit({ kind: 'feather', x: this.p.x, y: this.p.y, z: 200, count: Math.round(120 * w.quality), speed: [60, 420], vz: [-60, 260], life: [1.5, 3.5], size: [6, 18], color: '#eaf6ff', color2: '#9fe8ff', grav: 40, drag: 0.8 });
    });
    for (let i = 0; i < 14; i++) {
      this.at(1.85 + i * 0.16, () => {
        const w = this.w;
        const list = w.actors.filter((e) => !e.dead);
        const tgt = list.length ? list[i % list.length] : null;
        const x = tgt ? tgt.x + rand(-30, 30) : this.p.x + rand(-600, 600);
        const y = tgt ? tgt.y : rand(-20, 100);
        this.p.x = x; this.p.y = y; this.p.z = rand(120, 300);
        this.p.facing = i % 2 === 0 ? 1 : -1;
        const a = rand(-0.9, 0.9);
        this.slashes.push({ x, y, a, len: rand(220, 380), born: this.t });
        w.fx.cross(x, y, this.p.z, { color: '#ffffff', color2: '#9fe8ff', scale: 1.6, rot: a });
        this.hitAll(15, { lift: 200, kb: 40, silent: true });
        w.sfx('hit', 0.4, rand(1.2, 2));
        w.shake(8);
      });
    }
    this.at(4.4, () => {
      const w = this.w;
      this.p.z = 340;
      w.sfx('charge', 1, 1.6);
      w.screen.slowmo(0.2, 1.2);
    });
    this.at(4.9, () => {
      const w = this.w;
      this.bloom = 1;
      w.screen.flash('#ffffff', 1, 0.9);
      w.shake(50);
      w.sfx('hitCrit', 1.2, 0.7);
      w.sfx('wind', 1, 0.5);
      for (const s of this.slashes) {
        w.fx.cross(s.x, s.y, 160, { color: '#ffffff', color2: '#7fe9ff', scale: 2.4, rot: s.a });
        w.fx.ring(s.x, s.y, 30, { color: '#eaf6ff', w: 300, h: 100, dur: 0.6 });
        areaDamage(w, s.x, s.y, 200, 46);
      }
      this.hitAll(150, { lift: 700, kb: 620 });
      w.fx.ring(this.p.x, this.p.y, 120, { color: '#ffffff', w: 1600, h: 500, dur: 1.1 });
    });
  }
  onUpdate(dt: number) {
    this.bloom = Math.max(0, this.bloom - dt * 1.4);
    if (this.t > 1.8 && this.t < 4.4) { this.p.vz = 0; this.p.vx = 0; this.p.vy = 0; this.p.grounded = false; }
  }
  onRender(ctx: CanvasRenderingContext2D) {
    const w = this.w, cam = w.camera;
    ctx.save();
    // 殘留的斬線（延遲綻放）
    ctx.globalCompositeOperation = 'lighter';
    for (const s of this.slashes) {
      const age = this.t - s.born;
      const sx = s.x - cam.x + DESIGN_W / 2;
      const sy = worldToScreenY(s.y, 160);
      const grow = s.born < 4.9 ? clamp(age * 4, 0, 1) : 1;
      const a = s.born < 4.9 ? 0.25 + this.bloom * 0.75 : clamp(1.6 - age * 0.6, 0, 1);
      ctx.save();
      ctx.translate(sx, sy);
      ctx.rotate(s.a);
      ctx.globalAlpha = a;
      const L = s.len * grow * (1 + this.bloom * 0.6);
      const g = ctx.createLinearGradient(-L, 0, L, 0);
      g.addColorStop(0, 'rgba(255,255,255,0)');
      g.addColorStop(0.5, this.bloom > 0.1 ? 'rgba(255,255,255,0.95)' : 'rgba(159,232,255,0.7)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.strokeStyle = g;
      ctx.lineWidth = this.bloom > 0.1 ? 22 : 5;
      ctx.beginPath(); ctx.moveTo(-L, 0); ctx.lineTo(L, 0); ctx.stroke();
      ctx.restore();
    }
    // 巨鶴剪影掠過天空
    if (this.t > 1.4 && this.t < 5.2) {
      const k = clamp((this.t - 1.4) / 3.8, 0, 1);
      const cx = lerp(-400, DESIGN_W + 500, Ease.inOutQuad(k));
      const cy = 150 + Math.sin(k * Math.PI) * -60;
      ctx.globalAlpha = 0.5 * (1 - Math.abs(k - 0.5) * 0.6);
      ctx.save();
      ctx.translate(cx, cy);
      ctx.scale(1.5, 1.5);
      ctx.fillStyle = '#ffffff';
      const flap = Math.sin(this.t * 9) * 0.6;
      ctx.beginPath();
      ctx.ellipse(0, 0, 90, 26, 0, 0, TAU); ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-10, -6);
      ctx.quadraticCurveTo(-120, -90 - flap * 70, -230, -20 - flap * 40);
      ctx.quadraticCurveTo(-120, -20, -10, 8);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(10, -6);
      ctx.quadraticCurveTo(120, -90 - flap * 70, 230, -20 - flap * 40);
      ctx.quadraticCurveTo(120, -20, 10, 8);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(80, -4); ctx.lineTo(150, -16); ctx.lineTo(84, 8); ctx.fill();
      ctx.restore();
    }
    ctx.restore();
  }
}

/* ================================================================== */
/* 五號・玄角 —— 角抵山河破                                            */
/* ================================================================== */
export class UltXuan extends UltScript {
  private phase: 'crouch' | 'charge' | 'quake' = 'crouch';
  private cracks: { x: number; y: number; t: number }[] = [];
  protected build() {
    this.dur = 6.2;
    this.at(1.5, () => {
      const w = this.w;
      this.phase = 'crouch';
      this.p.x = 60; this.p.z = 0;
      w.sfx('charge', 1, 0.5);
      w.screen.flash('#ff3b52', 0.45, 0.5);
      this.liftAll(160);
    });
    this.at(2.3, () => {
      this.phase = 'charge';
      this.w.sfx('dash', 1, 0.4);
      this.w.sfx('bossRoar', 0.9, 0.8);
    });
    this.at(4.4, () => {
      const w = this.w;
      this.phase = 'quake';
      this.p.x = w.arenaW - 90;
      w.screen.flash('#ffd0d8', 0.9, 0.6);
      w.shake(72);
      w.sfx('explode', 1.3, 0.5);
      w.screen.radial = 1;
      w.fx.ring(this.p.x, this.p.y, 10, { color: '#ff3b52', w: 1800, h: 560, dur: 1.3 });
      this.hitAll(210, { lift: 860, kb: 760 });
      areaDamage(w, this.p.x, this.p.y, 1100, 130);
    });
    for (let i = 0; i < 9; i++) {
      this.at(4.6 + i * 0.14, () => {
        const w = this.w;
        const x = 120 + i * ((w.arenaW - 240) / 8);
        this.cracks.push({ x, y: rand(-20, 110), t: this.t });
        w.fx.pillar(x, rand(-20, 110), { color: '#ff3b52', color2: '#ffc93c', w: 130, h: 1000, dur: 1.3 });
        w.fx.crack(x, rand(-20, 110), { color: '#ff8090', scale: 2.6, dur: 2.6 });
        w.shake(28);
        w.sfx('explode', 0.7, rand(0.6, 1));
        areaDamage(w, x, 40, 240, 58);
      });
    }
  }
  onUpdate(dt: number) {
    const w = this.w;
    if (this.phase === 'charge') {
      this.p.x = Math.min(w.arenaW - 90, this.p.x + dt * 1500);
      this.p.z = 0; this.p.vz = 0; this.p.grounded = true;
      this.p.facing = 1;
      w.fx.ghost(this.p.x - 40, this.p.y, 0, { color: '#ff3b52', scale: 1.6, dir: 1 });
      w.ps.emit({ kind: 'ember', x: this.p.x - 30, y: this.p.y, z: rand(10, 110), count: Math.round(10 * w.quality), speed: [40, 220], vz: [20, 160], life: [0.3, 0.8], size: [4, 12], color: '#ff3b52', color2: '#ffc93c', additive: true });
      for (const e of w.actors) {
        if (e.dead) continue;
        if (e.x < this.p.x + 120 && e.x > this.p.x - 300 && Math.abs(e.y - this.p.y) < 60) {
          e.vx += 900 * dt * 8; e.vz = Math.max(e.vz, 220); e.hitstun = 0.3; e.grounded = false;
        }
      }
      if (w.quality > 0.3 && Math.random() < dt * 30) w.shake(10);
    }
    if (this.phase === 'crouch') {
      this.p.vx = 0; this.p.vy = 0;
      if (w.quality > 0.4) w.ps.emit({ kind: 'ember', x: this.p.x + rand(-70, 70), y: this.p.y + rand(-24, 24), z: rand(0, 40), count: 2, speed: [10, 60], vz: [120, 340], life: [0.3, 0.7], size: [3, 8], color: '#ff3b52', additive: true });
    }
  }
  onRender(ctx: CanvasRenderingContext2D) {
    if (this.phase === 'crouch' && this.t < 1.5) return;
    const w = this.w, cam = w.camera;
    ctx.save();
    // 空間撕裂線
    ctx.globalCompositeOperation = 'lighter';
    if (this.phase === 'charge' || this.phase === 'quake') {
      const leadX = this.p.x - cam.x + DESIGN_W / 2;
      const n = 7;
      for (let i = 0; i < n; i++) {
        const yy = 90 + i * (DESIGN_H / n) + Math.sin(this.t * 12 + i) * 10;
        ctx.globalAlpha = 0.5;
        ctx.strokeStyle = i % 2 ? '#ff3b52' : '#ffc93c';
        ctx.lineWidth = 3 + Math.sin(this.t * 20 + i) * 2;
        ctx.beginPath();
        ctx.moveTo(Math.max(0, leadX - 1600), yy);
        for (let x = Math.max(0, leadX - 1600); x < leadX; x += 40) {
          ctx.lineTo(x, yy + rand(-6, 6));
        }
        ctx.stroke();
      }
      // 角形能量楔
      ctx.globalAlpha = 0.85;
      const g = ctx.createLinearGradient(leadX - 700, 0, leadX, 0);
      g.addColorStop(0, 'rgba(255,59,82,0)');
      g.addColorStop(1, 'rgba(255,201,60,0.8)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(leadX, 470);
      ctx.lineTo(leadX - 700, 300);
      ctx.lineTo(leadX - 700, 640);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }
}

/* ================================================================== */
/* 六號・緋月 —— 九尾焚星陣                                            */
/* ================================================================== */
export class UltFei extends UltScript {
  private orbs: { a: number; r: number; z: number }[] = [];
  private meteors: { x: number; y: number; z: number; vz: number; done: boolean }[] = [];
  private tails: { t0: number; idx: number }[] = [];
  private collapse = 0;
  protected build() {
    this.dur = 7;
    this.at(1.5, () => {
      const w = this.w;
      w.sfx('thunder', 0.9, 1.6);
      w.screen.flash('#a56bff', 0.55, 0.6);
      for (let i = 0; i < 9; i++) this.orbs.push({ a: (i / 9) * TAU, r: 90, z: 90 });
      w.fx.rune(this.p.x, this.p.y, { color: '#a56bff', w: 520, dur: 5 });
      this.liftAll(180);
    });
    for (let i = 0; i < 20; i++) {
      this.at(2.0 + i * 0.11, () => {
        const w = this.w;
        const x = this.p.x + rand(-900, 900), y = rand(-40, 120);
        this.meteors.push({ x, y, z: 900, vz: -1100, done: false });
        w.sfx('fire', 0.3, rand(1.1, 1.6));
      });
    }
    for (let i = 0; i < 9; i++) {
      this.at(4.4 + i * 0.13, () => {
        const w = this.w;
        this.tails.push({ t0: this.t, idx: i });
        w.sfx('wind', 0.6, 0.7 + i * 0.05);
        this.hitAll(17, { lift: 200, kb: 120, silent: true });
        w.shake(14);
      });
    }
    this.at(5.9, () => {
      const w = this.w;
      this.collapse = 0.001;
      w.screen.slowmo(0.18, 1.1);
      w.sfx('charge', 1, 1.8);
    });
    this.at(6.4, () => {
      const w = this.w;
      this.collapse = 2;
      w.screen.flash('#e0b0ff', 1, 0.9);
      w.shake(60);
      w.sfx('explode', 1.3, 0.9);
      w.sfx('thunder', 1, 1.2);
      w.fx.ring(this.p.x, this.p.y, 60, { color: '#a56bff', w: 1900, h: 600, dur: 1.4 });
      w.fx.ring(this.p.x, this.p.y, 60, { color: '#ffc93c', w: 1300, h: 420, dur: 1.1 });
      for (let i = 0; i < 14; i++) {
        const a = (i / 14) * TAU;
        w.fx.pillar(this.p.x + Math.cos(a) * 320, this.p.y + Math.sin(a) * 90, { color: '#a56bff', color2: '#7fd4ff', w: 100, h: 1200, dur: 1.4 });
      }
      w.ps.emit({ kind: 'star', x: this.p.x, y: this.p.y, z: 80, count: Math.round(240 * w.quality), speed: [200, 1200], vz: [100, 1000], life: [0.7, 2.2], size: [5, 20], color: '#c9a0ff', color2: '#7fd4ff', additive: true, grav: 120 });
      this.hitAll(190, { lift: 900, kb: 700 });
      areaDamage(w, this.p.x, this.p.y, 1200, 120);
    });
  }
  onUpdate(dt: number) {
    const w = this.w;
    for (const o of this.orbs) {
      o.a += dt * 1.6;
      o.r = lerp(o.r, this.collapse > 1 ? 40 : 220, 1 - Math.exp(-2 * dt));
    }
    for (const m of this.meteors) {
      if (m.done) continue;
      m.z += m.vz * dt;
      if (w.quality > 0.4) {
        w.ps.emit({ kind: 'ember', x: m.x, y: m.y, z: m.z, count: 2, speed: [10, 60], life: [0.2, 0.6], size: [4, 12], color: '#ffc93c', color2: '#a56bff', additive: true });
      }
      if (m.z <= 20) {
        m.done = true;
        w.fx.impact(m.x, m.y, 20, { elem: 'fox', scale: 2.2 });
        w.fx.ring(m.x, m.y, 10, { color: '#a56bff', w: 300, h: 100, dur: 0.5 });
        areaDamage(w, m.x, m.y, 170, 34);
        w.shake(12);
        w.sfx('explode', 0.45, rand(1.2, 1.8));
      }
    }
    if (this.collapse > 0 && this.collapse < 2) this.collapse += dt;
    if (this.t > 1.5) { this.p.vz = 0; this.p.vx = 0; this.p.vy = 0; }
  }
  onRender(ctx: CanvasRenderingContext2D) {
    const w = this.w, cam = w.camera;
    const px = this.p.x - cam.x + DESIGN_W / 2;
    const py = worldToScreenY(this.p.y, this.p.z);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    // 九尾（貝茲緞帶）
    for (const tl of this.tails) {
      const age = this.t - tl.t0;
      if (age > 1.6) continue;
      const k = clamp(age / 0.5, 0, 1);
      const fade = clamp(1.6 - age, 0, 1);
      const baseA = (tl.idx / 9) * TAU;
      ctx.save();
      ctx.translate(px, py);
      ctx.globalAlpha = 0.75 * fade;
      const len = 900 * Ease.outExpo(k);
      const sway = Math.sin(age * 6 + tl.idx) * 120;
      const g = ctx.createLinearGradient(0, 0, Math.cos(baseA) * len, Math.sin(baseA) * len * 0.4);
      g.addColorStop(0, 'rgba(255,255,255,0.9)');
      g.addColorStop(0.4, 'rgba(165,107,255,0.7)');
      g.addColorStop(1, 'rgba(127,212,255,0)');
      ctx.strokeStyle = g;
      ctx.lineWidth = 34 * fade;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(Math.cos(baseA) * len * 0.5, Math.sin(baseA) * len * 0.25 - 200 + sway, Math.cos(baseA) * len, Math.sin(baseA) * len * 0.4 - 60 + sway);
      ctx.stroke();
      ctx.restore();
    }
    // 九顆妖火球
    for (const o of this.orbs) {
      const ox = px + Math.cos(o.a) * o.r;
      const oy = py + Math.sin(o.a) * o.r * 0.4 - o.z;
      const g = ctx.createRadialGradient(ox, oy, 2, ox, oy, 46);
      g.addColorStop(0, 'rgba(255,255,255,0.95)');
      g.addColorStop(0.35, 'rgba(127,212,255,0.8)');
      g.addColorStop(1, 'rgba(165,107,255,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(ox, oy, 46, 0, TAU); ctx.fill();
    }
    // 流星
    for (const m of this.meteors) {
      if (m.done) continue;
      const sx = m.x - cam.x + DESIGN_W / 2;
      const sy = worldToScreenY(m.y, m.z);
      ctx.globalAlpha = 0.9;
      const g = ctx.createLinearGradient(sx, sy - 200, sx, sy);
      g.addColorStop(0, 'rgba(255,201,60,0)');
      g.addColorStop(1, 'rgba(255,255,255,0.9)');
      ctx.strokeStyle = g; ctx.lineWidth = 8;
      ctx.beginPath(); ctx.moveTo(sx, sy - 200); ctx.lineTo(sx, sy); ctx.stroke();
      const g2 = ctx.createRadialGradient(sx, sy, 2, sx, sy, 34);
      g2.addColorStop(0, '#fff8e0'); g2.addColorStop(0.5, 'rgba(255,201,60,0.7)'); g2.addColorStop(1, 'rgba(165,107,255,0)');
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.arc(sx, sy, 34, 0, TAU); ctx.fill();
    }
    ctx.restore();
  }
}

/* ============================ 總控 ============================ */
const ULT_CLASS: Record<string, new (w: IWorld, p: Actor, h: HeroDef) => UltScript> = {
  lin: UltLin, panya: UltPanya, lian: UltLian,
  shuangling: UltShuang, xuanjiao: UltXuan, feiyue: UltFei,
};

export class UltDirector {
  current: UltScript | null = null;
  active = false;

  start(w: IWorld, p: Actor, hero: HeroDef) {
    const C = ULT_CLASS[hero.id] ?? UltLin;
    this.current = new C(w, p, hero);
    this.current.start();
    this.active = true;
  }

  update(dt: number) {
    if (!this.current) return false;
    const done = this.current.update(dt);
    if (done) { this.current.finish(); this.current = null; this.active = false; return true; }
    return false;
  }

  render(ctx: CanvasRenderingContext2D) {
    this.current?.render(ctx);
  }

  cancel() {
    this.current?.finish();
    this.current = null;
    this.active = false;
  }
}
