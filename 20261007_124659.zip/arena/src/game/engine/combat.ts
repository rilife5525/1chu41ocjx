/**
 * 戰鬥解析
 * ------------------------------------------------------------------
 * 傷害計算（攻擊力／暴擊／連擊疊加／處決／空中／屬性）、
 * 命中判定盒、異常狀態（灼燒／冰緩／流血／麻痺／殺氣標記）、
 * 擊退與浮空、連擊評價、以及每一種部隊獨有的死亡演出。
 */
import type { Actor } from './actors';
import type { EffectSystem, ScreenFx } from './fx';
import type { FloatTextSystem, ParticleSystem, PickupSystem } from './particles';
import type { ProjectileSystem } from './projectiles';
import type { HitSpec, Mods, SfxId, TraitId } from '../core/types';
import { TAU, chance, clamp, rand } from '../core/util';

/* ============================ 世界介面 ============================ */
export interface IWorld {
  time: number;
  dt: number;
  player: Actor;
  actors: Actor[];
  projectiles: ProjectileSystem;
  fx: EffectSystem;
  ps: ParticleSystem;
  texts: FloatTextSystem;
  pickups: PickupSystem;
  screen: ScreenFx;
  mods: Mods;
  traits: Set<TraitId>;
  camera: { x: number; y: number; zoom: number };
  arenaW: number;
  combo: number;
  comboTimer: number;
  kills: number;
  souls: number;
  ultGauge: number;
  quality: number;
  sfx(id: SfxId, vol?: number, rate?: number): void;
  spawnSoul(x: number, y: number, z: number, v: number): void;
  onKill(a: Actor, byPlayer: boolean): void;
  addUlt(v: number): void;
  addExp(v: number): void;
  shake(v: number): void;
  comboReset(): void;
  heroId: string;
  lowHpMul: number;
  stageScale: { hp: number; atk: number; speed: number; souls: number };
}

/* ============================ 連擊評價 ============================ */
const RANKS: [number, string, string][] = [
  [120, '神', '#ff2d40'],
  [80, 'SSS', '#ffc93c'],
  [55, 'SS', '#ff7a1a'],
  [35, 'S', '#a56bff'],
  [22, 'A', '#4fd8ff'],
  [12, 'B', '#7cb35f'],
  [5, 'C', '#d8d2c0'],
  [0, 'D', '#8a8a8a'],
];
export function comboRank(n: number): { rank: string; color: string } {
  for (const [th, r, c] of RANKS) if (n >= th) return { rank: r, color: c };
  return { rank: 'D', color: '#8a8a8a' };
}

/* ============================ 異常狀態 ============================ */
export type StatusKind = 'burn' | 'freeze' | 'bleed' | 'stun' | 'mark' | 'fear';

export function applyStatus(a: Actor, kind: StatusKind, dur: number, power: number) {
  if (a.dead || a.team === 'player') {
    if (kind === 'stun' && a.team === 'player' && a.invuln > 0) return;
  }
  const st = a.status.find((s) => s.kind === kind);
  if (st) {
    st.t = Math.max(st.t, dur);
    st.dur = Math.max(st.dur, dur);
    st.power = Math.max(st.power, power);
    if (kind === 'bleed') st.stacks = Math.min(a.team === 'player' ? 5 : 10, st.stacks + 1);
  } else {
    a.status.push({ kind, t: dur, dur, power, stacks: kind === 'bleed' ? 1 : 0, tick: 0 });
  }
}

export function updateStatuses(a: Actor, w: IWorld, dt: number) {
  for (let i = a.status.length - 1; i >= 0; i--) {
    const s = a.status[i];
    s.t -= dt;
    s.tick -= dt;
    if (s.kind === 'burn' && s.tick <= 0) {
      s.tick = 0.4;
      damage(a, s.power, w, { noFx: true, color: '#ff8a3a', source: 'burn', silent: true });
      w.ps.emit({ kind: 'ember', x: a.x + rand(-16, 16), y: a.y, z: rand(10, a.height * 0.8), count: 2, speed: [10, 50], vz: [60, 180], life: [0.2, 0.5], size: [2, 5], color: '#ffb03a', additive: true, grav: -40 });
    }
    if (s.kind === 'bleed' && s.tick <= 0) {
      s.tick = 0.5;
      damage(a, s.power * Math.max(1, s.stacks), w, { noFx: true, color: '#ff2d40', source: 'bleed', silent: true });
      w.ps.emit({ kind: 'ink', x: a.x + rand(-12, 12), y: a.y, z: rand(20, a.height * 0.7), count: 3, speed: [20, 90], vz: [-40, 40], life: [0.3, 0.7], size: [3, 7], color: '#8a0a1a', grav: 900 });
    }
    if (s.kind === 'freeze' && w.quality > 0.4 && chance(dt * 6)) {
      w.ps.emit({ kind: 'drop', x: a.x + rand(-14, 14), y: a.y, z: rand(10, a.height * 0.8), count: 1, speed: [10, 40], life: [0.3, 0.6], size: [2, 5], color: '#9fe8ff', additive: true, grav: 200 });
    }
    if (s.t <= 0) {
      if (s.kind === 'mark') a.marked = false;
      a.status.splice(i, 1);
    }
  }
  const frozen = a.status.some((s) => s.kind === 'freeze');
  const stunned = a.status.some((s) => s.kind === 'stun');
  a.speedMul = (frozen ? 0.55 : 1) * (stunned ? 0 : 1) * (a.status.some((s) => s.kind === 'fear') ? 0.7 : 1);
}

/* ============================ 傷害計算 ============================ */
export interface DmgOpts {
  crit?: boolean;
  kb?: { x: number; y: number; z: number };
  launch?: boolean;
  hitstop?: number;
  shake?: number;
  fx?: string;
  sfx?: string;
  noFx?: boolean;
  color?: string;
  source?: string;
  silent?: boolean;
  attacker?: Actor;
  aoe?: number;
  diveScale?: number;
  skillMul?: number;
}

export function computeDamage(base: number, attacker: Actor | null, w: IWorld, target: Actor, opts: DmgOpts = {}) {
  const m = attacker?.team === 'player' ? w.mods : null;
  let dmg = base * (attacker?.atkMul ?? 1);
  if (m) {
    dmg *= m.atkMul;
    dmg += m.atkFlat;
    if (attacker?.airborne) dmg *= 1 + m.airDmg;
    // 連擊疊加
    dmg *= 1 + Math.min(0.6, w.combo * m.comboDmg);
    // 處決
    if (m.executeBelow > 0 && target.hp / target.maxHp < m.executeBelow) dmg *= m.executeMul;
    // 屠神
    if (w.traits.has('giantSlayer') && (target.def?.rank === '首領' || target.def?.rank === '菁英')) dmg *= 1.35;
    // 逆境之力（低血量加成，由世界每幀計算）
    dmg *= w.lowHpMul;
    // 俯衝加成：墜落越高越痛
    if (opts.diveScale) dmg *= opts.diveScale;
    if (opts.skillMul) dmg *= opts.skillMul;
  } else {
    dmg *= w.stageScale.atk;
  }
  // 暴擊
  let crit = !!opts.crit;
  if (!crit && m) crit = chance(m.critChance);
  if (crit && m) dmg *= m.critDmg;
  // 防禦／減傷
  const armor = target.team === 'player' ? (m ? m.armor : 0) : target.armor;
  dmg *= 1 - clamp(armor, 0, 0.8);
  // 冰緩中的目標受到更多傷害
  if (target.status.some((s) => s.kind === 'freeze')) dmg *= 1.25;
  if (target.status.some((s) => s.kind === 'mark')) dmg *= 1.2;
  return { dmg: Math.max(1, Math.round(dmg)), crit };
}



/* ============================ 造成傷害 ============================ */
export function damage(target: Actor, base: number, w: IWorld, opts: DmgOpts = {}) {
  if (target.dead) return 0;
  if (target.team === 'player') {
    if (target.invuln > 0 || target.dashing > 0) return 0;
    const m = w.mods;
    if (m && chance(m.dodgeChance)) {
      w.texts.spawn({ x: target.x, y: target.y, z: target.height + 20, text: '閃避', color: '#9fe8ff', style: 'buff', size: 22 });
      w.fx.ring(target.x, target.y, 40, { color: '#9fe8ff', scale: 0.5, w: 90, h: 30, dur: 0.3 });
      return 0;
    }
  }
  const { dmg, crit } = computeDamage(base, opts.attacker ?? (target.team === 'player' ? null : w.player), w, target, opts);

  // 護盾吸收
  let remain = dmg;
  if (target.shield > 0) {
    const absorbed = Math.min(target.shield, remain);
    target.shield -= absorbed;
    remain -= absorbed;
    if (absorbed > 0 && !opts.noFx) {
      w.fx.ring(target.x, target.y, target.height * 0.5, { color: '#9fe8ff', w: 130, h: 46, dur: 0.32 });
      w.texts.spawn({ x: target.x, y: target.y, z: target.height + 30, text: `${Math.round(absorbed)}`, color: '#9fe8ff', style: 'buff', size: 20 });
    }
  }
  target.hp -= remain;
  target.flashT = 0.14;

  const isPlayer = target.team === 'player';
  if (!opts.silent && !opts.noFx) {
    const col = crit ? '#ffc93c' : isPlayer ? '#ff2d40' : opts.color ?? '#ffffff';
    w.texts.spawn({
      x: target.x + rand(-14, 14), y: target.y, z: target.height * 0.85 + rand(0, 24),
      text: `${dmg}`, color: col, style: crit ? 'crit' : isPlayer ? 'dmg' : 'dmg',
      size: crit ? 40 : isPlayer ? 28 : 22 + clamp(dmg / 12, 0, 16),
      vz: rand(200, 320),
    });
    if (crit) {
      w.fx.impact(target.x, target.y, target.height * 0.6, { elem: 'iron', scale: 1.5, color: '#ffc93c', color2: '#fff0b8' });
      w.screen.chromatic = Math.max(w.screen.chromatic, 0.5);
    }
  }

  // 打击感：停頓 + 震動
  if (!isPlayer && !opts.noFx) {
    const hs = (opts.hitstop ?? (crit ? 0.09 : 0.05)) * w.mods.hitstopMul;
    w.screen.hitStop(clamp(hs, 0, 0.18));
    w.shake((opts.shake ?? (crit ? 12 : 6)) * (1 + dmg / 260));
    w.addUlt(clamp(dmg * 0.16, 1, 14) * w.mods.ultChargeMul);
    if (opts.attacker?.team === 'player') onPlayerHit(w, target, dmg, crit);
  } else if (isPlayer) {
    w.screen.shake(14);
    w.screen.flash('#ff2d40', 0.32, 0.28);
    w.screen.chromatic = 0.8;
    w.screen.vignette = 0.8;
    w.sfx('hurt', 1);
    w.comboReset();
  }

  // 吸血
  if (!isPlayer && w.mods.lifesteal > 0 && opts.attacker?.team === 'player') {
    const heal = dmg * w.mods.lifesteal;
    w.player.hp = Math.min(w.player.maxHp, w.player.hp + heal);
    if (heal > 1.5) w.texts.spawn({ x: w.player.x, y: w.player.y, z: w.player.height + 26, text: `+${Math.round(heal)}`, color: '#7cb35f', style: 'heal', size: 18 });
  }

  // 擊退／浮空
  if (opts.kb && !isPlayer) {
    const mul = w.mods.kbMul;
    const resist = 1 / (0.6 + target.weight * 0.55);
    target.vx += opts.kb.x * mul * resist;
    target.vy += opts.kb.y * mul * resist;
    if (opts.launch || opts.kb.z > 200) {
      target.vz = Math.max(target.vz, opts.kb.z * mul * resist * 1.1);
      target.grounded = false;
      target.launched = true;
    } else if (target.grounded) {
      target.vz = Math.max(target.vz, opts.kb.z * resist * 0.6);
    }
    if (target.def?.rank === '首領') { target.vx *= 0.28; target.vy *= 0.28; target.vz *= 0.2; }
  }
  if (isPlayer && opts.kb) {
    target.vx += opts.kb.x * 0.42;
    target.vz = Math.max(target.vz, opts.kb.z * 0.34);
    target.grounded = false;
    target.hitstun = Math.max(target.hitstun, 0.34);
    target.state = 'hurt';
    target.stateT = 0;
  } else if (!isPlayer) {
    const heavy = dmg > target.maxHp * 0.12 || (opts.launch ?? false);
    target.hitstun = Math.max(target.hitstun, heavy ? 0.42 : 0.24);
    if (target.state !== 'hurt' && target.state !== 'down') { target.state = 'hurt'; target.stateT = 0; }
  }

  // 反傷
  if (isPlayer && w.mods.thorns > 0 && opts.attacker && opts.attacker.team === 'enemy') {
    damage(opts.attacker, dmg * w.mods.thorns * 3, w, { noFx: true, silent: true, color: '#b98bff', source: 'thorns' });
    w.fx.ring(w.player.x, w.player.y, 50, { color: '#b98bff', w: 120, h: 40, dur: 0.3 });
  }

  if (target.hp <= 0 && !target.dead) kill(target, w, opts.attacker);
  return dmg;
}

/* ============================ 命中掛勾（traits） ============================ */
function onPlayerHit(w: IWorld, target: Actor, dmg: number, crit: boolean) {
  if (w.traits.has('onHitBurn')) applyStatus(target, 'burn', 3, dmg * 0.16 + 2);
  if (w.traits.has('onHitFreeze')) applyStatus(target, 'freeze', 2, 0);
  if (w.traits.has('onHitBleed')) applyStatus(target, 'bleed', 4, dmg * 0.1 + 1);
  if (w.traits.has('chainLightning') && (chance(0.25) || w.traits.has('el3' as TraitId))) chainLightning(w, target, dmg * 0.55);
  if (w.traits.has('critNova') && crit) {
    w.fx.ring(target.x, target.y, target.height * 0.5, { color: '#ffc93c', w: 220, h: 70, dur: 0.4 });
    w.fx.impact(target.x, target.y, target.height * 0.6, { elem: 'holy', scale: 1.6 });
    areaDamage(w, target.x, target.y, 150, dmg * 0.6, target);
  }
}

export function chainLightning(w: IWorld, from: Actor, dmg: number, jumps = 4) {
  let cur = from;
  const hit = new Set<number>([cur.uid]);
  for (let i = 0; i < jumps; i++) {
    let best: Actor | null = null, bd = 340;
    for (const a of w.actors) {
      if (a.dead || hit.has(a.uid) || a.team === 'player') continue;
      const d = Math.hypot(a.x - cur.x, (a.y - cur.y) * 2);
      if (d < bd) { bd = d; best = a; }
    }
    if (!best) break;
    w.fx.bolt(cur.x, cur.y, cur.height * 0.6, { x2: best.x, z: best.height * 0.6, color: '#9fe8ff', color2: '#ffffff', h: 240, dur: 0.22 });
    w.fx.beam(cur.x, cur.y, cur.height * 0.6, best.x, best.y, best.height * 0.6, { color: '#dff6ff', color2: '#9fe8ff', w: 8, dur: 0.18 });
    damage(best, dmg * Math.pow(0.86, i), w, { noFx: true, color: '#9fe8ff', source: 'chain' });
    applyStatus(best, 'stun', 0.35, 0);
    hit.add(best.uid);
    cur = best;
  }
  w.sfx('thunder', 0.6, 1.3);
}

export function areaDamage(w: IWorld, x: number, y: number, radius: number, dmg: number, except?: Actor) {
  for (const a of w.actors) {
    if (a.dead || a === except || a.team === 'player') continue;
    const d = Math.hypot(a.x - x, (a.y - y) * 1.8);
    if (d < radius + a.radius) {
      const falloff = 1 - clamp(d / (radius + a.radius), 0, 0.7);
      damage(a, dmg * falloff, w, {
        kb: { x: (a.x - x) * 2.4 * (a.x >= x ? 1 : -1) + 160, y: (a.y - y) * 1.2, z: 260 },
        noFx: true, color: '#ffb03a',
      });
    }
  }
}

/* ============================ 死亡演出（每種部隊獨有） ============================ */
export function kill(target: Actor, w: IWorld, killer?: Actor) {
  if (target.dead) return;
  target.dead = true;
  target.deadT = 0;
  target.hp = 0;
  target.state = 'dead';
  const isPlayer = target.team === 'player';
  if (isPlayer) return;

  const byPlayer = killer?.team === 'player' || killer === undefined;
  const def = target.def;
  const cols = def?.deathColors ?? ['#ffffff', '#888888'];
  const x = target.x, y = target.y, z = target.height * 0.5;
  const q = w.quality;

  // 慢動作與畫面效果（首領專屬）
  const isBoss = def?.rank === '首領';

  switch (def?.deathFx) {
    case 'boneBurst': // 小妖：骨屑＋綠血飛散
      w.ps.emit({ kind: 'shard', x, y, z, count: Math.round(16 * q), speed: [140, 520], vz: [120, 520], life: [0.5, 1], size: [3, 8], color: cols[0], color2: cols[1], grav: 1500, drag: 0.4 });
      w.ps.emit({ kind: 'ink', x, y, z: z * 0.6, count: Math.round(8 * q), speed: [60, 240], life: [0.4, 0.9], size: [6, 16], color: '#3a5a2a', grav: 700 });
      w.fx.splat(x, y, { color: '#3a5a2a', scale: 0.8 });
      break;
    case 'boneShatter': // 骷髏槍兵：骨骼爆碎＋紅纓飄散
      w.ps.emit({ kind: 'shard', x, y, z, count: Math.round(22 * q), speed: [160, 620], vz: [160, 620], life: [0.5, 1.1], size: [3, 10], color: cols[0], color2: '#6a6152', grav: 1700, drag: 0.3 });
      w.ps.emit({ kind: 'feather', x, y, z: z * 1.2, count: Math.round(6 * q), speed: [40, 160], vz: [60, 200], life: [0.8, 1.6], size: [6, 14], color: cols[1], grav: 60, drag: 1.4 });
      w.fx.impact(x, y, z, { elem: 'iron', scale: 1 });
      w.fx.splat(x, y, { color: '#c0392b', scale: 0.7 });
      break;
    case 'smokeVanish': // 狼影忍：化為紫藍煙霧消失
      w.ps.emit({ kind: 'smoke', x, y, z, count: Math.round(14 * q), speed: [40, 200], vz: [40, 220], life: [0.5, 1.1], size: [16, 40], color: cols[0], color2: '#1a1e38', grav: -60, drag: 2.4 });
      w.ps.emit({ kind: 'spark', x, y, z, count: Math.round(10 * q), speed: [200, 620], life: [0.2, 0.5], size: [2, 4], color: '#cfd8e8', additive: true });
      w.fx.ring(x, y, z, { color: '#5b6bd6', w: 150, h: 50, dur: 0.4 });
      break;
    case 'talismanScatter': // 術士：符紙漫天飛散
      w.ps.emit({ kind: 'rune', x, y, z, count: Math.round(18 * q), speed: [60, 260], vz: [80, 320], life: [1, 2], size: [8, 16], color: cols[0], color2: '#fff3c0', grav: 120, drag: 1.1, vrot: [-8, 8] });
      w.fx.impact(x, y, z, { elem: 'holy', scale: 1.2 });
      break;
    case 'fieryExplosion': // 爆焰甲蟲：爆炸
      w.fx.impact(x, y, z, { elem: 'flame', scale: 2 });
      w.fx.ring(x, y, 20, { color: '#ff8a3a', w: 260, h: 80, dur: 0.5 });
      w.ps.emit({ kind: 'ember', x, y, z, count: Math.round(26 * q), speed: [160, 640], vz: [80, 420], life: [0.4, 1], size: [4, 12], color: '#ffb03a', color2: '#ff2d40', grav: 260, additive: true });
      w.ps.emit({ kind: 'smoke', x, y, z, count: Math.round(10 * q), speed: [40, 160], vz: [60, 200], life: [0.6, 1.4], size: [20, 44], color: '#3a2a20', grav: -40 });
      w.sfx('explode', 1, 1.1);
      w.shake(20);
      areaDamage(w, x, y, 150, target.atkMul * 24);
      break;
    case 'rockShatter': // 石甲巨鬼：岩石崩解＋岩漿光
      w.ps.emit({ kind: 'debris', x, y, z, count: Math.round(34 * q), speed: [140, 620], vz: [140, 620], life: [0.6, 1.4], size: [6, 20], color: cols[0], color2: '#3a2f24', grav: 1900, drag: 0.3 });
      w.ps.emit({ kind: 'ember', x, y, z, count: Math.round(20 * q), speed: [60, 300], vz: [100, 400], life: [0.5, 1.2], size: [4, 12], color: '#ff8a3a', additive: true, grav: 200 });
      w.fx.crack(x, y, { color: '#e0a558', scale: 1.6 });
      w.fx.ring(x, y, 10, { color: '#c8a05a', w: 320, h: 100, dur: 0.7 });
      w.sfx('explode', 0.9, 0.7);
      w.shake(26);
      break;
    case 'featherBurst': // 弓妖：羽毛爆散
      w.ps.emit({ kind: 'feather', x, y, z, count: Math.round(20 * q), speed: [60, 320], vz: [60, 300], life: [0.8, 1.8], size: [5, 12], color: cols[0], color2: '#d8e8c0', grav: 90, drag: 1.6, vrot: [-6, 6] });
      w.fx.impact(x, y, z, { elem: 'wind', scale: 1.1 });
      break;
    case 'emberDissolve': // 獄犬：化為餘燼消散
      w.ps.emit({ kind: 'ember', x, y, z, count: Math.round(22 * q), speed: [40, 260], vz: [80, 360], life: [0.5, 1.3], size: [3, 9], color: cols[0], color2: '#ffb0a0', grav: -80, additive: true, drag: 1.6 });
      w.fx.ring(x, y, 20, { color: '#ff4a6a', w: 160, h: 52, dur: 0.42 });
      break;
    case 'starDust': // 巫者：星塵爆裂
      w.ps.emit({ kind: 'star', x, y, z, count: Math.round(26 * q), speed: [80, 420], vz: [60, 380], life: [0.6, 1.5], size: [4, 12], color: cols[0], color2: '#ffe0a0', grav: -30, additive: true });
      w.fx.rune(x, y, { color: '#ff5ad6', w: 220, dur: 1.2 });
      w.fx.ring(x, y, z, { color: '#ff5ad6', w: 200, h: 66, dur: 0.5 });
      break;
    case 'eliteBurst': // 菁英：紅黑爆裂
      w.ps.emit({ kind: 'shard', x, y, z, count: Math.round(28 * q), speed: [180, 700], vz: [140, 620], life: [0.5, 1.2], size: [4, 14], color: '#ff3b52', color2: '#2a0a14', grav: 1500 });
      w.fx.ring(x, y, z * 0.6, { color: '#ff3b52', w: 300, h: 96, dur: 0.6 });
      w.fx.impact(x, y, z, { elem: 'flame', scale: 1.8 });
      w.sfx('explode', 0.8, 1.2);
      w.shake(20);
      break;
    default:
      w.ps.emit({ kind: 'shard', x, y, z, count: Math.round(14 * q), speed: [120, 460], vz: [100, 460], life: [0.4, 1], size: [3, 9], color: cols[0], grav: 1400 });
      break;
  }

  if (isBoss) bossDeath(target, w);

  // 魂魄與統計
  const souls = def ? Math.round(rand(def.souls[0], def.souls[1]) * w.stageScale.souls * (def.rank === '菁英' ? 1.6 : 1) * (isBoss ? 4 : 1)) : 6;
  const burst = w.traits.has('onKillSoulBurst') ? 1.6 : 1;
  const n = isBoss ? 26 : def?.rank === '菁英' ? 8 : clamp(Math.round(souls / 5), 1, 6);
  for (let i = 0; i < Math.round(n * burst); i++) w.spawnSoul(x + rand(-24, 24), y + rand(-14, 14), z + rand(0, 40), Math.max(1, Math.round((souls * burst) / n)));

  if (byPlayer) {
    w.kills++;
    w.combo++;
    w.comboTimer = 3.2;
    w.addUlt(6 * w.mods.ultChargeMul);
    w.addExp(isBoss ? 60 : def?.rank === '菁英' ? 14 : 5);
    if (w.mods.healOnKill > 0) {
      w.player.hp = Math.min(w.player.maxHp, w.player.hp + w.mods.healOnKill);
    }
    if (w.mods.staminaOnKill > 0) {
      w.player.stamina = Math.min(w.player.staminaMax, w.player.stamina + w.mods.staminaOnKill);
    }
    if (w.traits.has('onKillExplode')) {
      w.fx.impact(x, y, z, { elem: 'flame', scale: 1.5 });
      areaDamage(w, x, y, 140, 26 + w.player.atkMul * 10, target);
      w.sfx('explode', 0.5, 1.4);
    }
    w.screen.killFlash = Math.min(1, w.screen.killFlash + (isBoss ? 1 : 0.22));
    w.onKill(target, true);
  }
  if (!isBoss) w.sfx('die', 0.5, rand(0.85, 1.25));
}

function bossDeath(target: Actor, w: IWorld) {
  const x = target.x, y = target.y;
  w.screen.slowmo(0.22, 2.4);
  w.screen.flash('#ffffff', 0.85, 0.9);
  w.screen.bars = 0;
  w.shake(46);
  w.sfx('explode', 1.2, 0.6);
  w.sfx('bossRoar', 1, 0.6);
  const key = target.def?.deathFx ?? 'bossRockCollapse';
  const cols = target.def?.deathColors ?? ['#ffc93c', '#ff3b52'];
  const q = w.quality;
  if (key === 'bossRockCollapse') {
    for (let i = 0; i < 10; i++) {
      const t = i / 10;
      setTimeout01(w, t * 1.4, () => {
        w.fx.pillar(x + rand(-220, 220), y + rand(-40, 40), { color: cols[0], color2: cols[1], w: rand(60, 140), h: 900, dur: 1.1 });
        w.fx.crack(x + rand(-260, 260), y + rand(-50, 50), { color: cols[0], scale: 2 });
      });
    }
  } else if (key === 'bossFlameNova') {
    for (let i = 0; i < 12; i++) {
      const t = i / 12;
      setTimeout01(w, t * 1.5, () => {
        w.fx.impact(x + rand(-300, 300), y + rand(-60, 60), rand(20, 200), { elem: 'flame', scale: 3 });
        w.fx.ring(x, y, 20, { color: '#ff6a1a', w: 500 + i * 40, h: 150, dur: 0.9 });
        w.ps.emit({ kind: 'ember', x, y, z: rand(0, 200), count: Math.round(40 * q), speed: [200, 900], vz: [100, 700], life: [0.6, 1.6], size: [4, 14], color: '#ffb03a', color2: '#ff2d40', additive: true, grav: 100 });
      });
    }
  } else if (key === 'bossHolyBurst') {
    for (let i = 0; i < 12; i++) {
      setTimeout01(w, (i / 12) * 1.5, () => {
        w.fx.bolt(x + rand(-320, 320), y + rand(-40, 40), 0, { color: '#dff6ff', h: 700, dur: 0.4 });
        w.fx.rune(x, y, { color: '#ffe6a8', w: 420, dur: 1.4 });
        w.fx.pillar(x + rand(-260, 260), y, { color: '#ffe6a8', color2: '#ffffff', w: 90, h: 1000, dur: 1 });
      });
    }
  } else {
    // bossApocalypse：終焉演出 —— 全場爆裂、時間靜止、九瞳閉合
    for (let i = 0; i < 18; i++) {
      setTimeout01(w, (i / 18) * 2.6, () => {
        w.fx.impact(x + rand(-460, 460), y + rand(-90, 90), rand(0, 260), { elem: 'void', scale: 3.4 });
        w.fx.ring(x, y, 10, { color: '#ff2d40', w: 600 + i * 60, h: 190, dur: 1.2 });
        w.fx.pillar(x + rand(-380, 380), y, { color: '#ff3b52', color2: '#ffc93c', w: 120, h: 1200, dur: 1.4 });
        w.ps.emit({ kind: 'ember', x, y, z: rand(0, 300), count: Math.round(50 * q), speed: [200, 1000], vz: [100, 800], life: [0.8, 2], size: [4, 16], color: '#ff3b52', color2: '#ffc93c', additive: true, grav: -60 });
        w.shake(30);
      });
    }
    w.screen.flash('#ff2d40', 0.7, 2);
  }
  void TAU;
}

/** 簡易延遲排程（掛在世界時間軸上，避免 setTimeout 受暫停影響） */
export interface Scheduled { t: number; fn: () => void }
const sched: Scheduled[] = [];
function setTimeout01(w: IWorld, delay: number, fn: () => void) {
  sched.push({ t: w.time + delay, fn });
}
export function updateSchedule(w: IWorld) {
  for (let i = sched.length - 1; i >= 0; i--) {
    if (w.time >= sched[i].t) { sched[i].fn(); sched.splice(i, 1); }
  }
}
export function clearSchedule() { sched.length = 0; }

/* ============================ 命中盒解析 ============================ */
export interface HitResult { target: Actor; dmg: number }

export function resolveHit(attacker: Actor, hit: HitSpec, w: IWorld, opts: DmgOpts = {}) {
  const dir = attacker.facing;
  const cx = attacker.x + hit.ox * dir;
  const cy = attacker.y + hit.oy * 0.3;
  const cz = attacker.z + (hit.oy ?? 0);
  const hw = hit.w * 0.5 * (w.mods.aoeMul && attacker.team === 'player' ? w.mods.aoeMul : 1);
  const hh = hit.h * 0.5;
  const diveScale = opts.diveScale;
  const results: HitResult[] = [];
  const targets = attacker.team === 'player' || attacker.team === 'ally' ? w.actors : [w.player, ...w.actors.filter((a) => a.team === 'ally')];
  for (const t of targets) {
    if (t.dead || t.team === attacker.team) continue;
    if (attacker.hitIds.has(t.uid) && !hit.pierce) continue;
    const dx = Math.abs(t.x - cx);
    const dy = Math.abs(t.y - cy) * 1.6;
    const dz = Math.abs(t.z + t.height * 0.5 - (cz + t.height * 0.5));
    if (dx < hw + t.radius && dy < 46 + t.radius && dz < hh + t.height * 0.7) {
      const dmg = damage(t, hit.dmg, w, {
        ...opts,
        kb: { x: hit.kb.x * dir, y: hit.kb.y, z: hit.kb.z },
        launch: hit.launch,
        hitstop: hit.hitstop,
        shake: hit.shake,
        attacker,
        diveScale,
        aoe: hit.aoe,
      });
      attacker.hitIds.add(t.uid);
      results.push({ target: t, dmg });
      if (hit.aoe) {
        w.fx.ring(t.x, t.y, 16, { color: opts.color ?? '#ffb03a', w: hit.aoe * 2.2, h: hit.aoe * 0.7, dur: 0.42 });
        areaDamage(w, t.x, t.y, hit.aoe, hit.dmg * 0.5 * (attacker.team === 'player' ? w.mods.atkMul : 1), t);
      }
    }
  }
  return results;
}
