/**
 * 美術資源管理
 * ------------------------------------------------------------------
 * 1. 載入所有圖片素材（由 Vite 直接 inline 成 base64，確保單檔發佈可用）
 * 2. Texture Atlas 自動校正：以背景色差異找出每格立繪的實際內容框，
 *    即使 AI 產圖的格線有些微偏移，也能精準裁切
 * 3. 提供漸層／網點／噪點等快取，避免每幀重建造成 GC 壓力
 */
import heroAtlasUrl from '../../assets/art/atlas-heroes.jpg';
import fiendAtlasUrl from '../../assets/art/atlas-fiends.jpg';
import keyartUrl from '../../assets/art/keyart-menu.jpg';
import bossArtUrl from '../../assets/art/boss-titan.jpg';
import peakFarUrl from '../../assets/art/bg-peak-far.jpg';
import peakNearUrl from '../../assets/art/bg-peak-near.jpg';
import flameFarUrl from '../../assets/art/bg-flame-far.jpg';
import flameNearUrl from '../../assets/art/bg-flame-near.jpg';
import heavenFarUrl from '../../assets/art/bg-heaven-far.jpg';
import heavenNearUrl from '../../assets/art/bg-heaven-near.jpg';

export type ArtKey =
  | 'heroAtlas' | 'fiendAtlas' | 'keyart' | 'bossArt'
  | 'peakFar' | 'peakNear' | 'flameFar' | 'flameNear' | 'heavenFar' | 'heavenNear';

const URLS: Record<ArtKey, string> = {
  heroAtlas: heroAtlasUrl,
  fiendAtlas: fiendAtlasUrl,
  keyart: keyartUrl,
  bossArt: bossArtUrl,
  peakFar: peakFarUrl,
  peakNear: peakNearUrl,
  flameFar: flameFarUrl,
  flameNear: flameNearUrl,
  heavenFar: heavenFarUrl,
  heavenNear: heavenNearUrl,
};

export interface Cell {
  sx: number; sy: number; sw: number; sh: number;
}

const ATLAS_KEYS: ArtKey[] = ['heroAtlas', 'fiendAtlas'];
export const ATLAS_COLS = 3;
export const ATLAS_ROWS = 2;

const images = new Map<ArtKey, HTMLImageElement>();
const cells = new Map<ArtKey, Cell[]>();
const gradCache = new Map<string, CanvasGradient>();
let halftonePattern: CanvasPattern | null = null;
let noiseCanvas: HTMLCanvasElement | null = null;

/** 背景色（產圖時指定），用於自動偵測內容框 */
const BG_RGB: [number, number, number] = [0x12, 0x0c, 0x16];

function loadOne(key: ArtKey): Promise<void> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      images.set(key, img);
      resolve();
    };
    img.onerror = () => {
      // 載入失敗時放入 1x1 透明圖，確保遊戲仍可執行（純程序化繪製降級）
      const c = document.createElement('canvas');
      c.width = c.height = 4;
      const fallback = new Image();
      fallback.src = c.toDataURL();
      images.set(key, fallback);
      resolve();
    };
    img.src = URLS[key];
  });
}

/**
 * 自動校正圖集格子：在名目格子四周擴大 12% 的視窗內，
 * 找出與背景色差異夠大的像素包圍盒，作為實際裁切範圍。
 */
function detectCells(key: ArtKey) {
  const img = images.get(key);
  if (!img || !img.naturalWidth) return;
  const w = img.naturalWidth, h = img.naturalHeight;
  const cw = w / ATLAS_COLS, ch = h / ATLAS_ROWS;
  const cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  const c = cv.getContext('2d', { willReadFrequently: true });
  if (!c) return;
  c.drawImage(img, 0, 0);
  let data: Uint8ClampedArray;
  try {
    data = c.getImageData(0, 0, w, h).data;
  } catch {
    // 某些環境下無法讀取，退回名目格子
    const out: Cell[] = [];
    for (let i = 0; i < ATLAS_COLS * ATLAS_ROWS; i++) {
      out.push({ sx: (i % ATLAS_COLS) * cw, sy: Math.floor(i / ATLAS_COLS) * ch, sw: cw, sh: ch });
    }
    cells.set(key, out);
    return;
  }
  const out: Cell[] = [];
  const PAD = 0.1; // 視窗擴大比例
  const THRESH = 34; // 與背景色的最小色差
  for (let i = 0; i < ATLAS_COLS * ATLAS_ROWS; i++) {
    const cx = (i % ATLAS_COLS) * cw;
    const cy = Math.floor(i / ATLAS_COLS) * ch;
    const wx0 = Math.max(0, Math.floor(cx - cw * PAD));
    const wy0 = Math.max(0, Math.floor(cy - ch * PAD));
    const wx1 = Math.min(w, Math.floor(cx + cw * (1 + PAD)));
    const wy1 = Math.min(h, Math.floor(cy + ch * (1 + PAD)));
    let minX = wx1, minY = wy1, maxX = wx0, maxY = wy0, found = false;
    const step = 3; // 取樣間隔（效能考量）
    for (let y = wy0; y < wy1; y += step) {
      for (let x = wx0; x < wx1; x += step) {
        const p = (y * w + x) * 4;
        const dr = Math.abs(data[p] - BG_RGB[0]);
        const dg = Math.abs(data[p + 1] - BG_RGB[1]);
        const db = Math.abs(data[p + 2] - BG_RGB[2]);
        if (dr + dg + db > THRESH) {
          found = true;
          if (x < minX) minX = x;
          if (y < minY) minY = y;
          if (x > maxX) maxX = x;
          if (y > maxY) maxY = y;
        }
      }
    }
    if (!found || maxX - minX < cw * 0.2) {
      out.push({ sx: cx, sy: cy, sw: cw, sh: ch });
    } else {
      // 保留一點邊距，避免切到線條
      const m = Math.min(cw, ch) * 0.02;
      out.push({
        sx: Math.max(cx - cw * PAD, minX - m),
        sy: Math.max(cy - ch * PAD, minY - m),
        sw: Math.min(cw * (1 + PAD * 2), maxX - minX + m * 2),
        sh: Math.min(ch * (1 + PAD * 2), maxY - minY + m * 2),
      });
    }
  }
  cells.set(key, out);
}

export async function loadArt(onProgress?: (p: number, key: ArtKey) => void): Promise<void> {
  const keys = Object.keys(URLS) as ArtKey[];
  let done = 0;
  await Promise.all(
    keys.map(async (k) => {
      await loadOne(k);
      done++;
      onProgress?.(done / keys.length, k);
    }),
  );
  for (const k of ATLAS_KEYS) detectCells(k);
  buildHalftone();
  buildNoise();
}

export const getImg = (k: ArtKey) => images.get(k);
export const imgReady = (k: ArtKey) => {
  const i = images.get(k);
  return !!i && i.complete && i.naturalWidth > 0;
};

export function getCell(key: ArtKey, index: number): Cell | null {
  const arr = cells.get(key);
  if (!arr || !arr.length) return null;
  return arr[((index % arr.length) + arr.length) % arr.length];
}

/**
 * 以 cover 方式把圖集某一格繪製到目標矩形（含裁切）
 */
export function drawCell(
  ctx: CanvasRenderingContext2D,
  key: ArtKey,
  index: number,
  dx: number, dy: number, dw: number, dh: number,
  opts: { flipX?: boolean; alpha?: number; tint?: string; tintAlpha?: number; scale?: number; offsetY?: number } = {},
) {
  const img = images.get(key);
  const cell = getCell(key, index);
  if (!img || !cell) return;
  ctx.save();
  ctx.globalAlpha = opts.alpha ?? 1;
  ctx.beginPath();
  ctx.rect(dx, dy, dw, dh);
  ctx.clip();
  const s = opts.scale ?? 1;
  const cover = Math.max(dw / cell.sw, dh / cell.sh) * s;
  let sw = dw / cover, sh = dh / cover;
  let sx = cell.sx + (cell.sw - sw) / 2;
  let sy = cell.sy + (cell.sh - sh) / 2 + (opts.offsetY ?? 0) * cell.sh;
  sx = Math.max(cell.sx, Math.min(sx, cell.sx + cell.sw - sw));
  sy = Math.max(cell.sy, Math.min(sy, cell.sy + cell.sh - sh));
  if (opts.flipX) {
    ctx.translate(dx + dw, dy);
    ctx.scale(-1, 1);
    ctx.drawImage(img, sx, sy, sw, sh, 0, 0, dw, dh);
  } else {
    ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
  }
  if (opts.tint) {
    ctx.globalCompositeOperation = 'source-atop';
    ctx.globalAlpha = opts.tintAlpha ?? 0.4;
    ctx.fillStyle = opts.tint;
    ctx.fillRect(dx - dw, dy, dw * 3, dh);
  }
  ctx.restore();
}

/** 背景圖以 cover 方式繪製，並可依視差偏移重複取樣 */
export function drawBg(
  ctx: CanvasRenderingContext2D, key: ArtKey,
  x: number, y: number, w: number, h: number,
  opts: { alpha?: number; offsetX?: number; offsetY?: number; zoom?: number; flip?: boolean } = {},
) {
  const img = images.get(key);
  if (!img || !img.naturalWidth) return;
  ctx.save();
  ctx.globalAlpha = opts.alpha ?? 1;
  const zoom = opts.zoom ?? 1;
  const iw = img.naturalWidth, ih = img.naturalHeight;
  const cover = Math.max(w / iw, h / ih) * zoom;
  const dw = iw * cover, dh = ih * cover;
  let dx = x + (w - dw) / 2 - (opts.offsetX ?? 0);
  const dy = y + (h - dh) / 2 - (opts.offsetY ?? 0);
  // 水平重複，讓視差捲動不會露白
  const startX = ((dx - x) % dw) + x - dw;
  if (opts.flip) {
    ctx.translate(0, y + h);
    ctx.scale(1, -1);
    ctx.translate(0, -(y));
  }
  for (let px = startX; px < x + w; px += dw) {
    ctx.drawImage(img, px, dy, dw, dh);
  }
  ctx.restore();
}

/* ============================ 快取資源 ============================ */
export function grad(ctx: CanvasRenderingContext2D, key: string, x0: number, y0: number, x1: number, y1: number, stops: [number, string][]): CanvasGradient {
  const ck = `${key}`;
  let g = gradCache.get(ck);
  if (!g) {
    g = ctx.createLinearGradient(x0, y0, x1, y1);
    for (const [p, c] of stops) g.addColorStop(p, c);
    gradCache.set(ck, g);
  }
  return g;
}

export function radial(ctx: CanvasRenderingContext2D, key: string, x: number, y: number, r: number, stops: [number, string][]): CanvasGradient {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  for (const [p, c] of stops) g.addColorStop(p, c);
  void key;
  return g;
}

/** P5 風格的半色調網點圖案 */
function buildHalftone() {
  const c = document.createElement('canvas');
  c.width = c.height = 8;
  const x = c.getContext('2d');
  if (!x) return;
  x.fillStyle = 'rgba(0,0,0,0.55)';
  x.beginPath();
  x.arc(2, 2, 1.5, 0, Math.PI * 2);
  x.arc(6, 6, 1.5, 0, Math.PI * 2);
  x.fill();
  const p = patternCtx?.createPattern(c, 'repeat');
  if (p) halftonePattern = p;
  halftoneSrc = c;
}
let halftoneSrc: HTMLCanvasElement | null = null;
let patternCtx: CanvasRenderingContext2D | null = null;
export function bindPatternCtx(ctx: CanvasRenderingContext2D) {
  patternCtx = ctx;
  if (halftoneSrc && !halftonePattern) halftonePattern = ctx.createPattern(halftoneSrc, 'repeat');
}
export const getHalftone = () => halftonePattern;

/** 噪點畫布（用於紙質／膠片顆粒） */
function buildNoise() {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const x = c.getContext('2d');
  if (!x) return;
  const d = x.createImageData(128, 128);
  for (let i = 0; i < d.data.length; i += 4) {
    const v = 120 + Math.random() * 135;
    d.data[i] = d.data[i + 1] = d.data[i + 2] = v;
    d.data[i + 3] = 26;
  }
  x.putImageData(d, 0, 0);
  noiseCanvas = c;
}
export const getNoise = () => noiseCanvas;

export function clearCaches() {
  gradCache.clear();
}
