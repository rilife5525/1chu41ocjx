/**
 * 粒子系統
 * ------------------------------------------------------------------
 * 全部粒子共用一個大型結構陣列池（SoA-like），每種粒子有專屬繪製方式：
 * 火花／餘燼／煙／碎片／花瓣／環／星芒／墨漬／羽毛／水滴／閃電段／拖尾／文字。
 * 依效能等級自動縮減生成量，確保手機也能維持 60 FPS。
 */
import { Pool, TAU, clamp, rand, swapRemove } from '../core/util';

export type PKind =
  | 'spark' | 'ember' | 'smoke' | 'shard' | 'petal' | 'ring' | 'star'
  | 'ink' | 'feather' | 'drop' | 'bolt' | 'trail' | 'dust' | 'glow' | 'debris' | 'rune';

export interface Particle {
  kind: PKind;
  x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
  life: number; maxLife: number;
  size: number; size2: number;
  rot: number; vrot: number;
  color: string; color2: string;
  alpha: number;
  grav: number; drag: number;
  additive: boolean;
  depthSort: boolean;
  data: number;
  dead: boolean;
}

export interface EmitSpec {
  kind: PKind;
  x: number; y?: number; z?: number;
  count?: number;
  speed?: [number, number];
  dir?: number; spread?: number;
  vz?: [number, number];
  life?: [number, number];
  size?: [number, number];
  size2?: number;
  color?: string; color2?: string;
  grav?: number; drag?: number;
  rot?: [number, number]; vrot?: [number, number];
  additive?: boolean;
  alpha?: number;
  data?: number;
  ySpread?: number;
}

const resetP = (p: Particle) => {
  p.kind = 'spark'; p.x = p.y = p.z = 0; p.vx = p.vy = p.vz = 0;
  p.life = p.maxLife = 0; p.size = p.size2 = 1; p.rot = p.vrot = 0;
  p.color = '#fff'; p.color2 = '#fff'; p.alpha = 1; p.grav = 0; p.drag = 0;
  p.additive = false; p.depthSort = false; p.data = 0; p.dead = false;
};

export class ParticleSystem {
  pool = new Pool<Particle>(() => ({
    kind: 'spark', x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 1,
    size: 4, size2: 0, rot: 0, vrot: 0, color: '#fff', color2: '#fff', alpha: 1,
    grav: 0, drag: 0, additive: false, depthSort: false, data: 0, dead: false,
  }), resetP, 400, 2600);

  budget = 1; // 效能分級：1 = 全量
  count = 0;

  setBudget(b: number) { this.budget = clamp(b, 0.2, 1); }

  emit(s: EmitSpec) {
    let n = s.count ?? 1;
    n = Math.max(1, Math.round(n * this.budget));
    const spread = s.spread ?? TAU;
    const dir = s.dir ?? 0;
    for (let i = 0; i < n; i++) {
      const p = this.pool.obtain();
      if (!p) return;
      const a = dir + (spread >= TAU ? Math.random() * TAU : (Math.random() - 0.5) * spread);
      const sp = s.speed ? rand(s.speed[0], s.speed[1]) : 0;
      p.kind = s.kind;
      p.x = s.x + Math.cos(a) * (s.ySpread ? rand(0, s.ySpread) : 0);
      p.y = (s.y ?? 0) + Math.sin(a) * (s.ySpread ? rand(0, s.ySpread) * 0.5 : 0);
      p.z = s.z ?? 0;
      p.vx = Math.cos(a) * sp;
      p.vy = Math.sin(a) * sp * 0.42;
      p.vz = s.vz ? rand(s.vz[0], s.vz[1]) : Math.sin(a) * sp * 0.35;
      p.maxLife = p.life = s.life ? rand(s.life[0], s.life[1]) : 0.5;
      p.size = s.size ? rand(s.size[0], s.size[1]) : 4;
      p.size2 = s.size2 ?? p.size;
      p.rot = s.rot ? rand(s.rot[0], s.rot[1]) : a;
      p.vrot = s.vrot ? rand(s.vrot[0], s.vrot[1]) : 0;
      p.color = s.color ?? '#ffffff';
      p.color2 = s.color2 ?? s.color ?? '#ffffff';
      p.alpha = s.alpha ?? 1;
      p.grav = s.grav ?? 0;
      p.drag = s.drag ?? 1.6;
      p.additive = s.additive ?? false;
      p.depthSort = true;
      p.data = s.data ?? 0;
      p.dead = false;
    }
  }

  update(dt: number) {
    const arr = this.pool.active;
    for (let i = arr.length - 1; i >= 0; i--) {
      const p = arr[i];
      p.life -= dt;
      if (p.life <= 0) { swapRemove(arr, i); this.pool.release(p); continue; }
      const d = Math.exp(-p.drag * dt);
      p.vx *= d; p.vy *= d;
      p.vz = p.vz * d - p.grav * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.rot += p.vrot * dt;
      if (p.z < 0 && p.kind !== 'ring' && p.kind !== 'glow' && p.kind !== 'trail') {
        p.z = 0;
        p.vz = Math.abs(p.vz) * (p.kind === 'shard' || p.kind === 'debris' ? 0.42 : 0.2);
        p.vx *= 0.72; p.vy *= 0.72;
        if (p.vz < 26) p.vz = 0;
      }
      if (p.x < -4000 || p.x > 8000) { swapRemove(arr, i); this.pool.release(p); }
    }
    this.count = arr.length;
  }

  clear() { this.pool.releaseAll(); this.count = 0; }
}

/* ============================ 傷害數字 ============================ */
export interface FloatText {
  x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
  life: number; maxLife: number;
  text: string; size: number; color: string; outline: string;
  style: 'dmg' | 'crit' | 'heal' | 'buff' | 'soul' | 'big';
  dead: boolean;
}

const resetT = (t: FloatText) => {
  t.x = t.y = t.z = 0; t.vx = t.vy = t.vz = 0; t.life = t.maxLife = 0;
  t.text = ''; t.size = 20; t.color = '#fff'; t.outline = '#000'; t.style = 'dmg'; t.dead = false;
};

export class FloatTextSystem {
  pool = new Pool<FloatText>(() => ({
    x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 1,
    text: '', size: 20, color: '#fff', outline: '#000', style: 'dmg', dead: false,
  }), resetT, 64, 320);

  spawn(o: Partial<FloatText> & { x: number; y: number; z: number; text: string }) {
    const t = this.pool.obtain();
    if (!t) return;
    t.x = o.x; t.y = o.y; t.z = o.z;
    t.vx = o.vx ?? rand(-40, 40);
    t.vy = o.vy ?? rand(-16, 16);
    t.vz = o.vz ?? rand(150, 240);
    t.maxLife = t.life = o.maxLife ?? 0.85;
    t.text = o.text;
    t.size = o.size ?? 22;
    t.color = o.color ?? '#ffffff';
    t.outline = o.outline ?? '#1a0a10';
    t.style = o.style ?? 'dmg';
    t.dead = false;
  }

  update(dt: number) {
    const arr = this.pool.active;
    for (let i = arr.length - 1; i >= 0; i--) {
      const t = arr[i];
      t.life -= dt;
      if (t.life <= 0) { swapRemove(arr, i); this.pool.release(t); continue; }
      t.vz -= 620 * dt;
      t.x += t.vx * dt; t.y += t.vy * dt; t.z += t.vz * dt;
      if (t.z < 40) { t.z = 40; t.vz *= -0.24; }
      t.vx *= 0.96;
    }
  }

  clear() { this.pool.releaseAll(); }
}

/* ============================ 魂魄拾取物 ============================ */
export interface Pickup {
  x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
  kind: 'soul' | 'heal' | 'stamina';
  value: number; life: number; t: number; homing: boolean; dead: boolean;
}

const resetPk = (p: Pickup) => {
  p.x = p.y = p.z = 0; p.vx = p.vy = p.vz = 0; p.kind = 'soul'; p.value = 1;
  p.life = 12; p.t = 0; p.homing = false; p.dead = false;
};

export class PickupSystem {
  pool = new Pool<Pickup>(() => ({
    x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, kind: 'soul', value: 1, life: 12, t: 0, homing: false, dead: false,
  }), resetPk, 48, 400);

  spawn(x: number, y: number, z: number, kind: Pickup['kind'], value: number) {
    const p = this.pool.obtain();
    if (!p) return;
    p.x = x; p.y = y; p.z = z;
    const a = Math.random() * TAU;
    const sp = rand(60, 220);
    p.vx = Math.cos(a) * sp; p.vy = Math.sin(a) * sp * 0.4; p.vz = rand(180, 420);
    p.kind = kind; p.value = value; p.life = 14; p.t = 0; p.homing = false; p.dead = false;
  }

  update(dt: number, target: { x: number; y: number; z: number }, radius: number, onPick: (p: Pickup) => void) {
    const arr = this.pool.active;
    for (let i = arr.length - 1; i >= 0; i--) {
      const p = arr[i];
      p.life -= dt; p.t += dt;
      if (p.life <= 0) { swapRemove(arr, i); this.pool.release(p); continue; }
      const dx = target.x - p.x, dy = target.y - p.y;
      const dist = Math.hypot(dx, dy);
      if (dist < radius || p.homing) {
        p.homing = true;
        const pull = 2400 * dt;
        p.vx += (dx / (dist || 1)) * pull;
        p.vy += (dy / (dist || 1)) * pull * 0.5;
        p.vz += (target.z + 40 - p.z) * 6 * dt;
      }
      p.vz -= 900 * dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      if (p.z < 12) { p.z = 12; p.vz = Math.abs(p.vz) * 0.4; p.vx *= 0.86; p.vy *= 0.86; }
      if (p.homing && dist < 34 && Math.abs(p.z - target.z) < 90) {
        onPick(p);
        swapRemove(arr, i); this.pool.release(p);
      }
    }
  }

  clear() { this.pool.releaseAll(); }
}
